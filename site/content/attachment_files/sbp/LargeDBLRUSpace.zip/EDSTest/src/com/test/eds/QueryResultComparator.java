package com.test.eds;

import java.util.Comparator;

public class QueryResultComparator implements Comparator<QuerySubResult>{

	public int compare(QuerySubResult qsr1, QuerySubResult qsr2){
		   
	        int qsr1Size= qsr1.getResultSetSize();        
	        int qsr2Size= qsr2.getResultSetSize();
	       
	        if(qsr1Size > qsr2Size)
	            return 1;
	        else if(qsr1Size < qsr2Size)
	            return -1;
	        else
	            return 0;    
	    }
}
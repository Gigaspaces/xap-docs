package com.gs.util;

public interface IDataProcessor {
	PartitionCount processData();
}
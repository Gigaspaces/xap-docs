package com.gs.test.client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Logger;

import net.jini.config.Configuration;
import net.jini.config.ConfigurationException;
import net.jini.core.lease.UnknownLeaseException;
import net.jini.lease.LeaseRenewalManager;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.LeaseContext;

public class LeaseManagerClient {

	Logger logger = Logger.getLogger(this.getClass().getName());
	GigaSpace gigaSpace = null;

	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("Usage: java LeaseManagerClient <space URL>");
			System.exit(1);
		}

		while (true) {
			try {
				new LeaseManagerClient(args[0]);
				Thread.sleep(120000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public LeaseManagerClient(String url) {

		// connect to the space using its URL
		IJSpace space = new UrlSpaceConfigurer(url).space();
		// use gigaspace wrapper to for simpler API
		this.gigaSpace = new GigaSpaceConfigurer(space).gigaSpace();

		createOrder();

	}

	private void createOrder() {
		// Create new order
		Order order = new Order();
		order.setData("NewOrder");
		order.setProcessed(false);

		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss.SSS");
		Calendar calendar = Calendar.getInstance();

		// Write the order with limited lease
		LeaseContext<Order> lease = gigaSpace.write(order, 10000);

		calendar.setTimeInMillis(System.currentTimeMillis());
		logger.info("Wrote Event at: " + formatter.format(calendar.getTime()));

		calendar.setTimeInMillis(lease.getExpiration());
		logger.info("Object Leased upto: "
				+ formatter.format(calendar.getTime()));

		// Create a custom configuration (use non-default roundTripTime)
		LeaseRenewalConfiguration myConfig = new LeaseRenewalConfiguration(1000);
		MyLeaseListener myListener = new MyLeaseListener();
		LeaseRenewalManager renewer;
		try {
			
			//Create a LeaseRenewalManager using custom config
			renewer = new LeaseRenewalManager(myConfig);

			//Renew the order lease for 1 minute and keep renewing every 10 seconds 
			renewer.renewUntil(lease, System.currentTimeMillis() + 60000,
					10000, myListener);

			// Get the expiration of the lease (this should now point to 1 minute instead of 10 seconds
			long leasedUntil = renewer.getExpiration(lease);
			calendar.setTimeInMillis(leasedUntil);
			logger.info("LeaseRenewalManager manages lease upto: "
					+ formatter.format(calendar.getTime()));
		} catch (ConfigurationException e1) {
			e1.printStackTrace();
			logger.info("Error configuring LeaseRenewalManager");
		} catch (UnknownLeaseException e) {
			e.printStackTrace();
			logger.info("Error retrieving Expiration");
		}
	}

	private static final class LeaseRenewalConfiguration implements Configuration {

		final private Long configRTT;

		public LeaseRenewalConfiguration(long renewRTT) {
			configRTT = renewRTT;
		}

		public Object getEntry(String component, String name, Class type)
				throws ConfigurationException {
			return getEntry(component, name, type, -1l, null);
		}

		public Object getEntry(String component, String name, Class type,
				Object defaultValue) throws ConfigurationException {
			return getEntry(component, name, type, defaultValue, null);
		}

		public Object getEntry(String component, String name, Class type,
				Object defaultValue, Object data) throws ConfigurationException {

			if (!component.equals("net.jini.lease.LeaseRenewalManager"))
				return defaultValue;
			if (name.equals("roundTripTime"))
				return configRTT; // renewalRTT
			if (name.equals("renewBatchTimeWindow"))
				return 2l; // renewBatchTimeWindow
			return defaultValue;
		}
	}

}

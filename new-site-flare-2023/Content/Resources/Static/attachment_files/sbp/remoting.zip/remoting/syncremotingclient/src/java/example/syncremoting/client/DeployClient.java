package example.syncremoting.client;

import org.openspaces.pu.container.servicegrid.deploy.Deploy;

import com.j_spaces.core.client.FinderException;
import com.j_spaces.core.client.SpaceFinder;

public class DeployClient {
	private static String spaceUrl = null;

	static public void main(String args[]) {
		spaceUrl = args[0];
		if (waitForSpaceToStart()) {
			try {
				Deploy.main(new String[] { args[1] });
				//Deploy deploy = new Deploy();
				//deploy.deploy(new String[] { args[1] });
				System.out.println("Application Deployed!");
				System.exit(0);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private static boolean waitForSpaceToStart() {

		int count = 0;
		while (true) {
			try {
				SpaceFinder.find(spaceUrl);
				System.out.println("Found Space! Deploying Application");
				return true;

			} catch (FinderException e) {
				count++;
				if (count == 30) {
					System.out.println("Can't find space - Exit!");
					return false;
				}
				System.out.println("Wait 5 sec for space to be deployed...");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

}

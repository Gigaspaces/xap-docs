package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.ConfigureOptions;
import com.gigaspaces.cli.model.WANGatewayModel;
import org.openspaces.schema.core.gateway.Delegator;
import org.openspaces.schema.core.gateway.Lookups;
import org.openspaces.schema.core.gateway.Sink;

import java.util.Map;

import static java.lang.String.valueOf;

/**
 * Created by skyler on 5/27/2015.
 *
 * TODO: Refactor, maybe too much code here?
 */
public class ConfigureOperation implements Operation<ConfigureOptions> {

    public static final String LOOKUPS_ID = "lookups";

    @Override
    public void run(ConfigureOptions options, CliGatewayContext context) {
        String gatewayName = options.getGatewayName();
        Map<String, WANGatewayModel> models = context.getModels();

        checkGatewayInitialized(models, gatewayName);
        WANGatewayModel model = models.get(gatewayName);
        if (options.isGatewayLookup()){
            if (options.isAdd()){
                Lookups.Lookup lookup = createLookup(options);
                model.addLookup(lookup);
            }
            if (options.isRemove()){
                model.removeLookup(options.getRemoteGatewayName());
            }
            if (options.isModify()){
                Lookups.Lookup lookup = createLookup(options);
                model.modifyLookup(lookup);
            }
        }
        if (options.isDelegator()){
            String delegatorId = options.getDelegator();
            if (options.isAdd()){
                if (options.getTarget() == null){
                    Delegator delegator = createDelegator(options);
                    model.addDelegator(delegator);
                }   else {
                    Delegator.Delegations.Delegation delegation = createDelegation(options);
                    model.addDelegation(delegatorId, delegation);
                }
            }
            if (options.isRemove()){
                if (options.getTarget() == null){
                    model.removeDelegator(delegatorId);
                }   else {
                    Delegator.Delegations.Delegation delegation = createDelegation(options);
                    model.removeDelegation(delegatorId, delegation);
                }

            }
        }
        if (options.isSink()){
            String sinkId = options.getSink();
            if (options.isAdd()){
                if (options.getSource() == null){
                    Sink sink = createSink(options);
                    model.addSink(sink);
                }   else {
                    Sink.Sources.Source source = createSource(options);
                    model.addSource(sinkId, source);
                }
            }
            if (options.isRemove()){
                if (options.getSource() == null){
                    model.removeSink(sinkId);
                }   else {
                    Sink.Sources.Source source = createSource(options);
                    model.removeSource(sinkId, source);
                }

            }
        }
    }

    private Sink createSink(ConfigureOptions parameters) {
        Sink sink = new Sink();
        sink.setId(parameters.getSink());
        if (parameters.getCommunicationPort() != null) {
            sink.setCommunicationPort(valueOf(parameters.getCommunicationPort()));
        }
        sink.setLocalSpaceUrl(parameters.getLocalSpaceURL());
        sink.setGatewayLookups(LOOKUPS_ID);
        sink.setLocalGatewayName(parameters.getGatewayName());
        sink.setStartEmbeddedLus(parameters.isStartEmbeddedLus());
        sink.setSources(new Sink.Sources());
        sink.setRequiresBootstrap(parameters.isRequireBootstrap());
        sink.setSecurity(createSinkSecurity(parameters));
        return sink;
    }

    private Sink.Sources.Source createSource(ConfigureOptions parameters) {
        Sink.Sources.Source source = new Sink.Sources.Source();
        source.setName(parameters.getSource());
        return source;
    }

    private Sink.Security createSinkSecurity(ConfigureOptions parameters) {
        Sink.Security security = new Sink.Security();
        security.setUsername(parameters.getUsername());
        security.setPassword(parameters.getPassword());
        return security;
    }

    private Delegator.Delegations.Delegation createDelegation(ConfigureOptions parameters) {
        Delegator.Delegations.Delegation delegation = new Delegator.Delegations.Delegation();
        delegation.setTarget(parameters.getTarget());
        return delegation;
    }

    private Delegator createDelegator(ConfigureOptions parameters) {
        Delegator delegator = new Delegator();
        delegator.setId(parameters.getDelegator());
        delegator.setDelegations(new Delegator.Delegations());
        if (parameters.getCommunicationPort() != null) {
            delegator.setCommunicationPort(valueOf(parameters.getCommunicationPort()));
        }
        delegator.setGatewayLookups(LOOKUPS_ID);
        delegator.setLocalGatewayName(parameters.getGatewayName());
        delegator.setStartEmbeddedLus(parameters.isStartEmbeddedLus());
        delegator.setSecurity(createDelegatorSecurity(parameters));
        return delegator;
    }

    private Delegator.Security createDelegatorSecurity(ConfigureOptions parameters) {
        Delegator.Security security = new Delegator.Security();
        security.setUsername(parameters.getUsername());
        security.setPassword(parameters.getPassword());
        return security;
    }

    private Lookups.Lookup createLookup(ConfigureOptions parameters) {
        Lookups.Lookup result = new Lookups.Lookup();
        result.setGatewayName(parameters.getRemoteGatewayName());
        result.setHost(parameters.getHostName());
        if (parameters.getCommunicationPort() != null) {
            result.setCommunicationPort(valueOf(parameters.getCommunicationPort()));
        }
        result.setDiscoveryPort(valueOf(parameters.getDiscoveryPort()));
        return result;
    }

    private void checkGatewayInitialized(Map<String, WANGatewayModel> models, String gatewayName) {
        if (!models.containsKey(gatewayName)){
            throw new IllegalArgumentException("WAN GW PU is not initialized");
        }
    }

}

package com.tricode.gigaspaces.rules.client;

import com.tricode.gigaspaces.rules.shared.RulesConstants;
import com.tricode.gigaspaces.rules.shared.fact.Holiday;
import com.tricode.gigaspaces.rules.shared.fact.IFact;
import com.tricode.gigaspaces.rules.shared.remoting.IRulesExecutionService;
import org.apache.log4j.Logger;
import org.openspaces.remoting.ExecutorProxy;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collection;

/**
 * A very simple client application that demonstrates how to use the space-based rules engine.
 */
@Component
public class Client {

    private final Logger log = Logger.getLogger(Client.class);

    /**
     * Remoting service for executing business rules that are stored in the space.
     */
    @ExecutorProxy(gigaSpace = "gigaSpace")
    private IRulesExecutionService rulesExecutionService;

    /**
     * Main point of execution. Simply fires up the Spring context.
     *
     * @param args Command line args.
     */
    public static void main(String[] args) {
        new FileSystemXmlApplicationContext("applicationContext.xml");
    }

    /**
     * Method is created automatically after Spring has populated all class fields.
     * Executes a single (dummy) call to the rules engine.
     */
    @PostConstruct
    public void executeRules() {
        log.info("Starting client execution");

        final Collection<IFact> facts = new ArrayList<IFact>(1);
        facts.add(new Holiday("summer holiday", "july"));

        try {
            rulesExecutionService.executeRules(
                    RulesConstants.PROJECT_NAME,
                    new String[]{"Test"},
                    facts
            );
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        log.info("End client execution");
    }

}
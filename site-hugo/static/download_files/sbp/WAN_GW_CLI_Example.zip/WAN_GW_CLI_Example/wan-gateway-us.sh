connect -g pavlo
initialize -n US
configure --name US -a -S sink --local-space-url jini://*/*/wanSpaceUS
configure --name US -a -S sink --source DE
configure --name US -a -D delegator
configure --name US -a -D delegator --target DE
configure --name US -a -L -n DE -h 127.0.0.1 -d 4174
configure --name US -a -L -n US -h 127.0.0.1 -d 4174
deploy -n US
disconnect


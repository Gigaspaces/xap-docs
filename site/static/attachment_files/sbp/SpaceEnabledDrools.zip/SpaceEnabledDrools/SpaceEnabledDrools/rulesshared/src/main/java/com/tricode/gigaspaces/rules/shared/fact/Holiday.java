package com.tricode.gigaspaces.rules.shared.fact;

/**
 * A test fact.
 */
public class Holiday implements IFact {

    private String name;
    private String when;

    public Holiday() {
    }

    public Holiday(String name, String when) {
        this.name = name;
        this.when = when;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWhen() {
        return when;
    }

    public void setWhen(String when) {
        this.when = when;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Holiday holiday = (Holiday) o;

        return name.equals(holiday.name) && when.equals(holiday.when);
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + when.hashCode();
        return result;
    }
}
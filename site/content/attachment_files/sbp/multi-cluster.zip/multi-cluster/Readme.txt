This example is using Maven for packaging and build. Please install the OpenSpaces Maven plugin before you run this example.

Extract the example archive into a folder. Navigate to the folder (calling it <multi-cluster-example>).

cd <multi-cluster-example>

Run setDevEnv-G1.bat script to set the environment

Run maven clean using following command
mvn clean

Run maven package (skip the tests) using following command
mvn package -DskipTests

Start gs-agent

Deploy the first space cluster using following,
cd <multi-cluster-example>\processor
mvn os:deploy -Dgroups=group1 -Dlocators=SK-GS -Dmodule=processor

Deploy the second space cluster by running deploy-space2.bat

Deploy the mirror using following,
cd <multi-cluster-example>\mirror
mvn os:deploy -Dgroups=group1 -Dlocators=SK-GS -Dmodule=mirror

Start a gs-ui instance and ensure that the spaces are mirror are available

For running the clients you need the common jar in the maven repo. Install the common jar using following,

cd <multi-cluster-example>\common
mvn install

Create products (in mySpace)
Run WriteProducts
mvn exec:java -Dexec.classpathScope=compile -Dexec.mainClass="com.gigaspaces.client.WriteProducts" -Dexec.args="jini://*/*/mySpace?groups=group1"

You will notice Products are available on the mySpace2 as well

Run WriteOrders
mvn exec:java -Dexec.classpathScope=compile -Dexec.mainClass="com.gigaspaces.client.WriteOrders" -Dexec.args="jini://*/*/mySpace?groups=group1"

New orders will update the Product quantities on mySpace which in turn will be replicated to mySpace2 instance as well

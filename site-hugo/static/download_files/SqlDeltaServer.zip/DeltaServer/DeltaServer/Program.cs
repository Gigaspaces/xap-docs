﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Timers;
using GigaSpaces.Core;
using GigaSpaces.Core.Metadata;
using DeltaServer;

namespace DeltaServer
{
    class Program
    {

        string _connStr = ConfigurationManager.ConnectionStrings["DBSTRING"].ConnectionString;
        public class Employee
        {
            public int Id { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int Age { get; set; }

        }
        static Timer timer;
        
        static void Main(string[] args)
        {

           
            Program client = new Program();
           
            string operation;
            string status;
            timer = new Timer();

            timer.Interval = 5000; //set interval of polling here
            timer.Elapsed += new ElapsedEventHandler(ChangeCapture);
            timer.Enabled = true;

           
            
            do{
            Console.WriteLine("--------------------------\n");
            Console.WriteLine("Database interaction operations\n----------------------------\n");
            Console.WriteLine("Press 'i' to insert data\n");
            Console.WriteLine("Press 'u' to update data\n");
            Console.WriteLine("Press 'd' to delete data\n");
            Console.WriteLine("Press 'e' to insert data\n");
            Console.WriteLine("\n======================================\n");

            operation = Console.ReadLine();
            Console.WriteLine(operation);

            switch (operation) { 
            
                case "i":
                    Console.WriteLine("Insert A Record");
                    client.insertrecord();
                    break;

                case "u":
                    Console.WriteLine("Update A Record");
                    client.updaterecord();
                    break;
    
                case "d":
                    Console.WriteLine("Delete A Record");
                    client.deleterecord();
                    break;
 
                case "e":
                   
                    Environment.Exit(0);
                    break;

                default:

                    Console.WriteLine("Wrong Choice");
                    break;
            
            }
                 Console.Write("Do You Want To Continue? (Y/N) : ");
                 status = Console.ReadLine();
            } while (status != "N" && status != "n");
            
        }//End of Main

         static void ChangeCapture(object sender, ElapsedEventArgs e)
        {
         
           
            ISpaceProxy spaceProxy = GigaSpacesFactory.FindSpace("jini://*/*/mydatagrid?groups=XAP-9.7.0-ga-NET-4.0.30319-x64");

            string _connStr = ConfigurationManager.ConnectionStrings["DBSTRING"].ConnectionString;
            
            SqlConnection con = new SqlConnection(_connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Capture", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            // this will query your database and return the result to your datatable
            DataTable dt = new DataTable();
            da.Fill(dt);

            //Insert Query starts
            List<Employee> objEmployee2 = (from item in dt.AsEnumerable()
                                           where item.Field<int>("__$operation") == 2
                                           select new Employee()
                                           {
                                               Id = item.Field<int>("Id"),
                                               FirstName = item.Field<string>("FirstName"),
                                               LastName = item.Field<string>("LastName"),
                                               Age = item.Field<int>("Age")
                                           }).ToList();
            var personarray = new Person[objEmployee2.Count];
            for (int i = 0; i < objEmployee2.Count; i++) // Loop through List with for
            {
                personarray[i] = new Person
                {
                    Id = objEmployee2[i].Id,
                    FirstName = objEmployee2[i].FirstName,
                    LastName = objEmployee2[i].LastName,
                    Age = objEmployee2[i].Age

                };
             
            }
            spaceProxy.WriteMultiple(personarray);
            //Insert Query ends

            //Update Query starts
            List<Employee> objEmployee3 = (from item in dt.AsEnumerable()
                                           where item.Field<int>("__$operation") == 4
                                           select new Employee()
                                           {
                                               Id = item.Field<int>("Id"),
                                               FirstName = item.Field<string>("FirstName"),
                                               LastName = item.Field<string>("LastName"),
                                               Age = item.Field<int>("Age")
                                           }).ToList();


     
            for (int i = 0; i < objEmployee3.Count; i++) // Loop through List with for
            {

                IdQuery<Person> idQuery = new IdQuery<Person>(objEmployee3[i].Id);
                IChangeResult<Person> changeResult =
                    spaceProxy.Change<Person>(idQuery,
                    new ChangeSet().Set("FirstName", objEmployee3[i].FirstName).Set("LastName", objEmployee3[i].LastName).Set("Age", objEmployee3[i].Age));

            }
            //Update Query ends

            //Delete Query starts

            List<Employee> objEmployee1 = (from item in dt.AsEnumerable()
                                           where item.Field<int>("__$operation") == 1
                                           select new Employee()
                                           {
                                               Id = item.Field<int>("Id"),
                                               FirstName = item.Field<string>("FirstName"),
                                               LastName = item.Field<string>("LastName"),
                                               Age = item.Field<int>("Age")
                                           }).ToList();
            var deltearray = new Person[objEmployee1.Count];
            for (int i = 0; i < objEmployee1.Count; i++) // Loop through List with for
            {

                Person template = new Person();
                template.Id = objEmployee1[i].Id;
                spaceProxy.Take<Person>(template);
            }

            //Delete Query ends


            da.Dispose();
            con.Close();

        }

        

        public void insertrecord()
        {
            try
            {
                int id;
                string fname;
                string lname;
                int age;

                //string _connStr = "Data Source=Hp;Initial Catalog=Details1;Integrated Security=True";
                SqlConnection con = new SqlConnection(_connStr);
                con.Open();
                Console.WriteLine("Enter ID: \n");
                id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter FirstName: \n");
                fname = Console.ReadLine();
                Console.WriteLine("Enter LastName: \n");
                lname = Console.ReadLine();
                Console.WriteLine("Enter Age: \n");
                age = Convert.ToInt32(Console.ReadLine());

                SqlCommand cmd = new SqlCommand("insert into Person(Id,FirstName,LastName,Age) values('" + id + "','" + fname + "','" + lname + "','"+age+"')", con);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Data Inserted Succesfully");
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} Exception caught.", ex);
            }

        }

        public void updaterecord()
        {
            try
            {
                int id;
                string fname;
                string lname;
                int age;
                //string _connStr = "Data Source=Hp;Initial Catalog=Details1;Integrated Security=True";
                SqlConnection con = new SqlConnection(_connStr);
                con.Open();
                Console.WriteLine("Enter ID: \n");
                id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter FirstName: \n");
                fname = Console.ReadLine();
                Console.WriteLine("Enter LastName: \n");
                lname = Console.ReadLine();
                Console.WriteLine("Enter Age: \n");
                age = Convert.ToInt32(Console.ReadLine());

                SqlCommand cmd = new SqlCommand("update Person set FirstName ='" + fname + "',LastName='" + lname + "',Age='"+age+"' where Id=" + id, con);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Data Updated Successfully");
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} Exception caught.", ex);
            }

        
        }
        public void deleterecord()
        {

            try
            {
                int id;

                //string _connStr = "Data Source=Hp;Initial Catalog=Details1;Integrated Security=True";
                SqlConnection con = new SqlConnection(_connStr);
                con.Open();
                Console.WriteLine("Enter Id to delete: \n");
                id = Convert.ToInt32(Console.ReadLine());


                SqlCommand cmd = new SqlCommand("delete from Person where Id=" + id, con);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Data Deleted Successfully");
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} Exception caught.", ex);
            }

        }

        


    }//End of Class Program

 
}

package com.test.eds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.executor.DistributedTask;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.async.AsyncResult;
import com.j_spaces.core.client.SQLQuery;
import com.j_spaces.core.client.SpaceURL;

public class CountTask implements DistributedTask<QuerySubResult, List<QuerySubResult>>{

	@TaskGigaSpace
	transient GigaSpace gigaspace;
	
	String queryStr ;

	public CountTask (String query)
	{
		this.queryStr=query ;
	}
	
	public QuerySubResult execute() throws Exception {
		int partitionID= Integer.valueOf(gigaspace.getSpace().getURL().getProperty(SpaceURL.CLUSTER_MEMBER_ID)).intValue();		
		System.out.println("Partition ID: " +partitionID);
		SQLQuery<MyData> query = new SQLQuery<MyData>  (MyData.class , queryStr);
		int count = gigaspace.count(query);
		QuerySubResult subResult = new QuerySubResult(count,partitionID);
		return subResult;
	}

	public List<QuerySubResult> reduce(List<AsyncResult<QuerySubResult>> results) throws Exception {
		System.out.println(this.getClass().getName() + " - reduce is called");
		List<QuerySubResult> counts = new ArrayList<QuerySubResult> (); 
		for (AsyncResult<QuerySubResult> asyncResult : results) {
			counts.add(asyncResult.getResult());
		}
		return counts ;
	}
}

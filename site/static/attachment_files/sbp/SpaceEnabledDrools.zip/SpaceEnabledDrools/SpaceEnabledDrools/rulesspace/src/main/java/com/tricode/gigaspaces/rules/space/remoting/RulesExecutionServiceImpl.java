package com.tricode.gigaspaces.rules.space.remoting;

import com.tricode.gigaspaces.rules.shared.drools.model.DroolsContext;
import com.tricode.gigaspaces.rules.shared.fact.IFact;
import com.tricode.gigaspaces.rules.shared.remoting.IRulesExecutionService;
import com.tricode.gigaspaces.rules.space.drools.loader.SpaceDroolsRuleLoader;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.definition.KnowledgePackage;
import org.drools.runtime.StatelessKnowledgeSession;
import org.openspaces.core.GigaSpace;
import org.openspaces.remoting.RemotingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

@RemotingService
public class RulesExecutionServiceImpl implements IRulesExecutionService {

    @Autowired
    private GigaSpace gigaSpace;

    /**
     * {@inheritDoc}
     */
    @Transactional
    public Collection<IFact> executeRules(String projectName, String[] rulesetNames, Map<String, Object> globals, Collection<IFact> facts) {
        DroolsContext context = getContext(projectName, rulesetNames);

        StatelessKnowledgeSession session = context.getKnowledgeBase().newStatelessKnowledgeSession();

        // Session scoped globals
        if (globals != null) {
            for (String key : globals.keySet()) {
                session.setGlobal(key, globals.get(key));
            }
        }

        session.execute(facts);

        return facts;
    }

    /**
     * {@inheritDoc}
     */
    @Transactional
    public Collection<IFact> executeRules(String projectName, String[] rulesetNames, Collection<IFact> facts) {
        return executeRules(
                projectName,
                rulesetNames,
                null,
                facts
        );
    }

    private DroolsContext getContext(String projectName, String rulesetNames[]) {
        StringBuilder concatenatedNames = null;

        if (rulesetNames != null) {
            concatenatedNames = new StringBuilder();
            for (String rulesetName : rulesetNames) {
                concatenatedNames.append(rulesetName);
                concatenatedNames.append(",");
            }
        }

        DroolsContext template = new DroolsContext();
        template.setProjectName(projectName);
        if (concatenatedNames != null) {
            template.setRulesetNames(concatenatedNames.toString());
        }
        DroolsContext context = gigaSpace.read(template);

        if (context == null) {
            context = new DroolsContext();
            context.setProjectName(projectName);
            if (concatenatedNames != null) {
                context.setRulesetNames(concatenatedNames.toString());
            }
            final KnowledgeBase base = KnowledgeBaseFactory.newKnowledgeBase();
            context.setKnowledgeBase(base);

            Collection<KnowledgePackage> packages;
            if (rulesetNames == null) {
                packages = new SpaceDroolsRuleLoader(gigaSpace).getKnowledgePackages(projectName);
            } else {
                packages = new ArrayList<KnowledgePackage>();

                for (String rulesetName : rulesetNames) {
                    packages.addAll(new SpaceDroolsRuleLoader(gigaSpace).getKnowledgePackages(projectName, rulesetName));
                }
            }

            context.getKnowledgeBase().addKnowledgePackages(packages);

            gigaSpace.write(context);
        }

        return context;
    }

}
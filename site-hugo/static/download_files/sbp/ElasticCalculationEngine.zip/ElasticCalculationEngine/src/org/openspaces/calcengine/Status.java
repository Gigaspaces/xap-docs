package org.openspaces.calcengine;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.esm.ElasticServiceManager;
import org.openspaces.admin.gsa.GridServiceAgent;
import org.openspaces.admin.gsc.GridServiceContainer;
import org.openspaces.admin.gsm.GridServiceManager;
import org.openspaces.admin.pu.ProcessingUnit;

public class Status {
	static DecimalFormat formater = new DecimalFormat("0.0");

	static String DATA_GRID_PU = "CalcDataGrid";
	
	static String locator = System.getProperty("locators", "127.0.0.1");

	static Logger logger = Logger.getLogger("Status");
	public static void main(String[] args) throws Exception{
		int targetSize = Integer.valueOf(args[0]);
		
		System.out.println("Target Size[MB]:"+targetSize);
		
		Admin admin = new AdminFactory().addLocator(locator).create();
		
		if (admin !=null)
			logger.info("Created Admin - OK!");
		else 
		{
			logger.info(" Can't find a Admin - exit");
			System.exit(0);
		}

		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);

		GridServiceAgent agent = admin.getGridServiceAgents().waitForAtLeastOne(10, TimeUnit.SECONDS);

		System.out.println("agent PID "+ agent.getVirtualMachine().getDetails().getPid());
		
		ElasticServiceManager esm = admin.getElasticServiceManagers().waitForAtLeastOne(10, TimeUnit.SECONDS);

		System.out.println("esm PID "+ esm.getVirtualMachine().getDetails().getPid());

		GridServiceManager gsm = admin.getGridServiceManagers().waitForAtLeastOne(10, TimeUnit.SECONDS);

		if (gsm == null)
		{
			logger.info(" Can't find a GSM - exit");
			System.exit(0);
		}

		ProcessingUnit pu = null;
		
		pu = admin.getProcessingUnits().waitFor(DATA_GRID_PU, 10,TimeUnit.SECONDS);
		
		if (pu== null)
		{
			System.out.println("Can't find " + DATA_GRID_PU);
		}
		if (admin.getGridServiceContainers().waitFor(1, 1000, TimeUnit.SECONDS))
		{
			// Get total GSCs
			while (true)
			{
				double total_heap =0;
				int gscCount = 0 ;
				GridServiceContainer gscs[] = admin.getGridServiceContainers().getContainers();
				for (int i = 0; i < gscs.length; i++) {
					if (gscs[i].getZones().containsKey("CalcDataGrid"))
					{
						double maxheapsize = gscs[i].getVirtualMachine().getDetails().getMemoryHeapMaxInBytes();
						total_heap = total_heap  + maxheapsize;
						gscCount ++;
					}
				}
				int total_heapMB = (int)total_heap/(1024*1024);
				System.out.println(new Date() + " Total GSCs:" + gscCount + " Total Heap[MB]:"+total_heapMB);
				
				if ((total_heapMB > (targetSize * 0.9)) && (total_heapMB < (targetSize * 1.1))) 
					System.exit(0);
				
				Thread.sleep(1000);
			}
		}
	}
}

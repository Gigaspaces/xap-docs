package com.gigaspaces.examples.priorityq;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

public class PriorityQueueExample {
	public static void main(String[] args) {
		System.out.println("Welcome to GigaSpaces Priority Based Queue Example" );
		GigaSpace space = null;
		
		try {
			String spaceURL = "/./mySpace";
			if (args.length >0 )
				spaceURL=args[0];
						
			space = new GigaSpaceConfigurer (new UrlSpaceConfigurer(spaceURL)).gigaSpace();
			if (space == null) {
				System.out.println("can't connect to space" + spaceURL);
				System.out.println("exit!");
			}
			
			System.out.println("Connect to space:" + spaceURL + " OK!");
			space.clean();
			space.snapshot(new Order());
			
			int masterCount = 1;
			int workersCount = 2;
			Worker workers[] = new Worker [workersCount ];
			Master masters[] = new Master[masterCount  ];
			
			//Monitor monitor= new Monitor (space);
			//monitor.start();

			for (int i=0;i<masterCount ;i++)
			{
				masters[i]= new Master(space);
				masters[i].start();
			}

			Thread.sleep(2000);

			for (int i=0;i<masterCount ;i++)
			{
				masters[i].stop();
			}

			for (int i=0;i<workersCount ;i++)
			{
				workers[i]= new Worker(space , i *workersCount  , (i*workersCount ) + workersCount );
				workers[i].start();
			}

			for (int i=0;i<workersCount ;i++)
			{
				workers[i].join();
			}

			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

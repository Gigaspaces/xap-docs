#!/bin/bash
cat $1 | java -classpath /home/adminuser/gigaspaces-xap-premium-10.2.1-ga/lib/required/*:deployment/lib/*:target/* com.gigaspaces.cli.CommandLineTool


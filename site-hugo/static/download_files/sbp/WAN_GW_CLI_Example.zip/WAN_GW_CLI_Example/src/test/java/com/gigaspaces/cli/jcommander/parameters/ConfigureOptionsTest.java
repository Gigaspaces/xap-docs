package com.gigaspaces.cli.jcommander.parameters;

import com.gigaspaces.cli.jcommander.OptionsParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by skyler on 5/28/2015.
 */
public class ConfigureOptionsTest {

    @Test(expected=IllegalArgumentException.class)
    public void throwsWhenNameIsNull() {
        internalTestWrapper("-a", new ConfigureOptions());
    }

    @Test
    public void happyPathConfigureOptions() {
        ConfigureOptions underTest = new ConfigureOptions();
        internalTestWrapper("-a --name sitename", underTest);

        assertTrue(underTest.isAdd());
        assertEquals(underTest.getGatewayName(), "sitename");
    }

    @Test(expected=IllegalArgumentException.class)
    public void throwsWhenNoTaskIsSpecified() {
        internalTestWrapper("--name sitename", new ConfigureOptions());
    }

    @Test(expected=IllegalArgumentException.class)
    public void throwsWhenMultipleTasksAreSpecified() {
        internalTestWrapper("-a -m --name sitename", new ConfigureOptions());
    }

    private void internalTestWrapper(String command, ConfigureOptions options){
        OptionsParser optionsParser = new OptionsParser();
        optionsParser.parse(command.split(" "), options);
    }
}

WAN Gateway CLI Tool
===

About
---
Often there is a need to create and deploy a WAN gateway PU. The process is repeatable 
and can be easily automated ­ to speed this up this tool was created and it takes care 
of WAN gateway configuration and deployment.  
This tool can be used with master-slave, master-master or any other topology. 

Build process
---
WAN Gateway CLI Tool is built using maven command:

    mvn clean package

How to run tool
---
To run tool execute bash file `run.sh`

    ./run.sh wan_gateway_config.sh

where wan_gateway_config.sh is configuration file.


Configuration file format
---

Each line of configuration file has the following format:

    {command} {parameters}

Allowed commands: CONFIGURE, DEPLOY, DISCONNECT, INITIALIZE, LINK, BOOTSTRAP, CONNECT.
Please see allowed parameters for each command below.

### connect [*options*]
Sets the connect parameters. Required as the first command to connect to the specified grid, without it all other commands will fail.

**Options:**

| Short name 	|     Long name    	|              Description             	            | Optional/Required 	|   	
|:----------:	|:----------------:	|:------------------------------------:	            |:-----------------:	|	
|     -u     	| --username 	    | Username to authenticate against a secured grid.  |      optional     	|
|     -p     	| --password 	    | Password to authenticate against a secured grid.  |      optional     	|
|     -l     	| --lookup-locators | Lookup locator (null for default)  	            |      optional     	|
|     -g     	| --lookup-groups 	| Lookup group (if doesn't set default is used)  	|      optional     	|

    connect -u user -p password -l localhost:4174 -g mygroup

### initialize [*options*]
Initializes a new gateway. Throws exception, if gateway with the same name was initialized or deployed already.

**Options:**

| Short name    |   Long name   |   Description         |   Optional/Required   |
|:----------:   |:-----------:  |:-------------:        |:------------------:   |
|   -n          | --name        | Gateway site name.    |   optional            |

    initialize -n SITE-1

### configure [*options*]
Configures the gateway component or throws an exception if the gateway wasn't initialized.

**Options:**

Use one of three options to add/remove/modify one of gateway configurations.

| Short name 	|     Long name    	|              Description            |   	
|:----------:	|:----------------:	|:-----------------------------------:|	
|            	| --name 	        | Name of the gateway to configure.   |
|     -a     	| --add 	        | Add to gateway configuration 	      |
|     -r     	| --remove 	        | Remove from gateway configuration   |
|     -m     	| --modify	        | Modify gateway configuration 	      | 

*Delegator options:*

To add/remove delegator use ***-D*** option:

| Short name 	|     Long name    	   |              Description            |  Optional/Required 	| 
|:----------:	|:----------------:	   |:-----------------------------------:|	:-----------------:	|	
|     -D     	| --delegator 	       | Delegator id	                     |  	required        |
|           	| --username           | Username                    	     |      optional        |
|           	| --password           | Password                   	     |      optional        |
|     -c     	| --communication-port | Communication port         	     |      optional        |

    configure SITE-1 -a -D delegator1 --gateway-lookups lookupsId --c 8000

To add/remove target to existing delegator.

| Short name 	|     Long name    	   |              Description            |  Optional/Required 	| 
|:----------:	|:----------------:	   |:-----------------------------------:|	:-----------------:	|	
|     -D     	| --delegator 	       | Delegator id	                     |  	required        |
|            	| --target	           | Target gateway name                 |      required        |

    configure SITE-1 -a -D delegator1 --target SITE-2

*Sink options:*

To add/remove sink  use ***-S*** option:

| Short name 	|     Long name    	   |              Description            |  Optional/Required 	| 
|:----------:	|:----------------:	   |:-----------------------------------:|	:-----------------:	|	
|     -S     	| --sink    	       | Sink id    	                     |  	required        |
|     -c     	| --communication-port | Communication port         	     |      optional        |
|           	| --username           | Username                    	     |      optional        |
|           	| --password           | Password                   	     |      optional        |
|            	| --local-space-url	   | Locasl space url                    |      required        |

        configure SITE-1 -a -S sink1 --c 8000 --local-space-url jini://*/*/wanSpace 

To add/remove source to existing sink.

| Short name 	|     Long name    	   |              Description            |  Optional/Required 	| 
|:----------:	|:----------------:	   |:-----------------------------------:|	:-----------------:	|	
|     -S     	| --sink 	           | Sink id	                         |  	required        |
|            	| --source	           | Source gateway name                 |      required        |

    configure SITE-1 -a -S sink1 --source SITE-2

*Lookup options:*

To add/remove/modify lookup use ***-L*** option.

| Short name 	|     Long name    	       |              Description            |  Optional/Required 	| 
|:----------:	|:----------------:	       |:-----------------------------------:|	:-----------------:	|	
|     -n     	| --remote-gateway-name    | Name of the remote gateway	         |   required           |
|     -c     	| --communication-port     | Communication port         	     |   optional           |
|      -h      	| --host	               | Host name                           |   required           |
|      -d      	|   --discovery-port	   | Discovery port                      |   required           |

    configure SITE-1 -a -L -n SITE2 -h localhost -d 4366 -c 8000

### deploy [*options*]
Deploys gateway processing unit. If --source param is specified then replication gateway bootstrapping process will be executed.

| Short name 	|     Long name         |              Description                                      | Optional/Required  |
|:----------:	|:----------------:     |:-----------------------------------:                          |:-----------------: |
|      -n      	| --name                | Name of the gateway to deploy                                 |   required         |
|      -b      	| --bootstrap-source    | Name of the bootstrap source gateway                          |   optional         |
|      -z      	| --zone                | Name of the required zone for deployment                      |   optional         |
|      -t      	| --bootstrap-timeout   | The number of seconds before a boostrap timeout occurs.       |   optional         |
|            	| --xap9                | Indicates if the resulting gateway should be XAP 9.x or 10.x  |   optional         |


    deploy SITE-1 --source SITE-2

### link [*options*]
Connects the specified space to a deployed gateway at runtime.

| Short name 	|     Long name                 |              Description              |Optional/Required 	|
|:----------:	|:----------------:             |:-----------------------------------:  |:-----------------:	|
|     -a      	| --add                         | Adds the gateway target.              |   required         |
|     -r       	| --remove                      | Removes the gateway target.           |   required         |
|     -n       	| --name                        | Target gateway name.                  |   required         |
|     -s       	| --space-name                  | Target space.                         |   required         |
|     -b       	| --bulk-size                   | Replication bulk size.                |   optional         |
|     -i     	| --idle-time-threshold         | Max milliseconds between replication. |   optional         |
|     -m     	| --max-redo-capacity           | Max redo log count.                   |   optional         |
|     -o     	| --on-capacity-exceeded        | Operation when redo log size exceeded.|   optional         |
|     -c     	| --replicate-change-as-update  | Replicates changes as updates.        |   optional         |

    link --add -n gateway1 -s mySpace1

### disconnect
Exits from gateway configuration CLI.

    disconnect    

    
Example configuration
---
```
connect
initialize -n gigapro-gateway1
configure --name gigapro-gateway1 -a -S sink --local-space-url jini://*/*/space1
configure --name gigapro-gateway1 -a -S sink --source gigapro-gateway2
configure --name gigapro-gateway1 -a -D delegator
configure --name gigapro-gateway1 -a -D delegator --target gigapro-gateway2
configure --name gigapro-gateway1 -a -L -n gigapro-gateway1 -h 127.0.0.1 -d 4174
configure --name gigapro-gateway1 -a -L -n gigapro-gateway2 -h 127.0.0.1 -d 4174
deploy -n gigapro-gateway1 --xap9
disconnect
```

﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GigaSpacesSessionStateProvider
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                DisplaySessionData();
        }

        private void DisplaySessionData()
        {
            foreach (string sessionKey in Session.Keys)
            {
                WriteSessionDataToPage(sessionKey);
            }
        }

        protected void SubmitForm_Click(object sender, EventArgs e)
        {
            Session[SessionKey.Text] = SessionValue.Text;
            DisplaySessionData();
        }

        protected void RemoveKey_Click(object sender, EventArgs e)
        {
            Session.Remove(SessionKey.Text);
            DisplaySessionData();
        }
        private void WriteSessionDataToPage(string sessionKey)
        {
            var row = new TableRow();

            row.Cells.Add(new TableCell { Text = sessionKey });
            row.Cells.Add(new TableCell { Text = Convert.ToString(Session[sessionKey]) });

            sessionData.Controls.Add(row);
        }

    }
}
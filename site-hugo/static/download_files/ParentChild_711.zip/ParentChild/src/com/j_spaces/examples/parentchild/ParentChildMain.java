package com.j_spaces.examples.parentchild;

import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Set;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import net.jini.core.entry.UnusableEntryException;
import net.jini.core.transaction.TransactionException;
import com.gigaspaces.client.ReadByIdsResult;

public class ParentChildMain {

	static GigaSpace space;
	static int max_graphs = 10000;
	static int matching_graphs = 5;

	public static void main(String[] args) {
		try {

			 UrlSpaceConfigurer urlSpaceConfigurer = new UrlSpaceConfigurer("/./mySpace");
			 space = new GigaSpaceConfigurer(urlSpaceConfigurer.space()).gigaSpace();

			System.out.println("Write " + max_graphs+ " parent/child graphs.\nWe will have 2 types of graphs:" +
					"\n" +  matching_graphs+" graphs that got the following values for the child objects:0,1,2,3,4,5,6,7,8,9" +
					"\nand another "  +(max_graphs - matching_graphs) + " graphs with the following values for the child objects:0,10,20,30,40,50,60,70,80,90");
			
			go();
			
		} catch (Exception e) {
			e.printStackTrace();
		}		}

		static public void go() throws Exception
		{
			for (int i = 0; i < max_graphs; i++) {
				Parent parent = new Parent(i +"");
				Child _children[] = new Child[10];
				String _childrenIDs[] = new String[10];
				for (int j = 0; j < 10; j++) {
					_children[j] = new Child(i + "_" + j,parent.getId());
					if (i% (max_graphs/matching_graphs) ==0)
						_children[j].setData(new Long(j));
					else
						_children[j].setData (new Long(j * 10));
						
					_childrenIDs[j] = _children[j].getId();
				}
				parent.setChildrenIDs (_childrenIDs);
				
				space.write(parent);
				space.writeMultiple(_children);
			}

			findMatchingGraph(1,2);
			findMatchingGraph(3,4);
			findMatchingGraph(5,6);
			findMatchingGraph(7,8);
	}

	static void findMatchingGraph(long value1, long value2) throws Exception
	{
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Find all the parent objects that got 2 child objects with values " + value1 +" and " + value2+ "");
		System.out.println("Both child objects have the same parent object");
		Long startTime = System.nanoTime();
		Object childrenResults1[] = findChildrenByValue(new Long(value1));
		Set<String> parentIDs1 = getParentIDsSet(childrenResults1);

		Object childrenResults2[] = findChildrenByValue(new Long(value2));
		Set<String> parentIDs2 = getParentIDsSet(childrenResults2);
		
		Set<String> resultSet = AND(parentIDs1, parentIDs2);

		Parent parents[] = getParentsfromIDs(resultSet);
		Long endTime = System.nanoTime();
		System.out.println(" --->> Found " + parents.length +" matching Parent objects in " + (double)(((double)endTime - (double)startTime)/1000) + " micro second");
		
		for (int i = 0; i < parents.length; i++) {
			System.out.println("Found Parent Object:" + parents[i]
					+ " - ID:" + parents[i].getId() + " - His children objects are:\n\t"
					+ parents[i]._getChildrenDetails(space));
		}
		
	}
		
	static public Object[] findChildrenByValue(Long value) throws RemoteException, TransactionException, UnusableEntryException {
		Child childTemplate = new Child();
		childTemplate.setData(value);
		return space.readMultiple(childTemplate , Integer.MAX_VALUE);
	}
	
	static public Set<String> getParentIDsSet(Object entries[]) {
		HashSet<String> result = new HashSet<String>();
		for (int i = 0; i < entries.length; i++) {
			result.add(((Child) entries[i]).getParentID());
		}
		return result;
	}
	
	static public Parent[] getParentsfromIDs(Set ids) throws UnusableEntryException, RemoteException, TransactionException
	{
		ReadByIdsResult<Parent> parentObjResult = space.readByIds(Parent.class,ids.toArray());
		return parentObjResult.getResultsArray();
	}
	
	// find union between set1 and set2
	static public Set<String> AND(Set<String> set1, Set<String> set2) {
		HashSet<String> result = new HashSet<String>(set1);
		result.retainAll(set2);
		return result;
	}
}

package org.openspaces.riskcalc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoAware;
import org.openspaces.core.cluster.ClusterInfoContext;
import org.openspaces.core.executor.Task;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.client.ReadByIdsResult;
import com.j_spaces.core.client.SpaceURL;

public class AnalysisTask implements Task<HashMap<String, Double>>{

	@TaskGigaSpace
	transient GigaSpace gigaspace;
	Integer[] tradeIds ;
	Integer routing;
	Double rate ;
	
	public AnalysisTask (Integer[] tradeIds,Integer routing, Double rate)
	{
		this.tradeIds = tradeIds;
		this.routing = routing;
		this.rate=rate;
	}
	
	private void runAnalysis(List<Trade> trades, double rate){
		for(Trade t: trades){
			calculateNPV(rate,t);
		}
	}
	
	public HashMap<String, Double> execute() throws Exception {
		int partitionID= Integer.valueOf(gigaspace.getSpace().getURL().getProperty(SpaceURL.CLUSTER_MEMBER_ID)).intValue() - 1;
		System.out.println("Time: " + System.currentTimeMillis()+  " Execute on Partition ID: " +partitionID+" Routing ID:"+ routing);
		HashMap<String, Double> rtnVal = new HashMap<String, Double>();
		//Query Data from the DB
		List<Trade> tradesList = new ArrayList<Trade>();
		try {
			ReadByIdsResult<Trade> res=gigaspace.readByIds(Trade.class, tradeIds);
			
			// checking for null results and getting missing Trades objects from external Data source
			Trade resArr[] = res.getResultsArray();
			ArrayList<Integer> missingIDs = new ArrayList<Integer>();
			for (int i = 0; i < resArr.length; i++) {
				if (resArr [i] == null)
				{
					missingIDs.add(tradeIds[i]);
				}
			}
			Trade missingTrades[] = null;
			if (missingIDs.size() > 0)
			{
				System.out.println(">>>> Partition:"+ partitionID + " - Loading missing Trades from the database for IDs:"+missingIDs);
				missingTrades = getTradesFromDB(missingIDs);
			}
			
			Iterator<Trade> iter = res.iterator();
			// ReadByIdsResult - Holds iterable results of the readByIds operation. 
			// When iterating through the results, null values are skipped. 
			// If you want to access null values, use the getResultsArray() method. 
			// Results are ordered based on the list of Ids provided to the readByIds method.
			while (iter.hasNext())
			{
				tradesList.add(iter.next());
			}
			
			if (missingTrades!=null)
			{
				for (int i = 0; i < missingTrades.length; i++) {
					tradesList.add(missingTrades[i]);
				}
			}
		} catch (Exception e){
			String a = e.getMessage();
			System.out.println(a);
			e.printStackTrace();
		}
		runAnalysis(tradesList,rate);
		
		for(Trade t : tradesList){
			String key = t.getBook();
			if ( rtnVal.containsKey(key)){
				rtnVal.put(key, rtnVal.get(key)+t.getNPV());
			} else {
				rtnVal.put(key,t.getNPV());
			}
		}
		return rtnVal;
	}
	
	private Trade[] getTradesFromDB(ArrayList<Integer> missingIDs)
	{
		Trade[] trades = new Trade[missingIDs.size()];
		int i = 0;
		for (Iterator iterator = missingIDs.iterator(); iterator.hasNext();) {
			Integer id = (Integer) iterator.next();
			trades [i] = generateTrade(id);
			i++;
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		gigaspace.writeMultiple(trades);
		return trades;
	}

	@SpaceRouting
	public Integer getRouting() {
		return routing;
	}

	public void setRouting(Integer routing) {
		this.routing = routing;
	}

	// creating a trade
	Trade generateTrade(int id)
	{
		Trade trade = new Trade();
		trade.setId(id);
		CacheFlowData cf = new CacheFlowData();
		cf.setCacheFlowYear0((double)(id * -100));
		cf.setCacheFlowYear1((double)(id * 20));
		cf.setCacheFlowYear2((double)(id * 40));
		cf.setCacheFlowYear3((double)(id * 60));
		cf.setCacheFlowYear4((double)(id * 80));
		cf.setCacheFlowYear5((double)(id * 100));
		trade.setCacheFlowData(cf);
		return trade;
	}
	
	//calculate Net present value - http://en.wikipedia.org/wiki/Net_present_value
	public void calculateNPV(double rate , Trade trade) {
	    double disc = 1.0/(1.0+(double)(rate/100));
	    CacheFlowData cf =  trade.getCacheFlowData();
	    double NPV = (cf.getCacheFlowYear0() + 
	    		disc*(cf.getCacheFlowYear1() + 
	    		disc*(cf.getCacheFlowYear2() + 
	    		disc*(cf.getCacheFlowYear3() + 
	    		disc*(cf.getCacheFlowYear4() + 
	    		disc*cf.getCacheFlowYear5())))));
	    trade.setNPV(NPV);
	}

}
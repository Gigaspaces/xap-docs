package com.test.eds;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.gigaspaces.datasource.DataIterator;
import com.gigaspaces.datasource.DataProvider;
import com.gigaspaces.datasource.DataSourceException;
import com.gigaspaces.datasource.ManagedDataSource;

public class MyEDS implements DataProvider<MyData> {
	static Logger logger = Logger.getLogger("MyEDS");

	public static void main(String[] args) {
		try {

			GigaSpace spaceNode1 = startClusterNode(1);
			GigaSpace spaceNode2 = startClusterNode(2);
			GigaSpace spaceNode3 = startClusterNode(3);
			
			logger.info("Partition 1 has " + spaceNode1.count(null)
					+ " objects");
			
			logger.info("Partition 2 has " + spaceNode2.count(null)
					+ " objects");

			logger.info("Partition 3 has " + spaceNode3.count(null)
					+ " objects");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public DataIterator<MyData> iterator(MyData query)
			throws DataSourceException {
		logger.info(">> Partition ID:" + partitionID + " EDS-iterator - Need to load data from DB");
		return new MyDataIterator(query);
	}

	public MyData read(MyData query) throws DataSourceException {
		logger.info(">> Partition ID:" + partitionID + " EDS-read ID:"
				+ query.getId());
		return null;
	}

	int partitionID;

	public void init(Properties props) throws DataSourceException {
		logger.info(props.toString());
		partitionID = Integer.valueOf(props.get(ManagedDataSource.STATIC_PARTITION_NUMBER)
								.toString()).intValue();
		logger.info(">> Partition ID:" + partitionID + " EDS-init");
	}

	public DataIterator<MyData> initialLoad() throws DataSourceException {
		logger.info(">> Partition ID:" + partitionID + " EDS-initialLoad");
		List<MyData> initData = new ArrayList<MyData>();

		for (int i=0;i<partitionID*100;i++)
		{
			// load the space with some data
			MyData obj = new MyData();
			obj.setId(  "" + ((partitionID*10000) + i));
			obj.setData("1111111");
			obj.setRouting(partitionID-1);
			initData.add(obj);
		}
		logger.info(">> Partition ID:" + partitionID + " loading "+ initData.size() + " objects into the space");
		return new MyDataIterator(initData);
	}

	public void shutdown() throws DataSourceException {
	}

	static GigaSpace startClusterNode(int id) {
		GigaSpace space = new GigaSpaceConfigurer(new UrlSpaceConfigurer(
				"/./space?cluster_schema=partitioned-sync2backup&total_members=3,0&id="
						+ id)
				.addProperty("space-config.persistent.enabled", "true")
				.addProperty("space-config.engine.cache_policy", "0")
				// LRU
				.addProperty("space-config.external-data-source.usage",
						"read-only")
				.addProperty("space-config.persistent.StorageAdapterClass",
						"com.j_spaces.sadapter.datasource.DataAdapter")
				.addProperty(
						"space-config.external-data-source.data-source-class",
						MyEDS.class.getName())).gigaSpace();
		return space;
	}
}
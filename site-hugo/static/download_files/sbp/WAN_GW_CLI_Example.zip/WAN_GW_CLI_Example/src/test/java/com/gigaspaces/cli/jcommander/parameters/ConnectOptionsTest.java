package com.gigaspaces.cli.jcommander.parameters;

import com.gigaspaces.cli.jcommander.OptionsParser;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by skyler on 5/27/2015.
 */
public class ConnectOptionsTest {
    @Test(expected = IllegalStateException.class)
    public void throwsWhenUserNameIsProvidedButNoPassword() {
        ConnectOptions underTest = new ConnectOptions();
        internalTestWrapper("-u username", underTest);
    }

    @Test(expected = IllegalStateException.class)
    public void throwsWhenPasswordIsProvidedButNoUsername() {
        ConnectOptions underTest = new ConnectOptions();
        internalTestWrapper("-p password", underTest);
    }

    @Test
    public void happyPathConnect() {
        ConnectOptions underTest = new ConnectOptions();
        internalTestWrapper("-u username -p password", underTest);

        assertEquals("username", underTest.getUsername());
        assertEquals("password", underTest.getPassword());
    }

    private void internalTestWrapper(String command, ConnectOptions options){
        OptionsParser optionsParser = new OptionsParser();
        optionsParser.parse(command.split(" "), options);
    }
}

package example.syncremoting;

import java.util.concurrent.atomic.AtomicInteger;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.context.GigaSpaceLateContext;

import example.syncremoting.common.Account;
import example.syncremoting.common.AccountQuery;
import example.syncremoting.common.ApprovedAccountRecord;

public class AccountQueryImpl implements AccountQuery{
    @GigaSpaceLateContext
	private GigaSpace space;	
	
	public Integer getNumberOfApprovedAccountsByZipCode(String zipCode) {
		AtomicInteger accountCounter=new AtomicInteger();
		Account zipCodeAccountTemplate = new Account();
		zipCodeAccountTemplate.setZipCode(zipCode);
		Object[] accountResults=space.readMultiple(zipCodeAccountTemplate, 100000);
		int accountResultsLength=accountResults.length;
		ApprovedAccountRecord[] approvedAccountRecords =new ApprovedAccountRecord[accountResultsLength];
		for(int x=0;x<accountResultsLength;x++){
			Account account = (Account)accountResults[x];
			ApprovedAccountRecord template = new ApprovedAccountRecord();
			template.setAccountID(account.getId());			
			approvedAccountRecords[x]=space.read(template);
			if(approvedAccountRecords[x]!=null){
				accountCounter.incrementAndGet();
			}
		}
		System.out.println("responding to query with "+approvedAccountRecords.length);
		return new Integer(accountCounter.get());
	}

}

package example.eventremoting.common;

import java.util.concurrent.Future;

public interface SimpleService {
    public String say(String message,int invocationNumber);
    public Future<String> asyncSay(String message , int invocationNumber);
}

package com.gigaspaces.util.mirror.monitor;

import java.lang.management.ManagementFactory;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.space.Space;
import org.openspaces.admin.space.SpacePartition;
import org.openspaces.admin.space.events.SpaceModeChangedEventManager;
import org.openspaces.persistency.hibernate.DefaultHibernateExternalDataSource;
import com.gigaspaces.datasource.BulkItem;
import com.gigaspaces.datasource.DataIterator;
import com.gigaspaces.datasource.DataSourceException;

public class Mirror extends DefaultHibernateExternalDataSource {
	public Mirror (){}
	
	DecimalFormat DEC_FORMAT;
	int REPORT_SAMPLING_INTERVAL =10000;
	MirrorStats stats;

	String spaceUrl;
	String gropus;
	String locators;
	MBeanServer mbs ;
	ObjectName statsMeabnName ;
	SpaceModeListener spaceModeListener;
	String spaceName;
	SpaceModeChangedEventManager modeManager;
	boolean displayStats = false;
	boolean debug = false;
	boolean ide = false;
	
	public boolean isDisplayStats() {
		return displayStats;
	}

	public void setDisplayStats(boolean displayStats) {
		this.displayStats = displayStats;
	}

	public String getSpaceName() {
		return spaceName;
	}

	public void setSpaceName(String spaceName) {
		this.spaceName = spaceName;
	}

	long lastReading = System.currentTimeMillis();
	public void executeBulk(List<BulkItem> bulk) throws DataSourceException {
		if (!debug) super.executeBulk(bulk);
		collectStats(bulk);
		if (displayStats) 
			showStats(bulk);
	}
	
	void collectStats(List<BulkItem> bulk)
	{
		Iterator<BulkItem> iter = bulk.iterator();
		while(iter.hasNext())
		{
			BulkItem item = iter.next();
			int operation = item.getOperation();
			stats.globalCounter.incrementAndGet();
			
			switch (operation ) {
			case BulkItem.REMOVE:
			{
				stats.counterTake.incrementAndGet();
				break;
			}
			case BulkItem.UPDATE:
			{
				stats.counterUpdate.incrementAndGet();
				break;
			}
			case BulkItem.WRITE:
			{
				stats.counterWrite.incrementAndGet();
				break;
			}
			default:
				break;
			}
		}
	}
	
	void showStats(List<BulkItem> bulk)
	{
		int _count = stats.globalCounter.get();
		if (_count % REPORT_SAMPLING_INTERVAL ==0)
		{
			long currentTime = System.currentTimeMillis();
			double interval = (double) (currentTime - lastReading)/1000;
			double currentGlobalTP  = (double)(REPORT_SAMPLING_INTERVAL/interval);
			
			System.out.println(new Date (currentTime)+ 
					" Mirror - Total TP:"+ DEC_FORMAT.format(currentGlobalTP) +
					" C:"+  _count+		
					" W C:"+  stats.counterWrite.get()+		
					" U C:"+ stats.counterUpdate.get() +
					" T C:"+ stats.counterTake.get()	+
					" W TP:"+ DEC_FORMAT.format(stats.getWriteTP()) +		
					" U TP:"+ DEC_FORMAT.format(stats.getUpdateTP()) +		
					" T TP:"+ DEC_FORMAT.format(stats.getTakeTP())	
			);
			
			lastReading = currentTime;
		}
		
	}
	
	@Override
	public void init(Properties props) throws DataSourceException {
		if (!debug) super.init(props);
		System.out.println("Mirror started!");
    	DEC_FORMAT = new DecimalFormat();
    	DEC_FORMAT.setMaximumFractionDigits(1);

    	System.out.println("---- > Display Stats:" + displayStats);
    	Admin admin = null;
    	
    	if (ide)
    		admin = new AdminFactory().discoverUnmanagedSpaces().createAdmin();
    	else
    		admin = new AdminFactory().createAdmin();
    	
    	if (admin==null)
    	{
    		System.err.println(" ------> " +  " Can't locate admin");
    		throw new RuntimeException("Can't locate admin");
    	}
	
    	Space space = admin.getSpaces().waitFor(spaceName, 10, TimeUnit.SECONDS);

    	if (space==null)
    	{
    		System.err.println(" ------> " +  " Can't locate space " + spaceName);
    		throw new RuntimeException("Can't locate space " + spaceName);
    	}

    	SpacePartition partitions[]= space.getPartitions();
    	
		try {

			stats = new MirrorStats(partitions);
	    	modeManager =  space.getSpaceModeChanged();
	    	spaceModeListener = new SpaceModeListener(space, stats);
	    	modeManager.add(spaceModeListener);

			mbs = ManagementFactory.getPlatformMBeanServer();

			// Construct the ObjectName for the MBean we will register
			statsMeabnName = new ObjectName(Mirror.class.getPackage().getName()+ ":type=MirrorStats");
			mbs.registerMBean(stats,statsMeabnName );
		} catch (Exception e) {
			e.printStackTrace();
    		throw new RuntimeException(e.getMessage());
		}
	}
	@Override
	public DataIterator initialLoad() throws DataSourceException {
		if (!debug) 
			return super.initialLoad(); 
		else 
			return null;
	}
	
	@Override
	public void shutdown() throws DataSourceException {
		if (!debug) 
			super.shutdown();
		try {
			mbs.unregisterMBean(statsMeabnName);
		} catch (InstanceNotFoundException e) {
			e.printStackTrace();
		} catch (MBeanRegistrationException e) {
			e.printStackTrace();
		}
	}

	public String getSpaceUrl() {
		return spaceUrl;
	}

	public void setSpaceUrl(String spaceUrl) {
		this.spaceUrl = spaceUrl;
	}

	public boolean isIde() {
		return ide;
	}

	public void setIde(boolean ide) {
		this.ide = ide;
	}

	public boolean isDebug() {
		return debug;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}
}

package com.gigaspaces.domain;

public enum OrderType {

	VIP,	/* High Valued Order */ 
	NORMAL, /* Average valued Order */
	LOW;	/* Low valued Order  */
}

package com.gs.util;

import java.rmi.RemoteException;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoContext;
import org.openspaces.core.context.GigaSpaceContext;
import org.openspaces.remoting.RemotingService;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.admin.IRemoteJSpaceAdmin;
import com.j_spaces.core.admin.SpaceRuntimeInfo;

@RemotingService
public class DataProcessorService implements IDataProcessor {

	@ClusterInfoContext
	public ClusterInfo clusterInfo;

	@GigaSpaceContext
	transient GigaSpace gigaSpace;
	
    public PartitionCount processData() {
    	

		Integer totalCount = 0;
		IJSpace ijs = gigaSpace.getSpace();
		PartitionCount pc = new PartitionCount();
		pc.setCount(0);
		pc.setPartitionId(0);
		
		//pc.setPartitionId(clusterInfo.getInstanceId());

		try {
			IRemoteJSpaceAdmin spaceAdmin = (IRemoteJSpaceAdmin) ijs.getAdmin();

			SpaceRuntimeInfo rtInfo = spaceAdmin.getRuntimeInfo();

			for (int i = 0; i < rtInfo.m_ClassNames.size(); i++) {

				String className = rtInfo.m_ClassNames.get(i);
				Integer count = rtInfo.m_NumOFEntries.get(i);

				System.out.println("ClassName: " + className
						+ ", number of entries: " + count);

				totalCount += rtInfo.m_NumOFEntries.get(i);
			}
			pc.setCount(totalCount);
			pc.setPartitionId(clusterInfo.getInstanceId());

		} catch (RemoteException e) {
			e.printStackTrace();
		}

		return pc;

	}
}	

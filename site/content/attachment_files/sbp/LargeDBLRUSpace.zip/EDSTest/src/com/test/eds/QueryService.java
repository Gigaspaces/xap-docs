package com.test.eds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;
import com.gigaspaces.async.AsyncFuture;
import com.j_spaces.core.client.SQLQuery;
/*
 * This service designed to execute queries based on a pre-defined strategy when running in LRU mode.
 * The main goal when choosing a query execution strategy is to reduce the DB access.
 * This query service support several query execution strategies designed to reuse the data in memory in maximal manner. 
 */
public class QueryService {
	static Logger logger = Logger.getLogger("QueryService");

	public enum QueryStrategy {
		// Retrieve result set objects in an ordered manner , first from the partition with the highest amount of matching objects
//		HIGHEST ,
		
		// start retrieve objects from a partition picked up in a round robin manner
//		ROUND_ROBIN,
		
		// Retrieve result set objects from all partitions in parallel. 
		// Each partition retrieve a portion of the data
		BORADCAST ,
	
//		DIRECTLY_FROM_DB 
	}

	public QueryService (GigaSpace gigaspace , SQLQuery<MyData> query,int maxObjects ,QueryStrategy queryStrategy)
	{
		this.gigaspace=gigaspace;
		this.query=query;
		this.maxObjects=maxObjects;
		this.queryStrategy=queryStrategy;
	}
	
	SQLQuery<MyData> query;
	int maxObjects;
	GigaSpace gigaspace;
	QueryStrategy queryStrategy;
	
	public MyData[] executeQuery()
	{
		logger.info(">>>>>>> The Query Select * from MyData "+ query.getQuery() + " - max object to retrieve: "+maxObjects );
		MyData[] retArray = null;
		switch (queryStrategy) {
			case BORADCAST :
			{
				// get query result count from each partition 
				CountTask countTask = new CountTask(query.getQuery());
				AsyncFuture<List<QuerySubResult>> resultsCountFuture = gigaspace.execute(countTask);
				List<QuerySubResult> resultsCount= null;
				try {
					resultsCount = resultsCountFuture.get();
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				} catch (ExecutionException e1) {
					e1.printStackTrace();
				}

				// sort and get the results from the one with the highest amount of objects first
				Iterator<QuerySubResult> keysPartitionInfoIterator = resultsCount.iterator();
				int totalResultSetCount =0; 
				// GetTotalCount
				// search if there is one partition with enough matching results
				List <QuerySubResult> querySubResultsList = new ArrayList<QuerySubResult>();
				QuerySubResult partitionWithEnoughMatchingResults=null;
				while (keysPartitionInfoIterator.hasNext())
				{
					QuerySubResult partitionInfo = keysPartitionInfoIterator.next();
					int partitionID = partitionInfo.getPartitionID();
					int resultSetCount = partitionInfo.getResultSetSize();
					querySubResultsList.add(new QuerySubResult(resultSetCount ,partitionID));
					totalResultSetCount = totalResultSetCount+resultSetCount; 
					
					if (resultSetCount >= maxObjects)
					{
						partitionWithEnoughMatchingResults= new QuerySubResult(partitionInfo.getResultSetSize(),partitionInfo.getPartitionID());
						break;
					}
				}
				Collections.sort(querySubResultsList , new QueryResultComparator());
				
				boolean getDataFromDB = false;
				if (totalResultSetCount<maxObjects)
				{
					// we need to get more than what we have in memory
					getDataFromDB  = true;
					logger.info("Get Data from DB");
				}
				else
				{
					logger.info("Get Data from Memory Only");					
				}
				totalResultSetCount=0; 

				List <MyData> totalResult = new ArrayList<MyData> ();
				if (partitionWithEnoughMatchingResults!=null)
				{
					logger.info("We have one partition with enough results - fetch only from a partition " + partitionWithEnoughMatchingResults.getPartitionID() + " it has "+partitionWithEnoughMatchingResults.getResultSetSize() + " matching object");					
					// fetch from a single partition
					AsyncFuture<QuerySubResult> subResultFuture = gigaspace.execute(new SinglePartitionQueryTask(query.getQuery(),partitionWithEnoughMatchingResults.getResultSetSize()) , partitionWithEnoughMatchingResults.getPartitionID()-1);
					QuerySubResult subResult = null;
					try {
						subResult = subResultFuture.get();
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
					MyData partitionResult[] = subResult.getResultSet();
					int objCount=0;
					for (int i=0;i<partitionResult.length;i++)
					{
						totalResult.add(partitionResult[i]);
						objCount ++;
						// we got all what we need. Done.
						if (objCount == maxObjects)
							break;
					}
				}
				else
				{
					logger.info("fetching from multiple partitions");
					keysPartitionInfoIterator = resultsCount.iterator();
					List<AsyncFuture<QuerySubResult>> queryResults = new ArrayList<AsyncFuture<QuerySubResult>>();
					while (keysPartitionInfoIterator.hasNext())
					{
						QuerySubResult partitionInfo= keysPartitionInfoIterator.next();
						int partitionID = partitionInfo.getPartitionID();
						int resultSetCount = partitionInfo.getResultSetSize();
						totalResultSetCount = totalResultSetCount+resultSetCount; 
						
						logger.info("partitionID:" + partitionID + " resultSetCount :"+resultSetCount );
						int partitionMaxObjects = Integer.MAX_VALUE;
						if (!getDataFromDB)
							partitionMaxObjects = resultSetCount;
						
						AsyncFuture<QuerySubResult> subResult = gigaspace.execute(new SinglePartitionQueryTask(query.getQuery(),partitionMaxObjects ) , partitionID -1);
						queryResults.add(subResult);
						
						if (totalResultSetCount>=maxObjects)
						{
							// we should have enough results.
							break;
						}
					}
					int objCount=0;
					Iterator<AsyncFuture<QuerySubResult>> resultIterator = queryResults.iterator();
					while (resultIterator.hasNext())
					{
						AsyncFuture<QuerySubResult> subResultFuture = resultIterator.next();
						try {
							QuerySubResult subResult = subResultFuture.get();
							MyData partitionResult[] = subResult.getResultSet();
							for (int i=0;i<partitionResult.length;i++)
							{
								totalResult.add(partitionResult[i]);
								objCount ++;
								// we got all what we need. Done.
								if (objCount == maxObjects)
									break;
							}
						} catch (InterruptedException e) {
							e.printStackTrace();
						} catch (ExecutionException e) {
							e.printStackTrace();
						}
					}
					
				}
				retArray = new MyData[totalResult.size()];
				retArray = totalResult.toArray(retArray);
			}
		}
		return retArray;
	}
}
package com.test;


import java.util.concurrent.TimeUnit;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.space.Space;
import org.openspaces.admin.space.events.SpaceModeChangedEventManager;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.SpaceProxyConfigurer;

import com.gigaspaces.annotation.SupportCodeChange;
import com.gigaspaces.async.AsyncFuture;

public class MainSpaceDataEventListener {

	public static void main(String[] args) throws Exception{
		System.out.println("MainSpaceDataEventListener started");
		String spaceName = "space";
		GigaSpace gigaSpace = new GigaSpaceConfigurer(new SpaceProxyConfigurer(spaceName)).gigaSpace();
		
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().createAdmin();
		Space space = admin.getSpaces().waitFor(spaceName, 10, TimeUnit.SECONDS);
		SpaceModeChangedEventManager modeManager =  space.getSpaceModeChanged();
		SpaceModeListener spaceModeListener = new SpaceModeListener (space);
		modeManager.add(spaceModeListener);
		while(true)
		{
			Thread.sleep(1000);
			System.out.print(".");
		}
		
//		admin.close();
	}
}

using System;

namespace GigaSpaces.Examples.ExcelStocks.Feeder
{
	/// <summary>
	/// Stock market simulation. 
	/// The list of stocks we work with and the initial "Open" values
	/// </summary>
	public class InitialStock
	{		
		private readonly string _name;
		private readonly double _openingValue;

		public InitialStock(string name, double openingValue)
		{
			this._name = name;
			this._openingValue = openingValue;
		}

		public string Symbol
		{
			get { return _name; }				
		}

		public double OpeningValue
		{
			get { return _openingValue; }
		}
	

		public static InitialStock[] InitialStocks = new InitialStock[]
		                                             	{
		                                             		new InitialStock("GIGS", 100.1),
		                                             		new InitialStock("MSFT", 21.5),
		                                             		new InitialStock("IBM", 87.75),
		                                             		new InitialStock("JAVA", 4.8),
		                                             		new InitialStock("GOOG", 332),
		                                             		new InitialStock("YHOO", 12.29),
		                                             		new InitialStock("DELL", 13.29),
		                                             		new InitialStock("INFY", 23.91),
		                                             		new InitialStock("HPQ", 37),
		                                             		new InitialStock("AAPL", 96.8),
		                                             		new InitialStock("BEAS", 9.1),
		                                             		new InitialStock("SAP", 33.87),
		                                             		new InitialStock("ORCL", 16.68),
		                                             		new InitialStock("CA", 15.84),
		                                             		new InitialStock("RHT", 12.80),
		                                             	};		
	}
}

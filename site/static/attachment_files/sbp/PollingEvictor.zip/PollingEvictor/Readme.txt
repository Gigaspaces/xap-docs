Extract the archive into a folder

Navigate to the folder 

Run maven clean using following command
mvn clean

Run maven package (skip the tests) using following command
mvn package -DskipTests

Start an instance of gs-agent using the script inside GigaSpacesRoot/bin/gs-agent.bin(sh)

Deploy the application using following command
mvn os:deploy -Dmodule=pollingEvictor

Invoke a gs-ui session to monitor the space. 

Also Launch a JConsole session for the space that just started.

Run the test client using the following command
mvn exec:java -Dexec.classpathScope=compile -Dexec.mainClass="com.gigaspaces.client.TestClient" -Dexec.args="jini://*/*/mySpace" 

Start monitoring the JVM Tenured pool in JConsole and GSC logs. After few seconds you will see that the memory thresohold is breached and eviction logic will trigger and clear the old order objects from space. Once the memory usage reached the eviction stop limit, eviction logic stops.
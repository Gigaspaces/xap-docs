package com.gigaspaces.cli.exception;


public class DelegatorException extends RuntimeException {

    public DelegatorException() {
    }

    public DelegatorException(String message) {
        super(message);
    }

    public DelegatorException(String message, Throwable cause) {
        super(message, cause);
    }

    public DelegatorException(Throwable cause) {
        super(cause);
    }

    public DelegatorException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

package com.gigaspaces.cli.jcommander;

public enum Commands {
    CONFIGURE, DEPLOY, DISCONNECT, INITIALIZE, LINK, BOOTSTRAP, CONNECT
}


package org.openspaces.calcengine;

import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

public class StartCluster {
	static Logger logger = Logger.getLogger("StartCluster");
	static int MAX_PARTITIONS = 4;

	public static void main(String[] args) {
		try {
			
			GigaSpace spaceNodes[] = new GigaSpace [MAX_PARTITIONS];
			for (int i=0;i<MAX_PARTITIONS;i++)
			{
				spaceNodes[i] = startClusterNode(i);
			}
			
			for (int i=0;i<MAX_PARTITIONS;i++)
			{	
				logger.info("Partition " + i + " has " + spaceNodes[i].count(null)+ " objects");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static GigaSpace startClusterNode(int id) {
		id = id+1;
		GigaSpace space = new GigaSpaceConfigurer(new UrlSpaceConfigurer(
				"/./CalcDataGrid?cluster_schema=partitioned-sync2backup&total_members="+MAX_PARTITIONS+",0&id="+ id)).gigaSpace();
		return space;
	}
}
package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.Options;

/**
 * Created by skyler on 5/27/2015.
 */
public interface Operation<T extends Options> {
    public void run(T options, CliGatewayContext context);
}

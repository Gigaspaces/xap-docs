package com.gigaspaces.springbatch;

import com.gigaspaces.annotation.pojo.FifoSupport;
import com.gigaspaces.annotation.pojo.SpaceClass;

@SpaceClass(fifoSupport=FifoSupport.ALL)
public class ItemRequest extends ItemBase{

	public ItemRequest ()
	{
	}
	
	void execute(){};
	
}

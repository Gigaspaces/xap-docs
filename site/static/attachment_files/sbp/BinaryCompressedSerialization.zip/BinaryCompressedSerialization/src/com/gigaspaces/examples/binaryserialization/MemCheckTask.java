package com.gigaspaces.examples.binaryserialization;

import java.util.List;

import org.openspaces.core.executor.DistributedTask;

import com.gigaspaces.async.AsyncResult;

public class MemCheckTask implements DistributedTask<Long,Long>{

	public Long execute() throws Exception {
		System.out.println("----------- checking memory ----------- ");
	    MemChecker mc = new MemChecker();
	    return mc.check();
	}

	public Long reduce(List<AsyncResult<Long>> results) throws Exception {
		long total = 0;
		for (int i=0;i<results.size();i++)
		{
			total += (Long)results.get(i).getResult();
		}
		System.out.println("----------- used memory: " + (double)total /(double)(1024*1024) +  " MB ----------- ");
		return total ;
	}
}


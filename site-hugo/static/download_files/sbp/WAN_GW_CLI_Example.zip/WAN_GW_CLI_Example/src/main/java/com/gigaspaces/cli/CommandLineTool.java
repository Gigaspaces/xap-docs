package com.gigaspaces.cli;

import com.gigaspaces.cli.jcommander.Commands;
import com.gigaspaces.cli.jcommander.OptionsParser;
import com.gigaspaces.cli.jcommander.parameters.*;
import com.gigaspaces.cli.operations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CommandLineTool {

    private static Logger logger = LoggerFactory.getLogger("Gateway-CLI");

    private static OptionsParser parser = new OptionsParser();

    private static CliGatewayContext context = new CliGatewayContext();

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        logger.info("Waiting for operations");
        try {
            readOperations(sc);
        } catch (NoSuchElementException ex){
            logger.debug("Application terminated by the user.");
        } catch (Exception ex){
            logger.warn("Exception encountered.", ex);
        }

        System.exit(0);
    }

    private static void readOperations(Scanner sc) {
        boolean connected = true;
        while (connected) {

            String[] arguments = parser.createArguments(sc.nextLine());

            String stage = arguments[0];
            String[] argsToParse = Arrays.copyOfRange(arguments, 1, arguments.length);
            switch (Commands.valueOf(stage.toUpperCase())){
                case DISCONNECT: {
                    logger.debug("DISCONNECT");
                    connected = false;
                    break;
                }
                case CONNECT: {
                    operate("CONNECT", argsToParse, new ConnectOptions(), new ConnectOperation());
                    break;
                }
                case INITIALIZE: {
                    operate("INITIALIZE", argsToParse, new InitializeOptions(), new InitializeOperation());
                    break;
                }
                case CONFIGURE: {
                    operate("CONFIGURE", argsToParse, new ConfigureOptions(), new ConfigureOperation());
                    break;
                }
                case DEPLOY: {
                    operate("DEPLOY", argsToParse, new DeployOptions(), new DeployOperation());
                    break;
                }
                case BOOTSTRAP: {
                    operate("BOOTSTRAP", argsToParse, new BootstrapOptions(), new BootstrapOperation());
                    break;
                }
                case LINK: {
                    operate("LINK SPACE", argsToParse, new LinkSpaceOptions(), new LinkSpaceOperation());
                    break;
                }
            }
        }
    }

    private static <T extends Options, T1 extends Operation<T>> void operate(String logText, String[] args, T options, T1 operation) {
        parser.parse(args, options);

        logger.debug(logText + ": " + options.toString());
        operation.run(options, context);
    }
}

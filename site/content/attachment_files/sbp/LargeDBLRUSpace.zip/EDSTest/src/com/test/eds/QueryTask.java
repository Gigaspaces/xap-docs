package com.test.eds;

import java.util.ArrayList;
import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.executor.DistributedTask;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.async.AsyncResult;
import com.j_spaces.core.client.SQLQuery;
import com.j_spaces.core.client.SpaceURL;

public class QueryTask implements DistributedTask<QuerySubResult, MyData[]>{

	@TaskGigaSpace
	transient GigaSpace gigaspace;
	
	String queryStr ;
	int maxObjects;

	public QueryTask (String query,int _maxObjects)
	{
		this.queryStr=query ;
		this.maxObjects=_maxObjects;
	}
	
	public QuerySubResult execute() throws Exception {
		int partitionID= Integer.valueOf(gigaspace.getSpace().getURL().getProperty(SpaceURL.CLUSTER_MEMBER_ID)).intValue();
		System.out.println("Partition ID: " +partitionID);
		SQLQuery<MyData> query = new SQLQuery<MyData>  (MyData.class , queryStr);
		MyData[] ret;
		if (gigaspace.count(query) <= maxObjects)
		{
			//Query Data only from the space
			ret = gigaspace.readMultiple(query, maxObjects);
		}
		else
		{
			//Query Data from the DB
			ret = gigaspace.readMultiple(query, Integer.MAX_VALUE);
		}
		QuerySubResult subResult = new QuerySubResult(ret,partitionID);
		return subResult;
	}

	public MyData[] reduce(List<AsyncResult<QuerySubResult>> result) throws Exception {
		System.out.println(this.getClass().getName() + " - reduce is called");
		List<MyData> totalResult = new ArrayList<MyData> ();
		for (AsyncResult<QuerySubResult> asyncResult : result) {
			MyData[] ret= asyncResult.getResult().getResultSet();
			for (int i=0;i<ret.length;i++)
			{
				totalResult.add(ret[i]);
			}
		}
		return totalResult.toArray( new MyData[totalResult.size()]);
	}
}
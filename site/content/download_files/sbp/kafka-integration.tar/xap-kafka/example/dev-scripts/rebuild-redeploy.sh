#!/bin/bash

source ./rebuild.sh
source ./redeploy.sh

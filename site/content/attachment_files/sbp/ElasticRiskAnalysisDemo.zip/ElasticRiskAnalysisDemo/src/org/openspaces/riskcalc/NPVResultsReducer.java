package org.openspaces.riskcalc;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gigaspaces.async.AsyncResult;
import com.gigaspaces.async.AsyncResultsReducer;

public class NPVResultsReducer implements AsyncResultsReducer<HashMap<String, Double>, HashMap<String, Double>>{

	@Override
	// we are getting HashMap<String, Double> from eac AnalysisTask execute() 
	public HashMap<String, Double> reduce(List<AsyncResult<HashMap<String, Double>>> result) throws Exception {

		HashMap<String, Double> aggregatedNPVCalc = new HashMap<String, Double>();
		
		for (AsyncResult<HashMap<String, Double>> asyncResult : result) {
			HashMap<String, Double> incPositions = asyncResult.getResult();
			subreducer(aggregatedNPVCalc , incPositions);
		}
		return aggregatedNPVCalc ;
	}

	private void subreducer(Map<String, Double> aggregatedNPVCalc, Map<String, Double> incPositions){
		for (String key : incPositions.keySet())
		{
			if (aggregatedNPVCalc.containsKey(key)){
				double currentNPV = aggregatedNPVCalc.get(key);
				aggregatedNPVCalc.put(key, currentNPV + incPositions.get(key));
			} else {
				aggregatedNPVCalc.put(key, incPositions.get(key));
			}
		}
	}
}

package com.epam.openspaces.persistency.kafka.protocol;

/**
 * Message Key of XAP-Kafka protocol
 *
 * @author Oleksiy_Dyagilev
 */
public interface AbstractKafkaMessageKey {
}

package com.eauction.gigaspaces.loadbalancer.apache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * Holds information on all the different load balancer nodes (web processing unit instances).
 *
 * @author kimchy
 */
public class LoadBalancerInfo {
    private final String name;
    private final Map<String, LoadBalancerNodeInfo> balancers = new ConcurrentHashMap<String, LoadBalancerNodeInfo>();
    private volatile boolean dirty = true;

    public LoadBalancerInfo(String name) {
        this.name = name;
    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    /**
     * Returns the name of the web application processing unit.
     */
    public String getName() {
        return name;
    }

    public void putNode(LoadBalancerNodeInfo balancerInfo) {
        balancers.put(balancerInfo.getUid(), balancerInfo);
    }

    public void removeNode(LoadBalancerNodeInfo balancerInfo) {
        balancers.remove(balancerInfo.getUid());
    }

    /**
     * Returns all the nodes of the web application.
     */
    public LoadBalancerNodeInfo[] getNodes() {
        return balancers.values()
                        .toArray(new LoadBalancerNodeInfo[balancers.values()
                                                                   .size()]);
    }
}

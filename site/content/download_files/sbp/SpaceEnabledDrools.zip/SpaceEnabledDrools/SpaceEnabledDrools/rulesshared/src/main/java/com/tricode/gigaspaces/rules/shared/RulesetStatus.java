package com.tricode.gigaspaces.rules.shared;

/**
 * Status of a Ruleset. By default it is UNPROCESSED, but when the RulesCompiler is done with it
 * the state changes to COMPILED or EXCEPTION.
 */
public enum RulesetStatus {
    UNPROCESSED,
    COMPILED,
    EXCEPTION

}
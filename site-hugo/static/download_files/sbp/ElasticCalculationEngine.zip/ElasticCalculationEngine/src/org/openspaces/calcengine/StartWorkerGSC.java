package org.openspaces.calcengine;

import java.util.concurrent.TimeUnit;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.gsa.GridServiceAgent;
import org.openspaces.admin.gsa.GridServiceContainerOptions;

public class StartWorkerGSC {

	static String locators = System.getProperty("locators", "127.0.0.1");
	public static void main(String[] args) throws Exception{
		
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().addLocator(locators).createAdmin();

		if (admin == null)
		{
			System.out.println("Can locate lookup service and generate admin object. Exit");
			System.exit(0);
		}
		System.out.println("About to start a GSC for worker");
		
		GridServiceContainerOptions gscOptions = new GridServiceContainerOptions();
		gscOptions.vmInputArgument("-Dcom.gs.zones=worker");
		gscOptions.vmInputArgument("-Xmx64m");
		
		admin.getGridServiceAgents().waitFor(1, 10, TimeUnit.SECONDS);
		
		GridServiceAgent agent=admin.getGridServiceAgents().getAgents()[0];
		
		System.out.println("Agent running on: " + agent.getOperatingSystem().getDetails().getHostName());
		agent.startGridService(gscOptions);
		System.out.println("started GSC for worker");
		admin.close();
	}
}

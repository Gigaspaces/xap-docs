package com.gigaspaces.cli.task;

import com.gigaspaces.async.AsyncResult;
import com.gigaspaces.internal.client.spaceproxy.IDirectSpaceProxy;
import com.gigaspaces.internal.cluster.node.IReplicationNodeAdmin;
import com.gigaspaces.internal.cluster.node.impl.config.DynamicSourceGroupConfigHolder;
import com.gigaspaces.internal.server.space.SpaceImpl;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.executor.DistributedTask;
import org.openspaces.core.executor.TaskGigaSpace;

import java.util.*;

public class CollectTargetsTask implements DistributedTask<ArrayList<String>, Set<String>> {

    @TaskGigaSpace
    private transient GigaSpace gigaSpace;

    @Override
    public ArrayList<String> execute() throws Exception {
        IDirectSpaceProxy directProxy = gigaSpace.getSpace().getDirectProxy();
        SpaceImpl space = directProxy.getSpaceImplIfEmbedded();
        IReplicationNodeAdmin replicationNodeAdmin = space.getEngine().getReplicationNode().getAdmin();
        String groupName = space.getEngine().generateGroupName();
        DynamicSourceGroupConfigHolder groupConfig = replicationNodeAdmin.getSourceGroupConfigHolder(groupName);
        String[] membersLookupNames = groupConfig.getConfig().getMembersLookupNames();
        return new ArrayList<>(Arrays.asList(membersLookupNames));
    }

    @Override
    public Set<String> reduce(List<AsyncResult<ArrayList<String>>> asyncResults) throws Exception {
        Set<String> result = new HashSet<>();
        for (AsyncResult<ArrayList<String>> async : asyncResults){
            ArrayList<String> targets = async.getResult();
            for (String target : targets){
                if (target.startsWith("gateway")){
                    result.add(target);
                }
            }
        }
        return result;
    }

}

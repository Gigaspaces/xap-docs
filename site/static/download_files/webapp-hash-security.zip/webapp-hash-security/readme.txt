=================================================
=== OpenSpaces Plain Web Application Example  ===
=================================================

*********************************************************************************************
* FOR COMPLETE DOCUMENTATION OF THIS EXAMPLE PLEASE REFER TO THE StartHere.html FILE UNDER  * 
* <GIGASPACES ROOT>/examples/web or online at                                               *
* http://www.gigaspaces.com/wiki/display/XAP71/Scaling+Your+Web+Application                  *
*********************************************************************************************


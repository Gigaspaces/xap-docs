package com.tricode.gigaspaces.rules.space.drools.loader;

import org.drools.definition.KnowledgePackage;

import java.util.Collection;

/**
 * Implementations of this interface should load a set of (serialized) KnowledgePackage objects
 */
public interface IDroolsRuleLoader {

    /**
     * Loads knowledge packages matching projectname and ruleset name.
     *
     * @param projectName The name of a project.
     * @param rulesetName The name of a ruleset.
     * @return All knowledge packages for this project and rule set.
     */
    Collection<KnowledgePackage> getKnowledgePackages(String projectName, String rulesetName);

    /**
     * Loads knowledge packages matching projectname.
     *
     * @param projectName The name of a project.
     * @return All knowledge packages for this project.
     */
    Collection<KnowledgePackage> getKnowledgePackages(String projectName);

}
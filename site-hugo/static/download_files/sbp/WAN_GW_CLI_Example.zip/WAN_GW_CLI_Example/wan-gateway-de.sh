connect -g pavlo
initialize -n DE
configure --name DE -a -S sink --local-space-url jini://*/*/wanSpaceDE
configure --name DE -a -S sink --source US
configure --name DE -a -D delegator
configure --name DE -a -D delegator --target US
configure --name DE -a -L -n DE -h 127.0.0.1 -d 4174
configure --name DE -a -L -n US -h 127.0.0.1 -d 4174
deploy -n DE
disconnect


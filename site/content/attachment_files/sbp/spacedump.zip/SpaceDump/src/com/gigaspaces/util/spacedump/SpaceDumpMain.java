package com.gigaspaces.util.spacedump;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.space.SpaceInstance;
import org.openspaces.admin.space.SpacePartition;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.gigaspaces.cluster.activeelection.SpaceMode;
import com.j_spaces.core.SpaceCopyStatus;
import com.j_spaces.core.admin.IRemoteJSpaceAdmin;

public class SpaceDumpMain {

	
	static Logger log = Logger.getLogger("SpaceDump");
	static String OPERATION_DUMP = "dump";
	static String OPERATION_RELOAD = "reload";
	
	static Admin admin = null;
	static GigaSpace sourceSpace = null; 
	public static void main(String[] args) throws Exception{
		
		printUsage();
		String lookupLocator ="localhost";
		String operation =OPERATION_DUMP;
		String spaceName ="mySpace";
		
		if (args.length>0)
		{
			lookupLocator = args[0];
		}
		
		if (args.length>1)
		{
			operation = args[1];
			if ((!operation.equals(OPERATION_DUMP)) & (!operation.equals(OPERATION_RELOAD))) 			
			{
				log.info("Wrong operation - exit!");
				System.exit(0);
			}
		}

		if (args.length>2)
		{
			spaceName = args[2];
		}

		sourceSpace = new GigaSpaceConfigurer (new UrlSpaceConfigurer("jini://*/*/" + spaceName).lookupLocators(lookupLocator)).gigaSpace();
		admin = new AdminFactory().addLocator(lookupLocator).createAdmin();		
		// get space partitions direct proxy
		SpacePartition partitions[] = admin.getSpaces().waitFor(sourceSpace.getName(), 10 , TimeUnit.SECONDS).getPartitions();
		
		if (partitions == null )
		{
			log.info("Can't get partitions for " +sourceSpace.getName() );
			System.exit(0);
		}

		if (operation.equals(OPERATION_DUMP))
		{
			log.info("Dump data started!");
			for (int i=0 ; i<partitions.length ; i++)
			{
				int partitionID = getPrimaryInstanceID(partitions[i]);

				// create a temp persistenct space - Using O2 embedded DB. LRU space - should not use lots of memory.
				GigaSpace tempPersistSpace = new GigaSpaceConfigurer (new UrlSpaceConfigurer("/./tempSpace"+ sourceSpace.getName()  + (partitionID) +" ?schema=persistent").
						addProperty("space-config.engine.cache_size", "2000")).gigaSpace();
				
				// copy data from each partition into the temp persistent space
				copyPartitionToFile(partitions[i], tempPersistSpace);
			}
			log.info("Dump data is completed!");
		}
		
		if (operation.equals(OPERATION_RELOAD))
		{
			log.info("Reload data started!");
			for (int i=0 ; i<partitions.length ; i++)
			{
				int partitionID = getPrimaryInstanceID(partitions[i]);
				
				// create a temp persistenct space - Using O2 embedded DB. LRU space - should not use lots of memory.
				GigaSpace tempPersistSpace = new GigaSpaceConfigurer (new UrlSpaceConfigurer("/./tempSpace"+ sourceSpace.getName()  + (partitionID) +" ?schema=persistent").
						addProperty("space-config.engine.cache_size", "2000")).gigaSpace();
				
				// copy data back from temp persistent space to the partition
				copyFileToPartition(partitions[i], tempPersistSpace);
			}
			log.info("Reload data is completed!");
		}
		
		System.exit(0);

	}

	static int getPrimaryInstanceID(SpacePartition partition) throws Exception
	{				
		while (partition.getPrimary() == null)
		{
			Thread.sleep(1000);
			System.out.print(".");
		}
		System.out.println();
		boolean mode = partition.getPrimary().waitForMode(SpaceMode.PRIMARY, 10, TimeUnit.SECONDS);
		if (mode)
			return partition.getPrimary().getInstanceId();
		else
		{
			log.info("Can't find primary instance");
			System.exit(0);
		}	
		return 0;
	}
	
	static void copyPartitionToFile(SpacePartition partition,GigaSpace tempPersistSpace) throws Exception
	{
		SpaceInstance instances[] =  partition.getInstances();
		for (int j=0 ; j<instances.length ; j++)
		{
			// get primary space proxy
			if (instances[j].getBackupId()==0)
			{
				spaceCopy(instances[j].getGigaSpace(), tempPersistSpace);					
			}
		}		
	}
	
	static void copyFileToPartition(SpacePartition partition,GigaSpace tempPersistSpace) throws Exception
	{
		SpaceInstance instances[] =  partition.getInstances();
		for (int j=0 ; j<instances.length ; j++)
		{
			// copy data to primary
			if (instances[j].getBackupId() ==0) 
			{
				spaceCopy(tempPersistSpace, instances[j].getGigaSpace());					
			}
		}
		
		// restart relevant backup to allow it to recover from primary
		restartBackups(partition.getPrimary().getInstanceId());
	}
	
	static void restartBackups(int instanceId)
	{
		ProcessingUnit pu =  admin.getProcessingUnits().waitFor(sourceSpace.getName(), 10 , TimeUnit.SECONDS);
		ProcessingUnitInstance puInstances[] =  pu.getInstances();
		
		for (int i=0 ; i<puInstances.length ; i++)
		{
//			System.out.println("instanceId:" + instanceId + " BackupId:"+ puInstances[i].getSpaceInstance().getBackupId() + " puInstances[i].getClusterInfo().getInstanceId():"+puInstances[i].getClusterInfo().getInstanceId() );
			if ((puInstances[i].getSpaceInstance().getBackupId()>0) && (instanceId == puInstances[i].getClusterInfo().getInstanceId()))
			{
				log.info("Restart Partition ID:"+ instanceId+  " Backup ID:" + puInstances[i].getSpaceInstance().getBackupId());
				puInstances[i].restartAndWait(100, TimeUnit.SECONDS);
			}
		}
	}
	
	static void spaceCopy(GigaSpace source , GigaSpace target) throws Exception
	{
		target.clear(null);
		System.out.println("source : "+ source.getSpace());
		IRemoteJSpaceAdmin spaceAdmin =(IRemoteJSpaceAdmin)target.getSpace().getAdmin();
		SpaceCopyStatus cpstat = spaceAdmin.spaceCopy(source.getSpace(), null, false, 1000);
		log.info(cpstat.toString());
		log.info("Target space has " + target.count(null) + " objects");
	}
	
	static void printUsage()
	{
		System.out.println("------------------------      Space Dump/Reload utility    --------------------- ");
		System.out.println("--------------------------------      Usage     -------------------------------- ");
		System.out.println("java com.gigaspaces.util.spacedump.SpaceDumpMain <lookup locator> <Operation ["+ OPERATION_DUMP + " | " +OPERATION_RELOAD + "] <sapceName>" ); 
		System.out.println("-------------------------------------------------------------------------------- ");
	}
}

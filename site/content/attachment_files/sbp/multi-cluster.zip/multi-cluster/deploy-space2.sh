$JSHOMEDIR/bin/gs.bat deploy -cluster schema=partitioned-sync2backup total_members=1,1 -properties "embed://dataGridName=mySpace2" -override-name mySpace2 templates/datagrid

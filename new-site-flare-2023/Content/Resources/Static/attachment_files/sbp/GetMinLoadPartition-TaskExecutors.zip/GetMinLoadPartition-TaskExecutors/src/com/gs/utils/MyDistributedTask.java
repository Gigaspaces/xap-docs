package com.gs.utils;

import java.rmi.RemoteException;
import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoAware;
import org.openspaces.core.executor.DistributedTask;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.async.AsyncResult;
import com.j_spaces.core.IJSpace;
import com.j_spaces.core.admin.IRemoteJSpaceAdmin;
import com.j_spaces.core.admin.SpaceRuntimeInfo;

public class MyDistributedTask implements
		DistributedTask<PartitionCount, Integer>, ClusterInfoAware {

	@TaskGigaSpace
	private transient GigaSpace gigaSpace;

	private transient ClusterInfo clusterInfo;

	@Override
	public PartitionCount execute() throws Exception {

		Integer totalCount = 0;
		IJSpace ijs = gigaSpace.getSpace();
		PartitionCount pc = new PartitionCount();
		pc.setCount(0);
		pc.setPartitionId(0);

		// pc.setPartitionId(clusterInfo.getInstanceId());

		try {
			IRemoteJSpaceAdmin spaceAdmin = (IRemoteJSpaceAdmin) ijs.getAdmin();

			SpaceRuntimeInfo rtInfo = spaceAdmin.getRuntimeInfo();

			for (int i = 0; i < rtInfo.m_ClassNames.size(); i++) {

				String className = rtInfo.m_ClassNames.get(i);
				Integer count = rtInfo.m_NumOFEntries.get(i);

				System.out.println(System.currentTimeMillis() + "Partition: " + clusterInfo.getInstanceId()
						+ " ClassName: " + className + ", Number of entries: "
						+ count);

				totalCount += rtInfo.m_NumOFEntries.get(i);
			}
			System.out.println(System.currentTimeMillis() + "Partition: " + clusterInfo.getInstanceId()
					+ ", Total entries: " + totalCount);

			pc.setCount(totalCount);
			pc.setPartitionId(clusterInfo.getInstanceId());

		} catch (RemoteException e) {
			e.printStackTrace();
		}

		return pc;

	}

	@Override
	public Integer reduce(List<AsyncResult<PartitionCount>> results)
			throws Exception {

		PartitionCount minPart = null;
		for (AsyncResult<PartitionCount> result : results) {
			if (result.getException() != null) {
				throw result.getException();
			}
			if (minPart != null) {
				if (minPart.getCount() > result.getResult().getCount()) {
					minPart = result.getResult();
				}
			} else {
				minPart = result.getResult();
			}
		}
		return minPart.getPartitionId();
	}

	@Override
	public void setClusterInfo(ClusterInfo clusterInfo) {
		this.clusterInfo = clusterInfo;
	}

}

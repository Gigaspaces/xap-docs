package com.giagspaces.patterns.uow;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.context.GigaSpaceContext;
import org.openspaces.events.polling.SimplePollingContainerConfigurer;
import org.openspaces.events.polling.SimplePollingEventListenerContainer;
import org.openspaces.remoting.RemotingService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;

@RemotingService
public class UOWProcessorFactory implements InitializingBean,UOWProcessorService {

//	public static final int BUCKET_COUNT = Runtime.getRuntime().availableProcessors();
	public static final int BUCKET_COUNT = 4;
	@GigaSpaceContext
	GigaSpace space;
	
	@Autowired 
	@Resource(name="transactionManager")
	PlatformTransactionManager transactionManager;
	
	List<SimplePollingEventListenerContainer> pcList= new ArrayList<SimplePollingEventListenerContainer> ();

	void createProcessor(int bucket)
	{
		UOWMessage templ = new UOWMessage();
		templ.setBuketId(bucket);
		
		SimplePollingEventListenerContainer  pc = new SimplePollingContainerConfigurer(space)
			.eventListenerAnnotation(new UOWProcessor())
			.transactionManager(transactionManager)
			.template(templ).pollingContainer();

		pcList.add(pc);
	}   

	@Override
	public void afterPropertiesSet() throws Exception {
		for (int i=0;i<BUCKET_COUNT;i++)
		{
			createProcessor(i);	
		}
	}

	@Override
	public int getBucketsCount() {
		return BUCKET_COUNT;
	}
	
}

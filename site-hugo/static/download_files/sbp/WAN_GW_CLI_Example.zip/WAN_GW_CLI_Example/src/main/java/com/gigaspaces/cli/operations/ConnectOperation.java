package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.ConnectOptions;
import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;

public class ConnectOperation implements Operation<ConnectOptions> {

    @Override
    public void run(ConnectOptions options, CliGatewayContext context) {
        String lookupGroup = options.getLookupGroup();
        String lookupLocator = options.getLookupLocators();

        AdminFactory adminFactory = new AdminFactory();

        if (lookupGroup != null){
            adminFactory.addGroup(lookupGroup);
        }
        if (lookupLocator != null){
            adminFactory.addLocators(lookupLocator);
        }

        if(options.isSecured()){
            adminFactory.credentials(options.getUsername(), options.getPassword());
        }

        Admin admin = adminFactory.createAdmin();
        admin.getGridServiceContainers().waitFor(1);
        context.setAdmin(admin);
    }
}

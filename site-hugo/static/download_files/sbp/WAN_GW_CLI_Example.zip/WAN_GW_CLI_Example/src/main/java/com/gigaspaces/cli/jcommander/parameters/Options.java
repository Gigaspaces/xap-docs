package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;

public abstract class Options {

    @Parameter(names = {"--help"}, help = true)
    private boolean help;

    public boolean isHelp() {
        return help;
    }
}


package com.gigaspaces.examples.binaryserialization;
public class MemChecker
{
	private Long      _memUsage;
	private static Runtime  s_runtime = Runtime.getRuntime ();

    public MemChecker()
	{
	}
	
	public Long  check() throws Exception
	{
		runGC();
		long totalSum = usedMemory();
		_memUsage = new Long(totalSum);
		return _memUsage;
	}
	
	private  void runGC () throws Exception
    {
        // for whatever reason it helps to call Runtime.gc()
        // using several method calls:
        for (int r = 0; r < 3; ++ r) _runGC ();
    }

    private  void _runGC () throws Exception
    {
        long usedMem1 = usedMemory (), usedMem2 = Long.MAX_VALUE;

        for (int i = 0; (usedMem1 < usedMem2) && (i < 1000); ++ i)
        {
            s_runtime.runFinalization ();
            s_runtime.gc ();
            //Thread.currentThread ().yield ();
            
            usedMem2 = usedMem1;
            usedMem1 = usedMemory ();
            Thread.sleep(1000);
        }
        Thread.sleep(1000);
    }
    
    private  long usedMemory ()
    {
        return s_runtime.totalMemory () - s_runtime.freeMemory ();
    }
}

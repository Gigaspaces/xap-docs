using System;
using System.Text;

using GigaSpaces.Core.Metadata;

namespace GigaSpaces.Examples.ExcelStocks.StockEntities
{
	/// <summary>
	/// The Stock Market Information. 
	/// The data is kept in the Space and is updated 
	/// to reflect changes in the Stock market.
	/// </summary>
	public class StockData
	{
		#region Members

		private string _symbol;
		private string _time;
		private double? _prev;
		private double? _last;
		private double? _bid;
		private double? _ask;
		private double? _low;
		private double? _high;
		private double? _open;
		private int? _bidSize;
		private int? _askSize;
		private string _analystComment;

		#endregion

		#region Properties

		/// <summary>
		/// A system of letters used to uniquely identify a stock or mutual fund. 
		/// </summary>
		[SpaceID, SpaceRouting]
		public string Symbol
		{
			get { return _symbol; }
			set { _symbol = value; }
		}

		/// <summary>
		/// The previous value
		/// </summary>
		public double? Prev
		{
			get { return _prev; }
			set { _prev = value; }
		}
		
		/// <summary>
		/// The most recent trade of a security
		/// </summary>
		public double? Last
		{
			get { return _last; }
			set { _last = value; }
		}

		/// <summary>
		/// The time of the last update
		/// </summary>
		public string Time
		{
			get { return _time; }
			set { _time = value; }
		}

		/// <summary>
		/// The number of shares that are being offered for purchase at the bid price, 
		/// often expressed in terms of hundreds of shares. 
		/// </summary>
		public int? BidSize
		{
			get { return _bidSize; }
			set { _bidSize = value; }
		}
		
		/// <summary>
		/// The highest price any buyer is willing to pay for a given security at a given time
		/// </summary>
		public double? Bid
		{
			get { return _bid; }
			set { _bid = value; }
		}
		
		/// <summary>
		/// The ask is the best quoted price at which a Market Maker is willing to sell a stock
		/// </summary>
		public double? Ask
		{
			get { return _ask; }
			set { _ask = value; }
		}
		
		/// <summary>
		/// The number of shares that are being offered for sale at the ask price, 
		/// often expressed in terms of hundreds of shares. 
		/// </summary>
		public int? AskSize
		{
			get { return _askSize; }
			set { _askSize = value; }
		}
		
		/// <summary>
		/// The lowest price a security or commodity reached in a certain period of time, 
		/// usually a single trading session; here also called daily low. opposite of high.
		/// </summary>
		public double? Low
		{
			get { return _low; }
			set { _low = value; }
		}
		
		/// <summary>
		/// The highest price that was paid for a security during a certain time period. 
		/// </summary>
		public double? High
		{
			get { return _high; }
			set { _high = value; }
		}
		
		/// <summary>
		/// The first price of a given security or commodity in a trading session.
		/// </summary>
		public double? Open
		{
			get { return _open; }
			set { _open = value; }
		}

		/// <summary>
		/// The Analyst's comment about the Symbol
		/// </summary>
		public string AnalystComment
		{
			get { return _analystComment; }
			set { _analystComment = value; }
		}

		#endregion

		#region Constructors


		public StockData(String symbol, double open)
		{
			this.Symbol = symbol;
			this.Open = open;
			this.Last = open;
			this.Low = open;
			this.High = open;
			this.Prev = open;
			this.Bid = open;
			this.Ask = open;
			_time = DateTime.Now.ToString();
			this.AnalystComment = "(Empty)";
		}

		public StockData(String symbol)
			: this()
		{
			this.Symbol = symbol;
		}

		public StockData()
		{
			this.Prev = null;
			this.Last = null;
			this.BidSize = null;
			this.Bid = null;
			this.Ask = null;
			this.AskSize = null;
			this.Low = null;
			this.High = null;
			this.Open = null;
		}
		
		#endregion

		#region Public methods

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder();

			builder.Append(" Symbol: " + Symbol +
				" Prev: " + Prev.ToString() +
				" Current: " + Last.ToString() +
				" Time: " + Time.ToString() +
				" BidSize: " + BidSize.ToString() +
				" Bid: " + Bid.ToString() +
				" Ask: " + Ask.ToString() +
				" AskSize: " + AskSize.ToString() +
				" Low: " + Low.ToString() +
				" High: " + High.ToString() +
				" Open: " + Open.ToString()
				+ " Analyst Comment: " + AnalystComment
				);

			return builder.ToString();
		}

		public StockData ChangeRate(double change, int bidSize, int askSize, double bid, double ask)
		{
			if (Last + change >= 0)
			{
				Time = DateTime.Now.ToString();
				Prev = Last;
				Last = Math.Round((Last + change).Value * 100) / 100.0;
				High = Math.Max(Last.Value, High.Value);
				Low = Math.Min(Last.Value, Low.Value);
				this.BidSize = bidSize;
				this.AskSize = askSize;
				this.Bid = bid;
				this.Ask = ask;
			}
			return this;
		}

		#endregion
	}
}
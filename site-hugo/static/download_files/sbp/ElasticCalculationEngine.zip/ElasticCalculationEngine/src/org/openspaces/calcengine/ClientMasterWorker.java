package org.openspaces.calcengine;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.pu.events.ProcessingUnitInstanceLifecycleEventListener;
import org.openspaces.calcengine.common.CalculateNPVUtil;
import org.openspaces.calcengine.masterworker.Request;
import org.openspaces.calcengine.masterworker.Result;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.core.transaction.manager.DistributedJiniTxManagerConfigurer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.j_spaces.core.client.SpaceURL;

public class ClientMasterWorker implements ProcessingUnitInstanceLifecycleEventListener{

	static GigaSpace space;
	static int workersCount = 4;

	static final int MAX_TRADES = 10000;
	static final int MAX_ITERATIONS = 100;
	static String locators = System.getProperty("locators", "127.0.0.1");
	static double rates[] = {2,3,4,5,6,7,8};
	static DecimalFormat formater = new DecimalFormat("0.0");
	static Logger logger = Logger.getLogger("Master");
	static ProcessingUnit workerPU = null;
	static PlatformTransactionManager ptm = null;
	
	public static void main(String[] args) throws Exception{
		
		ptm = new DistributedJiniTxManagerConfigurer().transactionManager();	
		space = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/CalcDataGrid").lookupLocators(locators)).transactionManager(ptm).gigaSpace(); 
		if (space == null)
		{
			System.out.println("Can't find space - exit");
			System.exit(0);
		}
		
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().addLocator(locators).createAdmin();

		workerPU = admin.getProcessingUnits().waitFor("worker",5,TimeUnit.SECONDS);
		
		Logger.getLogger("org.openspaces.admin.internal.discovery.DiscoveryService").setLevel(Level.OFF);
		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);
		Logger.getLogger("net.jini.discovery.LookupLocatorDiscovery").setLevel(Level.OFF);
		
		if (workerPU != null)
		{
			workerPU.addLifecycleListener(new ClientMasterWorker ());
			workersCount = workerPU.getNumberOfInstances();
		}
		else
		{
			System.out.println("Can't find woker PU - exit!");
			System.exit(0);
		}
		
		Integer[] ids  = new Integer[MAX_TRADES];
		for (int i=0;i<MAX_TRADES;i++)
		{
			ids [i] = i ;
		}
		
		for (int r=0;r<rates.length; r++)
		{
			for (int i=0;i<MAX_ITERATIONS;i++)
			{
				// Mapping IDs to worker
				HashMap<Integer , HashSet<Integer>> partitionIDSDistro = CalculateNPVUtil.splitIDs(ids , workersCount);
				long startTime = System.currentTimeMillis();
				logger.info("--> Executing Job " + i + " with " + workersCount + " workers");
				if (execute(i,partitionIDSDistro,rates[r]))
					reduce(i, partitionIDSDistro.size());
				long endTime = System.currentTimeMillis();
				logger.info("--> Time to Execute Job " + i + " - "  + (endTime - startTime )+ "ms\n");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		System.exit(0);
	}
	
	static public void reduce(int jobId , int totalReusltsExpected)
	{
		//long stTime = System.currentTimeMillis();
		int count = 0;
		int retryCount=0;
		Result resultTemplate = new Result();
		resultTemplate.setJobID(jobId);
		DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
		TransactionStatus status = ptm.getTransaction(definition);

		HashMap<String, Double> aggregatedNPVCalc = new HashMap<String, Double>();
		while (true)
		{
			// getting results from all partitions
			
			Result results[] = space.takeMultiple(resultTemplate,Integer.MAX_VALUE);
			// Are there any results?
			if (results.length > 0)
			{
				count = count + results.length;
				// aggregate the results into books
				for (int i= 0 ; i<results.length ; i++)
				{
					HashMap<String, Double> incPositions = results[i].getResultData();
					CalculateNPVUtil.subreducer(aggregatedNPVCalc , incPositions);
				}
			}
			// Do we have all the results? 
			if (count == totalReusltsExpected)
			{
				logger.info("--> Done executing Job " +jobId);
				break;
			}
			try {
				Thread.sleep(10);
				retryCount++;
				if (retryCount==1000)
				{
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		try
		{
			ptm.commit(status);
			for(String key: aggregatedNPVCalc.keySet()){
				logger.info("Book = " + key + ", NPV = " + formater.format(aggregatedNPVCalc.get(key)));
			}
		}
		catch (Exception e)
		{
			if (!status.isCompleted())
				ptm.rollback(status);
		}
		//long endTime = System.currentTimeMillis();
		//System.out.println("Reduce time:" + (endTime - stTime));
	}
	
	static public boolean execute(int jobId , HashMap<Integer , HashSet<Integer>> partitionIDSDistro , double rate)
	{
		//long stTime = System.currentTimeMillis();
		TransactionStatus status = null;
		try
		{
			Request requests [] = new Request [partitionIDSDistro.size()]; 
			
			Iterator<Integer> iter = partitionIDSDistro.keySet().iterator();
			int i = 0;
			while (iter.hasNext())
			{
				int key = iter.next();
				HashSet<Integer> ids = partitionIDSDistro.get(key);
				requests [i] = new  Request ();
				requests [i].setJobID(jobId);
				requests [i].setTaskID(jobId + "_"+i);
				requests [i].setRouting(i%workersCount);
				requests [i].setRate(rate);
				Integer[]  ids_ = new Integer[ids.size()];
				ids.toArray(ids_);
				requests [i].setTradeIds(ids_ );
				i++;
			}
			DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
			status = ptm.getTransaction(definition);
			space.writeMultiple(requests);
			ptm.commit(status);
			//long endTime = System.currentTimeMillis();
			
			//System.out.println("Execute time:" + (endTime - stTime));
			return true;
		}
		catch (Exception e)
		{
			if (!status.isCompleted())
				ptm.rollback(status);
		}
		return false;

	}

	@Override
	public void processingUnitInstanceAdded(
			ProcessingUnitInstance processingUnitInstance) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		workersCount = workerPU.getNumberOfInstances();
	}

	@Override
	public void processingUnitInstanceRemoved(
			ProcessingUnitInstance processingUnitInstance) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		workersCount = workerPU.getNumberOfInstances();
	}

}

using System.Collections.Generic;

using GigaSpaces.Core.Events;

namespace GigaSpaces.Examples.ExcelStocks.Quote.Framework
{
    /// <summary>
    /// Holds Rtd information per entity instance
    /// </summary>
    /// <typeparam name="T">Type of entity</typeparam>
    internal class RtdEntityInfo<T>
    {
        private T _entity;
        private IEventRegistration _listener;
        private Dictionary<int, RtdTopicInfo> _topics;

        public T Entity
        {
            get { return _entity; }
            set { _entity = value; }
        }
        public IEventRegistration Listener
        {
            get { return _listener; }
            set { _listener = value; }
        }
        public Dictionary<int, RtdTopicInfo> Topics
        {
            get { return _topics; }
        }

        public RtdEntityInfo()
        {
            this._topics = new Dictionary<int, RtdTopicInfo>();
        }
    }
}

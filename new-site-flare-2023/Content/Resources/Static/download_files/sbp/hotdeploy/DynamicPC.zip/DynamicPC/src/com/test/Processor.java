package com.test;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.events.SpaceDataEventListener;
import org.springframework.transaction.TransactionStatus;

public class Processor implements SpaceDataEventListener<Data>{
	
	public Processor (ClusterInfo clusterInfo , String version)
	{
		this.clusterInfo =clusterInfo;
		this.version = version;
	}
	
	ClusterInfo clusterInfo;
	String version;
	
	@Override
	public void onEvent(Data data, GigaSpace arg1, TransactionStatus tx, Object arg3) {
        System.out.println("partition ID " + clusterInfo.getInstanceId()+ " version:" + version + " - processing object id:" + data.getId());
//        System.out.println("initial version");
//        System.out.println("new version");
	}

}

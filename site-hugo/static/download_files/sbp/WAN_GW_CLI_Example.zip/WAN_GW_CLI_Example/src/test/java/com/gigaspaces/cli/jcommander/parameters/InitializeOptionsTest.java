package com.gigaspaces.cli.jcommander.parameters;

import com.gigaspaces.cli.jcommander.OptionsParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by skyler on 5/27/2015.
 */
public class InitializeOptionsTest {
    @Test(expected = IllegalArgumentException.class)
    public void throwsWhenGatewayNameNotProvided() {
        InitializeOptions underTest = new InitializeOptions();
        internalTestWrapper("", underTest);
    }

    @Test
    public void happyPathInitializeOptions(){
        InitializeOptions underTest = new InitializeOptions();
        internalTestWrapper("-n gateway-1", underTest);

        assertEquals("gateway-1", underTest.getName());
    }

    private void internalTestWrapper(String command, InitializeOptions options){
        OptionsParser optionsParser = new OptionsParser();
        optionsParser.parse(command.split(" "), options);
    }
}

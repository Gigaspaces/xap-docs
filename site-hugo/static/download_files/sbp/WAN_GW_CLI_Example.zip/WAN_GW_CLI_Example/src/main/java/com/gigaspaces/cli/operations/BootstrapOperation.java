package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.BootstrapOptions;
import org.openspaces.admin.gateway.BootstrapResult;
import org.openspaces.admin.gateway.Gateway;
import org.openspaces.admin.gateway.GatewaySinkSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * Created by skyler on 5/28/2015.
 */
public class BootstrapOperation implements Operation<BootstrapOptions> {

    private static Logger logger = LoggerFactory.getLogger("Gateway-Bootstrapper");

    @Override
    public void run(BootstrapOptions options, CliGatewayContext context) {
        Gateway newyorkGateway = context.getAdmin().getGateways().waitFor(options.getDestinationId());
        GatewaySinkSource londonSinkSource = newyorkGateway.waitForSinkSource(options.getSourceId());
        BootstrapResult bootstrapResult = londonSinkSource.bootstrapFromGatewayAndWait(options.getTimeout(), TimeUnit.SECONDS);
        if(!bootstrapResult.isSucceeded())
             logger.warn("Bootstrapping failed.", bootstrapResult.getFailureCause());
    }
}

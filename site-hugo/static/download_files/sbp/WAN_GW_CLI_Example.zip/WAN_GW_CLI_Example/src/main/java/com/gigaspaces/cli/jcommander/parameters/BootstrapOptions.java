package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;

/**
 * Created by skyler on 5/28/2015.
 */
public class BootstrapOptions extends ValidateableOptions {

    @Parameter(names = { "-d", "--destination-id"}, description = "The unique identifier of the destination gateway.")
    private String destinationId;

    @Parameter(names = {"-s", "--source-id"}, description = "The unique identifier of the source gateway.")
    private String sourceId;

    @Parameter(names = { "-t", "--timeout"}, description = "The number of seconds before a timeout is reached.")
    private long timeout = 3600;

    @Override
    public void validate() {

    }

    public String getDestinationId() {
        return destinationId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public long getTimeout() {
        return timeout;
    }

    @Override
    public String toString() {
        return "BootstrapOptions{" +
                "destinationId='" + destinationId + '\'' +
                ", sourceId='" + sourceId + '\'' +
                ", timeout=" + timeout +
                '}';
    }
}

package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.InitializeOptions;
import com.gigaspaces.cli.model.WANGatewayModel;
import org.openspaces.admin.Admin;
import org.openspaces.admin.gateway.Gateways;

import java.util.concurrent.TimeUnit;

/**
 * Created by skyler on 5/27/2015.
 */
public class InitializeOperation implements Operation<InitializeOptions> {
    @Override
    public void run(InitializeOptions options, CliGatewayContext context) {
        String gatewayName = options.getName();
        Admin admin = context.getAdmin();
        Gateways gateways = admin.getGateways();
        gateways.waitFor(gatewayName, 1000, TimeUnit.MILLISECONDS);

        if (gateways.getGateway(gatewayName) != null){
            throw new IllegalArgumentException("A gateway named [" + options.getName() + "] is already deployed.");
        }

        if (context.getModels().containsKey(gatewayName)){
            throw new IllegalArgumentException("A gateway named [" + options.getName() + "] is already initialized.");
        }

        context.getModels().put(gatewayName, new WANGatewayModel());
    }
}

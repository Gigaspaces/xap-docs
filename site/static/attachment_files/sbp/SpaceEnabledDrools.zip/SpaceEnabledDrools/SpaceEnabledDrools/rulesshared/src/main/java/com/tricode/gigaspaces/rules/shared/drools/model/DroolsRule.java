package com.tricode.gigaspaces.rules.shared.drools.model;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;

import java.io.Serializable;

/**
 * The contents of a single DRL file.
 */
@SpaceClass(persist = false, replicate = false)
public class DroolsRule implements Serializable {

    private static final long serialVersionUID = -1045963978987889918L;

    private String id;

    private String ruleSetId;

    private String projectName;

    private byte[] ruleBytes;

    private String resourceTypeString;

    /**
     * Public no-arg constructor is required by GigaSpaces.
     */
    public DroolsRule() {
    }

    @SpaceId(autoGenerate = true)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRuleSetId() {
        return ruleSetId;
    }

    public void setRuleSetId(String ruleSetId) {
        this.ruleSetId = ruleSetId;
    }

    @SpaceRouting
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public byte[] getRuleBytes() {
        return ruleBytes;
    }

    public void setRuleBytes(byte[] ruleBytes) {
        this.ruleBytes = ruleBytes.clone();
    }

    public String getResourceTypeString() {
        return resourceTypeString;
    }

    public void setResourceTypeString(String resourceTypeString) {
        this.resourceTypeString = resourceTypeString;
    }

}
package com.gs.util;

import java.sql.Time;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.remoting.ExecutorRemotingProxyConfigurer;

import com.j_spaces.core.IJSpace;

public class ExecutorClientMain {

	static IJSpace space = null;
	static GigaSpace gigaSpace = null;
	static IDataProcessor dataProcessor = null;

	public static void main(String[] args) throws Exception {
		boolean sync = true;

		space = new UrlSpaceConfigurer("jini://*/*/space").space();
		gigaSpace = new GigaSpaceConfigurer(space).gigaSpace();

		dataProcessor = new ExecutorRemotingProxyConfigurer<IDataProcessor>(
				gigaSpace, IDataProcessor.class).broadcast(
				new DataProcessorServiceReducer()).proxy();
		int count = 0;
		while (true) {
			count++;
			if (count == 10)
				break;
			System.out.println(new Time(System.currentTimeMillis())
					+ " - Client calling sync dataProcessor ");
			PartitionCount result = dataProcessor.processData();
			System.out.println(new Time(System.currentTimeMillis())
					+ " - Client got Result:" + result.getPartitionId());
			Thread.sleep(1000);
		}
	}
}
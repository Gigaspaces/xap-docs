package com.gigaspaces.cli;

import com.gigaspaces.cli.model.WANGatewayModel;
import org.openspaces.admin.Admin;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by skyler on 5/27/2015.
 */
public class CliGatewayContext {
    private Admin admin;
    private Map<String, WANGatewayModel> models = new HashMap<>();

    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public Map<String, WANGatewayModel> getModels() {
        return models;
    }
}

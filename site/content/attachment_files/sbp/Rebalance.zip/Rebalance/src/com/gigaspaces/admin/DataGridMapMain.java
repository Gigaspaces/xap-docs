package com.gigaspaces.admin;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.space.SpaceInstance;

import com.gigaspaces.cluster.activeelection.SpaceMode;
import com.j_spaces.core.IJSpace;
import com.j_spaces.core.admin.IRemoteJSpaceAdmin;
import com.j_spaces.core.admin.SpaceRuntimeInfo;

public class DataGridMapMain {

    final Log log = LogFactory.getLog("DataGridMapMain");

    private Admin admin;
    private static String processingUnitName;
    private ProcessingUnit pu;
    private static String locators;

    public static void main(String[] args) {

    	try {
    		locators=args[0];
    		processingUnitName=args[1];

    		DataGridMapMain dataGridMapMain  = new DataGridMapMain ();
    		dataGridMapMain.init();
    		
    		Hashtable<String,ArrayList<SpaceInstance>> spaceMap = dataGridMapMain.getSpacesOnHosts();
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    public void init() {		
        admin = new AdminFactory().addLocators(locators).createAdmin();
        log.info("Looking for " + processingUnitName + " ...");
        pu = admin.getProcessingUnits().waitFor(processingUnitName, 30, TimeUnit.SECONDS);
        if (pu==null)
        {
            log.info("Can't find " + processingUnitName + " PU!");
            System.exit(0);
        }
        
        log.info("Found PU " + pu.getName());
        pu.waitForSpace(30,TimeUnit.SECONDS);
        
        log.info(pu.getName() + " have:" + pu.getSpace().getNumberOfInstances() + " Instances");
        log.info(pu.getName() + " have:" + pu.getSpace().getNumberOfBackups() + " Backups");
        log.info(pu.getName() + " have:" + pu.getSpace().getTotalNumberOfInstances() + " Total Number Of Instances ");
    }
    
    private Hashtable<String,ArrayList<SpaceInstance>> getSpacesOnHosts() throws Exception
	{
		Hashtable<String,ArrayList<SpaceInstance>> spaceListPerHost = new Hashtable<String,ArrayList<SpaceInstance>> ();
		int spaceCount = pu.getTotalNumberOfInstances();
		ProcessingUnitInstance puInstances[]=getInstances();		
		for (int i=0;i<puInstances.length;i++ )
		{
			String hostAddress = puInstances[i].getMachine().getHostAddress();

			ArrayList<SpaceInstance> spaces = null;
			if (!spaceListPerHost.containsKey(hostAddress))
			{
				spaces = new ArrayList<SpaceInstance>();
			}
			else
			{
				spaces=spaceListPerHost.get(hostAddress);
			}
			
			while (puInstances[i].getSpaceInstance() == null)
			{
				Thread.sleep(1000);
			}
			
			spaces.add(puInstances[i].getSpaceInstance());
			spaceListPerHost.put(hostAddress , spaces);
		}

		Enumeration<String> keys = spaceListPerHost.keys();
		while (keys.hasMoreElements())
		{
			String host = keys.nextElement();
			System.out.println("     Host:"+host);
			System.out.println("-------------------------");
			
			ArrayList<SpaceInstance> spaces = spaceListPerHost.get(host);
			Iterator<SpaceInstance> spaceIter = spaces.iterator();
			while (spaceIter.hasNext())
			{
				SpaceInstance space = spaceIter.next();
				if (space != null)
				{
					SpaceMode spaceMode = getSpaceMode(space);
					System.out.println("Process ID: "+  space.getVirtualMachine().getDetails().getPid()+ " InstanceID:" +space.getInstanceId() + " " +spaceMode + " Instance Count:" + getObjectCount(space) );
					}
				}
		}

		return spaceListPerHost ;
	}

    int getObjectCount(SpaceInstance space) throws Exception
    {
    	int objectCount =0;
    	IJSpace ijsapce = space.getGigaSpace().getSpace();
    	IRemoteJSpaceAdmin spaceAdmin = (IRemoteJSpaceAdmin)ijsapce.getAdmin();
    	 
    	SpaceRuntimeInfo rtInfo = spaceAdmin.getRuntimeInfo();
    	Iterator<Integer> iter = rtInfo.m_NumOFEntries.iterator();
    	while(iter.hasNext())
    	{
    		objectCount = objectCount + iter.next().intValue();
    	}
    	return objectCount ;
    }
    
    ProcessingUnitInstance[] getInstances() throws Exception
    {
		int spaceCount = pu.getTotalNumberOfInstances();
		int retryCount = 0;
		ProcessingUnitInstance puInstances[];
		
		while (true)
		{
			puInstances = pu.getInstances();
			retryCount ++;
			if (puInstances.length == spaceCount)
			{
				break;
			}
			if (retryCount == 20)
			{
				log.info("--->>> Can't get full list of instances!");
				break;
			}
			Thread.sleep(2000);
		}
		return puInstances;
    }
    private SpaceMode getSpaceMode(SpaceInstance spaceInstance) throws Exception
    {
        int retryCount=0;
		SpaceMode mode = spaceInstance.getMode();
		while (mode == null )
		{
			mode = spaceInstance.getMode();
	        if (mode == null)
	        {
	        	Thread.sleep(1000);
	        }
	        retryCount++;
	        if (retryCount ==10)
	        {
	        	return mode;
	        }
		}

        retryCount=0;
		// try again in case status is NONE
		while (mode.equals(SpaceMode.NONE))
		{
			mode = spaceInstance.getMode();
	        if (!mode.equals(SpaceMode.NONE))
	        {
	        	break;
	        }
	        else
	        {
	        	Thread.sleep(1000);
	        }
	        retryCount++;
	        if (retryCount ==10)
	        {
	        	return mode ;
	        }
		}
		return mode ;
    }

    private boolean isMode(ProcessingUnitInstance instance , SpaceMode requestedMode) throws Exception{
        SpaceInstance spaceInstance = null;
        int retryCount=0;
        
		while (spaceInstance == null )
		{
	        spaceInstance = instance.getSpaceInstance();
	        if (spaceInstance == null)
	        {
	        	Thread.sleep(1000);
	        }
	        retryCount++;
	        if (retryCount ==10)
	        {
	        	return false;
	        }
		}
		
        retryCount=0;
		SpaceMode mode = getSpaceMode(spaceInstance);
		
		return mode.equals(requestedMode);
    }
    
    private boolean isBackup(ProcessingUnitInstance instance) throws Exception{
    	return isMode(instance, SpaceMode.BACKUP);
    }

}

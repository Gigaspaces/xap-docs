package com.test;

import org.openspaces.core.space.filter.replication.ReplicationFilterProviderFactory;

import com.j_spaces.core.cluster.ReplicationFilterProvider;

public class MyreplicationFilterFactory implements ReplicationFilterProviderFactory{

	@Override
	public MyReplicationFilterProvider getFilterProvider() {
		return new MyReplicationFilterProvider(new MyReplicationFilter() , new MyReplicationFilter());
	}


}

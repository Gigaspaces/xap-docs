package com.giagspaces.patterns.uow;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.remoting.ExecutorRemotingProxyConfigurer;

public class UOWFeederMain {

	public static void main(String[] args) throws Exception{
		int burstSize = 100;
		
		if (args.length > 0)
		{
			burstSize = Integer.valueOf(args[0]).intValue();
		}
		
		GigaSpace space = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/space").noWriteLease(true)).gigaSpace();

		UOWProcessorService uowService  = new ExecutorRemotingProxyConfigurer
			<UOWProcessorService>(space,UOWProcessorService.class).proxy(); 
		
		int bucketsCount = uowService.getBucketsCount();
		int groupsCount = 20;
		
		int i=0;
		
		UOWMessage messageArry[] = new UOWMessage [burstSize];
		while(true)
		{
			for (int j=0;j<burstSize;j++)
			{
				UOWMessage m = new UOWMessage();
				m.setData("AA");
				m.setId(i);
				m.setGroup((i % groupsCount)+ "");
				m.setBuketId(i % bucketsCount);
				messageArry[j] = m;
				i++;
			}
			space.writeMultiple(messageArry);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}
	}
}

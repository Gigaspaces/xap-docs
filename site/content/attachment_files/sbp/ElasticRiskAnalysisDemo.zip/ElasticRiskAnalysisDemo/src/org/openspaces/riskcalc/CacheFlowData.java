package org.openspaces.riskcalc;

import java.io.Serializable;

public class CacheFlowData implements Serializable{

	private Double cacheFlowYear0;
	private Double cacheFlowYear1;
	private Double cacheFlowYear2;
	private Double cacheFlowYear3;
	private Double cacheFlowYear4;
	private Double cacheFlowYear5;

	public Double getCacheFlowYear0() {
		return cacheFlowYear0;
	}

	public void setCacheFlowYear0(Double cacheFlowYear0) {
		this.cacheFlowYear0 = cacheFlowYear0;
	}

	public Double getCacheFlowYear1() {
		return cacheFlowYear1;
	}

	public void setCacheFlowYear1(Double cacheFlowYear1) {
		this.cacheFlowYear1 = cacheFlowYear1;
	}

	public Double getCacheFlowYear2() {
		return cacheFlowYear2;
	}

	public void setCacheFlowYear2(Double cacheFlowYear2) {
		this.cacheFlowYear2 = cacheFlowYear2;
	}

	public Double getCacheFlowYear3() {
		return cacheFlowYear3;
	}

	public void setCacheFlowYear3(Double cacheFlowYear3) {
		this.cacheFlowYear3 = cacheFlowYear3;
	}

	public Double getCacheFlowYear4() {
		return cacheFlowYear4;
	}

	public void setCacheFlowYear4(Double cacheFlowYear4) {
		this.cacheFlowYear4 = cacheFlowYear4;
	}

	public Double getCacheFlowYear5() {
		return cacheFlowYear5;
	}

	public void setCacheFlowYear5(Double cacheFlowYear5) {
		this.cacheFlowYear5 = cacheFlowYear5;
	}

}

package com.gigaspaces.examples.binaryserialization;

import com.gigaspaces.async.AsyncFuture;
import com.j_spaces.core.client.FinderException;
import net.jini.core.entry.UnusableEntryException;
import net.jini.core.lease.Lease;
import net.jini.core.transaction.TransactionException;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import java.util.List;
import java.util.ArrayList;

public class CompressMain {

    private GigaSpace _gigaspace;
    Progress progress = new Progress();
    static final int BATCH_SIZE = 1000;
    static final int TOTAL_BATCHS = 250;
    static final int MILLISEC_IN_SECOND = 1000;
    public static void main(String[] args) {
        try{
            CompressMain cm = new CompressMain(args[0]);

            Integer dec = new Integer(args[1]);
            if(dec == null){
                System.exit(1);
            }
            switch (dec){
                case 0:
                    cm.testFunctionality();
                    break;
                case 1:
                    cm.testSimpleEntry();
                    break;
                case 2:
                    cm.testBinaryFormatEntry();
                    break;
                default:
                    System.exit(1);
            }
            System.exit(0);
        }catch(FinderException e){
            e.printStackTrace();
            System.exit(1);
        }catch(Exception ee){
            ee.printStackTrace();
            System.exit(1);
        }
    }


    public CompressMain(String url) throws Exception {
        _gigaspace = new GigaSpaceConfigurer(new UrlSpaceConfigurer(url)).gigaSpace();
    }

    private void testFunctionality() throws Exception{
    	_gigaspace.clear(null);
    	System.out.println ("running basic system test");
        SimpleEntry testSE = generateSimpleEntry(500);
        _gigaspace.write(testSE, Lease.FOREVER);
    	System.out.println ("wrote SimpleEntry");
        SimpleEntry templateSE = new SimpleEntry();
        templateSE.setQueryField( new Long(500));
        SimpleEntry resSE = (SimpleEntry)_gigaspace.read(templateSE, 0);
    	if (resSE !=null) 
    		System.out.println ("read SimpleEntry");
    	else
    		System.out.println ("can't read SimpleEntry");
    		
        BinaryFormatEntry testBFE = generateBinaryFormatEntry(500);
        _gigaspace.write(testBFE, Lease.FOREVER);
    	System.out.println ("wrote BinaryFormatEntry");
        BinaryFormatEntry templateBFE = new BinaryFormatEntry();
        templateBFE.setQueryField(new Long(500));
        BinaryFormatEntry resBFE = (BinaryFormatEntry)_gigaspace.read(templateBFE, 0);
    	if (resBFE!=null) 
    		System.out.println ("read BinaryFormatEntry");
    	else
    		System.out.println ("can't read BinaryFormatEntry");
    		
        resBFE.unpack();
    	System.out.println ("basic system test - OK!");
    }

    private void testSimpleEntry() throws TransactionException, java.rmi.RemoteException,
            UnusableEntryException, InterruptedException , Exception{
    	
        long  timeBefore = 0, timeAfter = 0;
        double avgWriteMultiple = 0, avgWrite = 0, avgRead = 0, avgReadMultiple = 0, avgTake = 0, avgTakeMultiple = 0,
                counter = 0;

        System.out.println("About to start testing Memory footprint and throughput for SimpleEntry " +
        "\nThis may take few minutes");
        _gigaspace.clear(null);
        long memoryBefore = memCheck();

        avgWriteMultiple = TOTAL_BATCHS/(writeMultipleTest(1 , progress)/MILLISEC_IN_SECOND);
        long memoryAfter = memCheck();
        System.out.println("\nwrite test...");
        for(int i = 1 ; i < 10001 ; i++){
            SimpleEntry wse = generateSimpleEntry(i + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.write(wse, Lease.FOREVER);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            
            if (i % 100 ==0)
            	progress.next();
        }
        avgWrite = 10000/(counter/MILLISEC_IN_SECOND);
        counter = 0;
        System.out.println("\nreadMultiple test...");

        for(int j = 1 ; j < 251 ; j++){
            SimpleEntry readMultipleTemplate = new SimpleEntry();
            timeBefore = System.currentTimeMillis();
            Object res[] = _gigaspace.readMultiple(readMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length==0) throw new RuntimeException("readMultiple return empty result");
            if (j % 100 ==0)
            	progress.next();
            
        }
        avgReadMultiple = TOTAL_BATCHS/(counter/MILLISEC_IN_SECOND);
        counter = 0;
        System.out.println("\nread test...");

        for(int k = 1 ; k < 10001 ; k++){
            SimpleEntry readTemplate = new SimpleEntry();
            readTemplate.setQueryField( new Long(k + 1000));
            timeBefore = System.currentTimeMillis();
            _gigaspace.read(readTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);

            if (k % 100 ==0)
            	progress.next();
            
        }
        avgRead = 10000/(counter/MILLISEC_IN_SECOND);
        counter = 0;
        
        printResult("SimpleEntry", memoryAfter , memoryBefore , avgWrite , avgRead , avgTake, avgWriteMultiple , avgReadMultiple , avgTakeMultiple);

    }

    static public void printResult(String entryType, long  memoryAfter , long memoryBefore , double avgWrite , double avgRead , double avgTake, double avgWriteMultiple , double avgReadMultiple , double avgTakeMultiple)
    {
        System.out.println("\nThe results for :" + entryType);
        System.out.println("Average " + entryType + " size = " + (memoryAfter - memoryBefore)/(TOTAL_BATCHS * BATCH_SIZE));
        System.out.println(entryType + " - Average writeMultiple (1000 entries batch) TP = "+ (int)(avgWriteMultiple*1000) +" oper/sec");
        System.out.println(entryType + " - Average write TP = " + (int)avgWrite+" oper/sec");
        System.out.println(entryType + " - Average readMultiple  (1000 entries batch) TP = "+ (int)(avgReadMultiple * 1000)+" oper/sec");
        System.out.println(entryType + " - Average read TP = " + (int)avgRead +" oper/sec");
    }


    private void testBinaryFormatEntry() throws TransactionException, java.rmi.RemoteException,
        UnusableEntryException, InterruptedException , Exception{
        long timeBefore = 0, timeAfter = 0;
        double avgWriteMultiple = 0, avgWrite = 0,
                avgRead = 0, avgReadMultiple = 0, avgTake = 0, avgTakeMultiple = 0,
                counter = 0;

        System.out.println("About to start testing Memory footprint and throughput for BinaryFormatEntry " +
        "\nThis may take few minutes");
        _gigaspace.clear(null);

        long memoryBefore = memCheck();
        avgWriteMultiple = TOTAL_BATCHS/(writeMultipleTest(3,progress)/MILLISEC_IN_SECOND);
        long memoryAfter = memCheck();
        System.out.println("\nwrite test...");

        for(int i = 1 ; i < 10001 ; i++){
            BinaryFormatEntry writeTemplate = generateBinaryFormatEntry(i + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.write(writeTemplate, Lease.FOREVER);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (i % 100 ==0)
                progress.next();
            
        }
        avgWrite = 10000/(counter/MILLISEC_IN_SECOND);
        counter = 0;
        System.out.println("\nreadMultiple test...");

        for(int j = 1 ; j < 251 ; j++){
            BinaryFormatEntry readMultipleTemplate = new BinaryFormatEntry();
            timeBefore = System.currentTimeMillis();
            Object res[] = _gigaspace.readMultiple(readMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length ==0) throw new RuntimeException("readMultiple return empty result");
        }
        avgReadMultiple = TOTAL_BATCHS/(counter/MILLISEC_IN_SECOND);
        counter = 0;
        System.out.println("\nread test...");

        for(int k = 1 ; k < 10001 ; k++){
            BinaryFormatEntry readTemplate = new BinaryFormatEntry();
            readTemplate.setQueryField (new Long(k + 1000));
            timeBefore = System.currentTimeMillis();
            _gigaspace.read(readTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (k % 100 ==0)
            	progress.next();
        }
        avgRead = 10000/(counter/1000);
        
        printResult("BinaryFormatEntry", memoryAfter , memoryBefore , avgWrite , avgRead , avgTake, avgWriteMultiple , avgReadMultiple , avgTakeMultiple);

    }
    private long memCheck() throws Exception{
    	System.out.println("\nChecking space memory...");
        progress.startAutoProgress();
        MemCheckTask mct = new MemCheckTask();
        AsyncFuture<Long> result = _gigaspace.execute(mct);
        Long res = result.get();
        progress.stopAutoProgress();
    	System.out.println("\nEnd Checking space memory");
        return res.longValue();
    }
    

    private double writeMultipleTest(int type , Progress prog) throws TransactionException, java.rmi.RemoteException,Exception{
    	long timeBefore = 0, timeAfter = 0;
        double duration = 0;
        System.out.println("writeMultiple test...");
        for(int i = 1 ; i < 251 ; i++){
            Object[] writeMArr = getWriteList(type, i);
            timeBefore = System.currentTimeMillis();
            _gigaspace.writeMultiple(writeMArr, Lease.FOREVER);
            prog.next();
            timeAfter = System.currentTimeMillis();
            duration += (timeAfter - timeBefore);
        }

        return duration;
    }

    private Object[] getWriteList(int type, int id) throws Exception{

        Object[] retArr = null;
        switch(type){
            case 1:
                retArr = generateSimpleEntryList(id);
                break;
            case 3:
                retArr = generateBinaryFormatEntryList(id);
                break;
            default:
                break;
        }
        return retArr;
    }

    private SimpleEntry[] generateSimpleEntryList(int id){
        List<SimpleEntry> simpleEntryList = new ArrayList<SimpleEntry>();
        for(int j = 0 ; j < 1000 ; j++){
            SimpleEntry se = generateSimpleEntry(id);
            simpleEntryList.add(se);
        }

        return simpleEntryList.toArray(new SimpleEntry[simpleEntryList.size()]);
    }

    private SimpleEntry generateSimpleEntry(int id){
        return new SimpleEntry(id, 
        	10,
		    20,
		    30,
		    40,
		    50,
		    100,
		    1000,
		    10000,
		    "100000",
		    "1000000",
		    "10000000",
		    "100000000",
		    100000,
		    1000000,
		    10000000,
		    100000000,
		    1000000000,
		    100000000,
		    10000000,
		    1000000,
		    "1000000000",
		    "10000000000",
		    "100000000000",
		    "10000000000000",
		    100000,
		    10000,
		    1000,
		    100,
		    50,
		    40,
		    30,
		    20,
		    "10000000000000",
		    "1000000000000",
		    "100000000000",
		    "10000000000");
    }

    private BinaryFormatEntry[] generateBinaryFormatEntryList(int id) throws Exception{
        List<BinaryFormatEntry> binaryFormatEntryList = new ArrayList<BinaryFormatEntry>();
        for(int j = 0 ; j < BATCH_SIZE ; j++){
            BinaryFormatEntry bfe = generateBinaryFormatEntry(id);
            binaryFormatEntryList.add(bfe);
        }

        return binaryFormatEntryList.toArray(new BinaryFormatEntry[binaryFormatEntryList.size()]);
    }

    private BinaryFormatEntry generateBinaryFormatEntry(int id) throws Exception
     {
        BinaryFormatEntry bfe = new BinaryFormatEntry(id, 
            	10,
    		    20,
    		    30,
    		    40,
    		    50,
    		    100,
    		    1000,
    		    10000,
    		    "100000",
    		    "1000000",
    		    "10000000",
    		    "100000000",
    		    100000,
    		    1000000,
    		    10000000,
    		    100000000,
    		    1000000000,
    		    100000000,
    		    10000000,
    		    1000000,
    		    "1000000000",
    		    "10000000000",
    		    "100000000000",
    		    "10000000000000",
    		    100000,
    		    10000,
    		    1000,
    		    100,
    		    50,
    		    40,
    		    30,
    		    20,
    		    "10000000000000",
    		    "1000000000000",
    		    "100000000000",
    		    "10000000000");

        bfe.pack();
        return bfe;
    }
}

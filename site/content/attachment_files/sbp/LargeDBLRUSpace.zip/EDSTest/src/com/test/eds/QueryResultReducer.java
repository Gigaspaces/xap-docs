package com.test.eds;

import java.util.ArrayList;
import java.util.List;

import com.gigaspaces.async.AsyncResult;
import com.gigaspaces.async.AsyncResultsReducer;

public class QueryResultReducer implements AsyncResultsReducer<MyData[],MyData[]>{

	public QueryResultReducer(){}

	public MyData[] reduce(List<AsyncResult<MyData[]>> results) throws Exception {
		System.out.println(this.getClass().getName() + " - reduce is called");
		List<MyData> totalResult = new ArrayList<MyData> ();
		
		for (AsyncResult<MyData[]> asyncResult : results) {
			MyData[] ret= asyncResult.getResult();
			System.out.println(" Objects Found:" + ret.length);
			for (int i=0;i<ret.length;i++)
			{
				totalResult.add(ret[i]);
			}
		}
		return totalResult.toArray( new MyData[totalResult.size()]);
	}
}

package example.syncremoting.client;

import org.openspaces.remoting.RemoteResultReducer;
import org.openspaces.remoting.SpaceRemotingInvocation;
import org.openspaces.remoting.SpaceRemotingResult;

// The reduce part
public class AccountCountReducer implements RemoteResultReducer<Integer,Integer>{

	public Integer reduce(SpaceRemotingResult[] results,
			SpaceRemotingInvocation remotingInvocation) throws Exception {
		int completeResult =0;
		int size =results.length;
		for(int x=0; x<size;x++){
			if(results[x]!=null){
		    	 if(results[x].getResult()!=null){	
		    			completeResult+=((Integer)results[x].getResult()).intValue();
		    	 }
			}
		}
		return new Integer(completeResult);
	}
}

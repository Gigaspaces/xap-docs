package com.gigaspaces.cli.jcommander.parameters;

public abstract class ValidateableOptions extends Options {
    public abstract void validate();
}

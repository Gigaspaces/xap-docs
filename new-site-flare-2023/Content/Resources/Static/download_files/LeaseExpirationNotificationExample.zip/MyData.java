package com.test;

import com.gigaspaces.annotation.pojo.SpaceId;

public class MyData {

	public MyData(){}

	public MyData(int id){
		this.id = String.valueOf(id);
	}
	String id;

	public String getId() {
		return id;
	}

	@SpaceId (autoGenerate = false)
	public void setId(String id) {
		this.id = id;
	}
}

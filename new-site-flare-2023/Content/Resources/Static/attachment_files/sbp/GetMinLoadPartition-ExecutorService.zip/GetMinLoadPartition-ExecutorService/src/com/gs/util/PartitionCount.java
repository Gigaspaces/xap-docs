package com.gs.util;

import java.io.Serializable;

public class PartitionCount implements Serializable {

	private Integer partitionId;
	private Integer count;
	
	public Integer getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Integer partitionId) {
		this.partitionId = partitionId;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
}

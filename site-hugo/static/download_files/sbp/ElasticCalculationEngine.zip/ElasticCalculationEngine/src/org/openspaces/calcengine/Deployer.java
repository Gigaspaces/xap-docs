package org.openspaces.calcengine;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.gsm.GridServiceManager;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.pu.elastic.config.ManualCapacityScaleConfigurer;
import org.openspaces.admin.space.ElasticSpaceDeployment;
import org.openspaces.core.util.MemoryUnit;

public class Deployer {
	static DecimalFormat formater = new DecimalFormat("0.0");

	static int MAX_MEMEORY_CAPACITY_MB=2048;
	static int INITIAL_MEMEORY_CAPACITY_MB=256;
	static int TARGET_MEMEORY_CAPACITY_MB_STEP1=512;
	static int TARGET_MEMEORY_CAPACITY_MB_STEP2=1024;
	static int TARGET_MEMEORY_CAPACITY_MB_STEP3=256;
	static int CONTAINER_MEMORY_CAPACITY_MB=128;
	static String DATA_GRID_PU = "CalcDataGrid";
	
	static String locator = System.getProperty("locators", "127.0.0.1");
//	static String groups = System.getProperty("groups", "gigaspaces-8.0.1-XAPPremium-ga");

	static Logger logger = Logger.getLogger("Deployer");
	public static void main(String[] args) throws Exception{

		Admin admin = new AdminFactory().addLocator(locator).create();
		logger.info("Created Admin - OK!");
		if (admin == null)
		{
			logger.info(" Can't find a Admin - exit");
			System.exit(0);
		}

		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);

		admin.getGridServiceAgents().waitForAtLeastOne(10, TimeUnit.SECONDS);
		admin.getElasticServiceManagers().waitForAtLeastOne(10, TimeUnit.SECONDS);

		GridServiceManager gsm = admin.getGridServiceManagers().waitForAtLeastOne(10, TimeUnit.SECONDS);
		
		if (gsm == null)
		{
			logger.info(" Can't find a GSM - exit");
			System.exit(0);
		}
		ProcessingUnit pu = null;
		
		pu = admin.getProcessingUnits().waitFor(DATA_GRID_PU, 5,TimeUnit.SECONDS);

		if (pu!= null)
		{
			logger.info("Data-Grid already running");
		}
		else
		{
		// check if the PU already running
		long startTime = System.currentTimeMillis();
		try
		{
				logger.info("--- > Local Machine Demo - Starting initial deploy - Deploying a PU with:" + INITIAL_MEMEORY_CAPACITY_MB + "MB");
				pu = gsm.deploy(new ElasticSpaceDeployment(DATA_GRID_PU)
				 .singleMachineDeployment()
				 .memoryCapacityPerContainer(CONTAINER_MEMORY_CAPACITY_MB,MemoryUnit.MEGABYTES)
		         .maxMemoryCapacity(MAX_MEMEORY_CAPACITY_MB,MemoryUnit.MEGABYTES)
//		         .maxNumberOfCpuCores(maxNumberOfCpuCores)
//				 .addContextProperty("cluster-config.groups.group.fail-over-policy.active-election.yield-time","300")
//				 .addContextProperty("cluster-config.groups.group.fail-over-policy.active-election.fault-detector.invocation-delay","300")
//				 .addContextProperty("cluster-config.groups.group.fail-over-policy.active-election.fault-detector.retry-count","2")
//				 .addContextProperty("space-config.proxy-settings.connection-retries","5")
		         	//initial scale
		         	.scale(new ManualCapacityScaleConfigurer().
	//	         			numberOfCpuCores(cpuCores)
		         			memoryCapacity(INITIAL_MEMEORY_CAPACITY_MB,MemoryUnit.MEGABYTES).
		         			create())       
				);
				monitorPUScaleProgress(pu , INITIAL_MEMEORY_CAPACITY_MB);
				long endTime = System.currentTimeMillis();
				logger.info("Initial Deploy done! - Time to deploy system:" + (endTime-startTime)/1000 + " seconds");
			}
			catch (org.openspaces.admin.pu.ProcessingUnitAlreadyDeployedException e)
			{
				logger.info(e.getMessage());
			}
		}
		
		scale (pu,TARGET_MEMEORY_CAPACITY_MB_STEP1 , MemoryUnit.MEGABYTES); 
		scale (pu,TARGET_MEMEORY_CAPACITY_MB_STEP2 , MemoryUnit.MEGABYTES); 
		scale (pu,TARGET_MEMEORY_CAPACITY_MB_STEP3 , MemoryUnit.MEGABYTES); 
		System.exit(0);
	}

	static void monitorPUScaleProgress(ProcessingUnit pu , int targetCapacity) throws Exception
	{
		double bias = targetCapacity/10; // 10 %
		double progressPercentage =0;
		
		while (true)
		{
			int totalGSCs = pu.getAdmin().getGridServiceContainers().getSize();

				double currentMemUsageMB = getPUTotalMemoryUtilization(pu);
				double diff = Math.abs (targetCapacity - currentMemUsageMB);
				if (currentMemUsageMB>=targetCapacity)
				{
					// scale down scenario
					progressPercentage = (100 * (1 - (diff/currentMemUsageMB)));
				}
				else
				{
					// scale up scenario
					progressPercentage = (100 - ((diff / targetCapacity) * 100));
				}	
				logger.info(">> Total Memory used:"+(formater.format(currentMemUsageMB))+ " MB - Progress:"+ (formater.format(progressPercentage)) + " % done - Total Containers:" + totalGSCs);
				Thread.sleep(2000);
				if (currentMemUsageMB> (targetCapacity - bias) 
						&& (currentMemUsageMB < (targetCapacity + bias)))
					break;
			
			if (progressPercentage> 95)
				break;
		}
	}
	
	static void scale (ProcessingUnit pu , int targetMemoryCapacity , MemoryUnit memUnit) throws Exception
	{
		long startTime =0 ;
		// checking deployed PU.
		logger.info("\n\nAbout to scale data-grid memory capacity from " + formater.format(getPUTotalMemoryUtilization(pu)) + " MB to " + targetMemoryCapacity + " MB");
		logger.info("Hit enter to scale the data grid...");
		System.in.read();
		System.in.read();
		startTime = System.currentTimeMillis();
		pu.scale(new ManualCapacityScaleConfigurer()
        	.memoryCapacity(targetMemoryCapacity,memUnit)
        	.create());

		monitorPUScaleProgress(pu,targetMemoryCapacity);
		long endTime = System.currentTimeMillis();
		logger.info("Data-Grid Memory capacity change done! - Time to scale system:" + (endTime-startTime)/1000 + " seconds");
		
	}
	
	static double getPUTotalMemoryUtilization(ProcessingUnit pu)
	{
		HashMap<String,Double> puJVMsSet = new HashMap<String,Double>();

		pu.waitFor(pu.getNumberOfInstances() * 2,2,TimeUnit.SECONDS);
		double totalMemoryInMB=0;
		ProcessingUnitInstance instances[] = pu.getInstances();
		for (ProcessingUnitInstance processingUnitInstance : instances) {
			puJVMsSet.put(processingUnitInstance.getMachine().getHostAddress() + 
					processingUnitInstance.getVirtualMachine().getDetails().getPid(), 
					new Double (processingUnitInstance.getVirtualMachine().getDetails().
							getMemoryHeapMaxInMB()));
		}

		totalMemoryInMB = puJVMsSet.size() * CONTAINER_MEMORY_CAPACITY_MB;
			
		return totalMemoryInMB;
	}	
}

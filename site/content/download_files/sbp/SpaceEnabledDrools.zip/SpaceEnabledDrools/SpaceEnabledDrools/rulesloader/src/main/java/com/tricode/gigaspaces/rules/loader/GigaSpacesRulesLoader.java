package com.tricode.gigaspaces.rules.loader;

import com.tricode.gigaspaces.rules.shared.RulesConstants;
import com.tricode.gigaspaces.rules.shared.RulesetStatus;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsDslDefinition;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRuleset;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRule;
import com.tricode.gigaspaces.rules.loader.droolsxml.DroolsXmlReader;
import com.tricode.gigaspaces.rules.loader.droolsxml.XmlChangeSet;
import com.tricode.gigaspaces.rules.loader.droolsxml.XmlResource;
import com.tricode.gigaspaces.rules.shared.remoting.IRulesLoadingService;
import org.apache.log4j.Logger;
import org.openspaces.remoting.ExecutorProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.*;

@Component
public class GigaSpacesRulesLoader {

    private final Logger log = Logger.getLogger(GigaSpacesRulesLoader.class);

    private static final String RESOURCE_TYPE_DRL = "DRL";

    private static final String RESOURCE_TYPE_DSLR = "DSLR";

    /**
     * Predefined set of rule definitions (DSL's) to load, see pu.xml
     * <p/>
     * WARNING: Don't change type of this field to List, UNLESS you also change the implementation in the pu.xml!
     */
    @Autowired
    private LinkedList ruleDefinitions;

    /**
     * Predefined set of rulesets to load, see pu.xml
     * <p/>
     * WARNING: Don't change type of this field to Map, UNLESS you also change the implementation in the pu.xml!
     */
    @Autowired
    private HashMap<String, String> ruleSets;

    @Autowired
    private DroolsXmlReader xmlReader;

    /**
     * Remoting service for loading business rules into the space.
     */
    @ExecutorProxy(gigaSpace = "gigaSpace")
    private IRulesLoadingService rulesLoadingService;

    @PostConstruct
    public void init() throws IOException {
        // unload all previously loaded rules
        rulesLoadingService.unloadAllRulesets();

        final Collection<DroolsDslDefinition> definitions = new ArrayList<DroolsDslDefinition>();

        // process definitions first
        for (Object ruleDefinition : ruleDefinitions) {
            DroolsDslDefinition definition = new DroolsDslDefinition();
            definition.setProjectName(RulesConstants.PROJECT_NAME);
            definition.setDslBytes(loadDefinition((String) ruleDefinition));
            definitions.add(definition);
        }

        // start processing new rules to load
        for (Map.Entry<String, String> bulkLoadRule : ruleSets.entrySet()) {
            final String ruleSetName = bulkLoadRule.getKey();
            log.info("========= processing ruleset: " + ruleSetName + " ==========");
            final DroolsRuleset ruleSet = new DroolsRuleset();
            ruleSet.setStatus(RulesetStatus.UNPROCESSED);
            ruleSet.setProjectName(RulesConstants.PROJECT_NAME);
            ruleSet.setRuleSetName(ruleSetName);

            // add all loaded definitions
            ruleSet.setDefinitions(definitions);

            // init collection of rules
            ruleSet.setRules(new ArrayList<DroolsRule>());

            if (bulkLoadRule.getValue().toUpperCase().endsWith(".XML")) {
                // DRL/DSLR package
                XmlChangeSet changeSet = xmlReader.readDroolsRuleResourceFromXml(bulkLoadRule.getValue());

                if (changeSet != null) {
                    if (changeSet.getAdd() != null) {
                        for (XmlResource resource : changeSet.getAdd().getResources()) {

                            final String source = resource.getSource();
                            final String type;

                            if (resource.getType().equalsIgnoreCase(RESOURCE_TYPE_DRL)) {
                                type = RESOURCE_TYPE_DRL;
                            } else if (resource.getType().equalsIgnoreCase(RESOURCE_TYPE_DSLR)) {
                                type = RESOURCE_TYPE_DSLR;
                            } else {
                                log.error("Unknown resource type (" + bulkLoadRule.getValue() + "), skipping...");
                                continue;
                            }

                            DroolsRule rule = new DroolsRule();
                            rule.setProjectName(RulesConstants.PROJECT_NAME);
                            rule.setRuleBytes(loadRule(source.substring(10, source.length())));
                            rule.setResourceTypeString(type);
                            ruleSet.getRules().add(rule);
                        }
                    } else {
                        log.error("Invalid XML file content (" + bulkLoadRule.getValue() + "), skipping...");
                    }
                } else {
                    log.error("Error reading XML file (" + bulkLoadRule.getValue() + "), skipping...");
                }

            } else if (bulkLoadRule.getValue().toUpperCase().endsWith(".DRL")) {
                // normal DRL

                final String source = bulkLoadRule.getValue();
                final String type = RESOURCE_TYPE_DRL;

                DroolsRule rule = new DroolsRule();
                rule.setProjectName(RulesConstants.PROJECT_NAME);
                rule.setRuleBytes(loadRule(source));
                rule.setResourceTypeString(type);
                ruleSet.getRules().add(rule);

            } else {
                log.error("Unknown file type (" + bulkLoadRule.getValue() + "), skipping...");
            }

            rulesLoadingService.loadRuleset(ruleSet);
            log.info("========= ruleset (" + ruleSetName + ") loaded ==========");
        }
    }

    private byte[] loadDefinition(final String source) throws IOException {
        InputStream is;
        InputStreamReader reader = null;

        try {
            log.info("Loading '" + source + "'");
            is = new ClassPathResource(source).getInputStream();
            reader = new InputStreamReader(is);

            StringWriter sw = new StringWriter();
            int i;
            while ((i = reader.read()) != -1) {
                sw.write(i);
            }

            return sw.toString().getBytes();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    private byte[] loadRule(final String source) throws IOException {
        InputStream is;
        InputStreamReader reader = null;

        try {
            log.info("Loading '" + source + "'");
            is = new ClassPathResource(source).getInputStream();
            reader = new InputStreamReader(is);

            StringWriter sw = new StringWriter();
            int i;
            while ((i = reader.read()) != -1) {
                sw.write(i);
            }

            return sw.toString().getBytes();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

}
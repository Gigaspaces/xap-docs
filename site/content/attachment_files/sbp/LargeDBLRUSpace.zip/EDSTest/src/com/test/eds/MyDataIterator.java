package com.test.eds;

import java.util.Iterator;
import java.util.List;

import com.gigaspaces.datasource.DataIterator;
import com.j_spaces.core.client.SQLQuery;

public class MyDataIterator implements DataIterator<MyData>{

	List<MyData> data;
	Iterator<MyData> dataIter;
	public MyDataIterator(List<MyData> initData)
	{
		data=initData;
		dataIter = data.iterator();
	}

	public MyDataIterator(SQLQuery<MyData> query)
	{
		
	}
	public MyDataIterator(MyData query)
	{
		
	}
	public void close() {
		
	}

	public boolean hasNext() {
		if (dataIter!=null )
			return dataIter.hasNext();
		return false;
	}

	public MyData next() {
		if (dataIter!=null )
			return dataIter.next();
		else
			return null;
	}

	public void remove() {
		if (dataIter!=null )
			dataIter.remove();		
	}

}
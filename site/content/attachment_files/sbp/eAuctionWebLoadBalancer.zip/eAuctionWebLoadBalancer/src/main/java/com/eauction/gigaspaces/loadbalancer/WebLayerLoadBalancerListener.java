package com.eauction.gigaspaces.loadbalancer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.pu.events.ProcessingUnitInstanceLifecycleEventListener;

import org.springframework.beans.factory.annotation.Required;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


/**
 * Provides an agent for interacting with a LoadBalancer, such as Apache.
 */
public class WebLayerLoadBalancerListener {
    protected final Log log = LogFactory.getLog(WebLayerLoadBalancerListener.class);

    /**
     * The loadbalancer strategy
     */
    private LoadBalancerAgent loadBalancerAgent;

    /**
    * Names of the PU that are monitored.
    */
    private List<String> monitoredProcessingUnits;

    /**
     * GigaSpaces adminFactory interface.
     */
    private AdminFactory adminFactory;

    /**
     * GigaSpaces admin interface.
     */
    private Admin admin;

    /**
     * Initializes this SLA monitor, and adds an event listener listening for Processing Unit events.
     *
     * @throws Exception in case of initialization problems.
     */
    @PostConstruct
    public void afterPropertiesSet() throws Exception {
        admin = adminFactory.createAdmin();
        admin.addEventListener(new ProcessingUnitInstanceLifecycleEventListener() {
                public void processingUnitInstanceAdded(
                    ProcessingUnitInstance puInstance) {
                    if (monitoredProcessingUnits.contains(puInstance.getName())) {
                        log.info("Processing Unit Instance Added '" +
                            puInstance.getName() + "'");
                        loadBalancerAgent.processingUnitAdded(puInstance);
                    }
                }

                public void processingUnitInstanceRemoved(
                    ProcessingUnitInstance puInstance) {
                    if (monitoredProcessingUnits.contains(puInstance.getName())) {
                        log.info("Processing Unit Instance Removed '" +
                            puInstance.getName() + "'");
                        loadBalancerAgent.processingUnitRemoved(puInstance);
                    }
                }
            });
    }

    /**
     * Cleans up this SLA monitor, shutting down the executor service and Admin.
     *
     * @throws Exception in case of cleanup problems
     */
    @PreDestroy
    public void destroy() throws Exception {
        admin.close();
    }

    //============================================ Setter/Getter ==================================================

    /**
     * Gets the Admin API to find processing units with and request statistics from.
     *
     * @return {@code Admin} API that has been set
     */
    public Admin getAdmin() {
        return admin;
    }

    /**
     * Gets the AdminFactory API to find processing units with and request statistics from.
     *
     * @return {@code AdminFactory} API that has been set
     */
    public AdminFactory getAdminFactory() {
        return adminFactory;
    }

    /**
     * Sets the AdminFactory API to find processing units with and request statistics from.
     *
     * @param adminFactory adminFactory API to set
     */
    public void setAdminFactory(AdminFactory adminFactory) {
        this.adminFactory = adminFactory;
    }

    /**
     * Gets the names of the monitored processing unit.
     *
     * @return {@code List<String>} names of the monitored processing unit
     */
    public List<String> getMonitoredProcessingUnits() {
        return monitoredProcessingUnits;
    }

    /**
     * Sets the names of the monitored processing unit.
     *
     * @param monitoredProcessingUnits names to set
     */
    @Required
    public void setMonitoredProcessingUnits(
        List<String> monitoredProcessingUnits) {
        this.monitoredProcessingUnits = monitoredProcessingUnits;
    }

    /**
     * The loadbalancer strategy to use.
     *
     * @param loadBalancer
     */
    @Required
    public void setLoadBalancerAgent(LoadBalancerAgent loadBalancerAgent) {
        this.loadBalancerAgent = loadBalancerAgent;
    }
}

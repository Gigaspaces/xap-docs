package com.test;

import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoAware;
import org.openspaces.core.executor.DistributedTask;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.async.AsyncResult;

public class WriteTask implements DistributedTask<Integer, Integer> , ClusterInfoAware{

	public WriteTask (int max)
	{
		this.max = max;
	}
	
	int routing;
	int max;
	
	transient ClusterInfo clusterInfo;
	
	@TaskGigaSpace
	transient GigaSpace space;
	
	@Override
	public Integer execute() throws Exception {
		for (int i=0;i<max;i++)
		{
			space.write(new Data());
		}
//		System.out.println("partition name:" + space.getSpace().getContainerName() + " wrote " +  max + " objects");
//		System.out.println("partition clusterInfo InstanceId:" + clusterInfo.getInstanceId() + " wrote " +  max + " objects");
		System.out.println("partition clusterInfo RunningNumber:" + clusterInfo.getRunningNumber() + " wrote " +  max + " objects");
		return null;
		
	}

	@Override
	public Integer reduce(List<AsyncResult<Integer>> arg0) throws Exception {
		System.out.println("done writing all objects");
		return 1;
	}
	
	@SpaceRouting
	public int getRouting() {
		return routing;
	}

	public void setRouting(int routing) {
		this.routing = routing;
	}
	
	
	@Override
	public void setClusterInfo(ClusterInfo clusterInfo) {
		this.clusterInfo = clusterInfo;
	}

}

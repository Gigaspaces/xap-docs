package com.gigaspaces.cli.jcommander.parameters;

import com.gigaspaces.cli.jcommander.OptionsParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by skyler on 5/28/2015.
 */
public class DeployOptionsTest {
    @Test(expected = IllegalArgumentException.class)
    public void throwsWhenNameIsNotProvided() {
        internalTestWrapper("", new DeployOptions());
    }

    @Test
    public void deployHappyPath(){
        DeployOptions underTest = new DeployOptions();
        internalTestWrapper("-n site-1", underTest);

        assertEquals("site-1", underTest.getName());
    }

    private void internalTestWrapper(String command, DeployOptions options){
        OptionsParser optionsParser = new OptionsParser();
        optionsParser.parse(command.split(" "), options);
    }
}

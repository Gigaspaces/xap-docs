package example.syncremoting.common;

import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceProperty;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.annotation.pojo.SpaceProperty.IndexType;

public class Account {
    private Long creationTimeStamp;
    private String id;
    private String zipCode;
    private String fullName;
    private Double creditLimit;
    private Boolean isProcessed;
    private Integer routingValue;
  
	public Long getCreationTimeStamp() {
		return creationTimeStamp;
	}
	public void setCreationTimeStamp(Long val) {
		this.creationTimeStamp = val;
	}

	@SpaceProperty(index = IndexType.BASIC)
	public String getZipCode() {
		return zipCode;
	}
	
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	@SpaceRouting	
	public Integer getRoutingValue() {
		return routingValue;
	}

	public void setRoutingValue(Integer val) {
		this.routingValue = val;
	}

	public Double getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(Double creditLimit) {
		this.creditLimit = creditLimit;
	}
	
	@SpaceId(autoGenerate=false)
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setIsProcessed(Boolean isProcessed) {
		this.isProcessed = isProcessed;
	}
	public Boolean getIsProcessed() {
		return isProcessed;
	}
	public String toString(){
		return "id "+this.id+" from "+this.zipCode;
	}
}
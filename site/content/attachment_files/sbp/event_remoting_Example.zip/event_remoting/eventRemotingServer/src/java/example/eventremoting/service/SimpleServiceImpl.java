package example.eventremoting.service;

import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;

import example.eventremoting.common.SimpleService;

public class SimpleServiceImpl implements SimpleService, InitializingBean {

	public Future<String> asyncSay(String message, int invocationNumber) {
		System.out.println(this.getClass().getSimpleName() + " method called!");
		return null;
	}

	public String say(String message, int invocationNumber) {
		System.out.println(new java.sql.Timestamp(System.currentTimeMillis()) + " " + this.getClass().getSimpleName()
				+ " - Request Number:" + invocationNumber + " called!");

		try {
			Thread.sleep(10000);
		} catch (Throwable t) {
		}
		return message ;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("SimpleServiceImpl constructed...");
	}
}

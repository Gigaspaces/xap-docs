package com.gigaspaces.examples.binaryserialization;

import java.util.Timer;
import java.util.TimerTask;

public class Progress {
	int last=0;
	String symm[] = {"|" ,"/" ,"-","\\"};
	Timer timer = null;
	public void next()
	{
			System.out.print(symm[last]);
			System.out.print("\r");
			last ++;
			if (last==4 ) last =0; 
	}
	
	public void stopAutoProgress()
	{
		timer.cancel();
	}
	public void startAutoProgress()
	{
		timer = new Timer("progress");
		ProgressTask task = new ProgressTask (this);
		timer.schedule(task , 0,500);
	}
	
    public static void main(String[] args) {
    	Progress pr = new Progress();
    	pr.startAutoProgress();
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	pr.stopAutoProgress();
		
    }
    class ProgressTask extends TimerTask
	{
    	Progress prog;
    	ProgressTask(Progress prog)
    	{
    		this.prog = prog;
    	}
		@Override
		public void run() {
			prog.next();
		}
    	
	}
}

package com.test;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.SpaceDataEventListener;
import org.springframework.transaction.TransactionStatus;

import com.gigaspaces.cluster.activeelection.SpaceMode;
import com.gigaspaces.events.NotifyActionType;
import com.j_spaces.core.client.EntryArrivedRemoteEvent;

public class SimpleListener implements SpaceDataEventListener<MyData> {
	public static Map<String, SpaceMode> spaceMode = new ConcurrentHashMap<String, SpaceMode>();

	public void onEvent(MyData data, GigaSpace gigaSpace,
			TransactionStatus txStatus, Object source) {
		// process event
		EntryArrivedRemoteEvent event = (EntryArrivedRemoteEvent) source;
		
		System.out.println(new Date() + " Got " +NotifyActionType.fromModifier(event.getNotifyType())+" notification for Object "
				+ data.getId() + " from "
				+ spaceMode.get(event.getSpaceUuid().toString()));
	}
}

package com.j_spaces.examples.parentchild;

import java.rmi.RemoteException;

import org.openspaces.core.GigaSpace;

import net.jini.core.entry.UnusableEntryException;
import net.jini.core.transaction.TransactionException;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceIndex;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.client.ReadByIdsResult;
import com.gigaspaces.metadata.index.SpaceIndexType;

@SpaceClass
public class Parent  {

	private String childrenIDs[];
	private transient Child children[];
	private Long data;
	private String id;
	
	static final String ChildClassName = Child.class.getName();

	public Parent() {
	}

	public Parent(String id) {
		this.id = id;
	}

	public String _getChildrenDetails(GigaSpace space) throws RemoteException, TransactionException, UnusableEntryException
	{
		String ret="";
		Child[] childs = _getChildren(space);
		for (int i=0;i<childs.length ; i++)
		{
			ret = ret + childs[i].toString() + " | ";
		}
		return ret;
		
	}

	public Child[] _getChildren(GigaSpace space) throws RemoteException, TransactionException, UnusableEntryException
	{
		if (children == null)
		{
			ReadByIdsResult<Child> childrenObjResult = space.readByIds(Child.class,childrenIDs);
			children = childrenObjResult.getResultsArray();
		}
		return children;
	}
	
	public String _getChildrenIDs()
	{
		String res ="";
		for (int i=0 ; i< childrenIDs.length; i++)
		{
			res =res +childrenIDs[i] + "\n";
		}
		return res;
	}

	@SpaceIndex(type=SpaceIndexType.BASIC)
	public Long getData() {
		return data;
	}

	public void setData(Long data) {
		this.data = data;
	}

	public String[] getChildrenIDs() {
		return childrenIDs;
	}

	public void setChildrenIDs(String[] _childrenIDs ) {
		this.childrenIDs = _childrenIDs ;
	}

	@SpaceId(autoGenerate=false)
	@SpaceRouting
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}

using System;
using System.IO;
using System.Web;
using System.Web.SessionState;
using GigaSpaces.Core.Metadata;

namespace GigaSpaces.Practices.HttpSessionProvider
{
    public enum LockedState : byte
    {
        None = 0,
        Unlocked = 1,
        Locked = 2
    };

    /// <summary>
    /// The session state element
    /// </summary>    
    public class SessionDataEntry
    {
        #region Members
        /// <summary>
        /// Sessions unique ID (Includes application name)
        /// </summary>
        [SpaceID]
        [SpaceRouting]
        public readonly string SessionId;
        /// <summary>
        /// Application (Domain) name that the sessions belongs to
        /// </summary>
        [SpaceIndex]
        public String ApplicationName;
        /// <summary>
        /// Current lock id of the session
        /// </summary>
        [SpaceProperty(NullValue = 0)]
        public int LockId;
        /// <summary>
        /// Session's lock state
        /// </summary>
        [SpaceProperty(NullValue = LockedState.None)]
        public LockedState Locked;
        /// <summary>
        /// Last date at which the session was locked (in ticks)
        /// </summary>
        [SpaceProperty(NullValue = -1)]
        public long LockedTimeTicks;
        /// <summary>
        /// Sessions timeout in minutes, if the session is inactive for this number of minutes,
        /// it is removed.
        /// </summary>
        [SpaceProperty(NullValue = -1)]
        public int Timeout;
        /// <summary>
        /// Session's Items, holds all the session's data
        /// </summary>
        public byte[] SessionItems;
        /// <summary>
        /// Session's http static object
        /// </summary>
        public byte[] StaticObjects;
        /// <summary>
        /// Session's action flags, used on cookieless configurations
        /// </summary>
        [SpaceProperty(NullValue = SessionStateActions.None)]
        public SessionStateActions Flags;
        /// <summary>
        /// Version for optimistic locking
        /// </summary>
        [SpaceVersion]
        public int Versionid;

        #endregion

        #region Constructors
        /// <summary>
        /// Default_1 constructor
        /// </summary>
        public SessionDataEntry()
            : this(null, null, 0)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="applicationName">Application name the session relates to</param>
        public SessionDataEntry(string applicationName)
            : this(null, applicationName, 0)
        {
        }


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id">Session ID</param>
        /// <param name="applicationName">Application name the session relates to</param>
        public SessionDataEntry(string id, string applicationName)
            : this(id, applicationName, 0)
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id">Session ID</param>
        /// <param name="applicationName">Application name the session relates to</param>
        /// <param name="lockid">Lock Id of the session</param>
        public SessionDataEntry(string id, string applicationName, int lockid)
        {
            Timeout = -1;
            SessionId = id == null ? id : id + "_" + applicationName;
            ApplicationName = applicationName;
            LockId = lockid;
            LockedTimeTicks = -1;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id">Session ID</param>
        /// <param name="applicationName">Application name the session relates to</param>
        /// <param name="timeout">Timeout (in minutes) for the session</param>
        /// <param name="stateStoreData">Session State Store Data</param>
        public SessionDataEntry(string id, string applicationName, int timeout, SessionStateStoreData stateStoreData)
            : this(id, applicationName, 0)
        {
            Timeout = timeout;
            Locked = LockedState.None;
            Flags = 0;
            SetSessionStateStoreData(stateStoreData);
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns the session state store data held in this instance
        /// </summary>
        /// <returns>Returns the session state store data held in this instance</returns>
        public SessionStateStoreData GetSessionStateStoreData()
        {
            return new SessionStateStoreData(DeserializeSessionItems(SessionItems), DeserializeStaticObjects(StaticObjects), Timeout);
        }

        /// <summary>
        /// Sets the internal items to hold the data
        /// </summary>
        /// <param name="data">Given Session State Store Data</param>
        public void SetSessionStateStoreData(SessionStateStoreData data)
        {
            if (data != null)
            {
                SessionItems = SerializeSessionItems((SessionStateItemCollection)data.Items);
                StaticObjects = SerializeStaticObjects(data.StaticObjects);
            }
            else
            {
                SessionItems = null;
                StaticObjects = null;
            }
        }

        #endregion

        #region Serializing and Deserializing methods
        /// <summary>
        /// Serialize is called by the SetAndReleaseItemExclusive method to 
        /// convert the SessionStateItemCollection into a Base64 string to    
        /// be stored in an Access Memo field.
        /// </summary>
        internal static byte[] SerializeSessionItems(SessionStateItemCollection items)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                BinaryWriter writer = new BinaryWriter(ms);

                if (items != null)
                    items.Serialize(writer);

                return ms.ToArray();
            }
        }

        /// <summary>
        /// DeSerialize is called by the GetSessionStoreItem method to 
        /// convert the Base64 string stored in the Access Memo field to a 
        /// SessionStateItemCollection.
        /// </summary>
        private static SessionStateItemCollection DeserializeSessionItems(byte[] serializedItems)
        {
            SessionStateItemCollection sessionItems =
              new SessionStateItemCollection();

            if (serializedItems != null && serializedItems.Length > 0)
            {
                using (BinaryReader reader = new BinaryReader(new MemoryStream(serializedItems)))
                {
                    sessionItems = SessionStateItemCollection.Deserialize(reader);
                }
            }

            return sessionItems;
        }

        /// <summary>
        /// Serialize is called by the SetAndReleaseItemExclusive method to 
        /// convert the HttpStaticObjectsCollection into a Base64 string to    
        /// be stored in an Access Memo field.
        /// </summary>
        internal static byte[] SerializeStaticObjects(HttpStaticObjectsCollection staticObjects)
        {

            using (MemoryStream ms = new MemoryStream())
            {
                BinaryWriter writer = new BinaryWriter(ms);

                if (staticObjects != null)
                    staticObjects.Serialize(writer);

                return ms.ToArray();
            }
        }

        /// <summary>
        /// DeSerialize is called by the GetSessionStoreItem method to 
        /// convert the Base64 string stored in the Access Memo field to a 
        /// HttpStaticObjectsCollection.
        /// </summary>
        private static HttpStaticObjectsCollection DeserializeStaticObjects(byte[] serializedStaticObjects)
        {
            HttpStaticObjectsCollection staticObjects =
              new HttpStaticObjectsCollection();

            if (serializedStaticObjects != null && serializedStaticObjects.Length > 0)
            {
                using (BinaryReader reader = new BinaryReader(new MemoryStream(serializedStaticObjects)))
                {
                    staticObjects = HttpStaticObjectsCollection.Deserialize(reader);
                }
            }

            return staticObjects;
        }

        #endregion
    }
}

package com.gigaspaces.examples.binaryserialization.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;
import java.util.Map.Entry;

/**
 * This class provides helper methods for low footprint binary serialization.
 * 
 * It should only be used by experienced developers in scenarios which require low footprint optimizations.
 * 
 * NOTE: This class is NOT part of GigaSpaces XAP API. It is a porting of a class which was originally created for internal 
 * usage in modules which require high performance. Since performance was the major design guideline, some safety checks 
 * (e.g. validations) were intentionally not included, which means common user errors might result in unexpected behavior 
 * at runtime.
 * 
 * @author GigaSpaces
 */
public class BinaryOutputStream extends OutputStream
{
	/** 
	 * The buffer where data is stored. 
	 */
	private byte[] _buffer;

	/**
	 * The number of valid bytes in the buffer. 
	 */
	private int _count;

	private static final int SIZE_INT = 4;
	private static final int SIZE_LONG = 8;
	private static final int SIZE_UUID = 16;
	
	/**
	 * Creates a new byte array output stream. The buffer capacity is 
	 * initially 32 bytes, though its size increases if necessary. 
	 */
	public BinaryOutputStream()
	{
		this(32);
	}

	/**
	 * Creates a new byte array output stream, with a buffer capacity of 
	 * the specified size, in bytes. 
	 *
	 * @param   capacity   the initial capacity.
	 * @exception  IllegalArgumentException if size is negative.
	 */
	public BinaryOutputStream(int capacity)
	{
		if (capacity < 0)
			throw new IllegalArgumentException("Negative initial size: " + capacity);
		_buffer = new byte[capacity];
	}

	/**
	 * Copy internal buffer 
	 * @param arr target buffer 
	 * @param srcPos start position 
	 */
	public void copyToBuffer(ByteBuffer buffer)
	{
		buffer.put(_buffer, 0, _count);
	}

	/**
	 * Set stream buffer, and reset the counter.
	 * @param buf new buffer
	 * @return old buffer
	 */
	public void setInternalBuffer( byte[] buf)
	{
		setInternalBuffer( buf, 0);
	}

	/**
	 * Set stream buffer and set the counter.
	 * @param buf new buffer
	 * @param count amount of valid bytes
	 * @return old buffer
	 */
	public void setInternalBuffer( byte[] buffer, int count)
	{
		this._buffer = buffer;
		this._count = count;
	}

	/**
	 * Gets internal buffers 
	 * @return internal buffer
	 */
	public byte[] getInternalBuffer()
	{
		return this._buffer;
	}

	/**
	 * Set the buffer size.
	 * @param size amount of valid bytes
	 */
	public void setSize( int size)
	{
		this._count = size;
	}

	/**
	 * Returns the current size of the buffer.
	 *
	 * @return  the value of the <code>count</code> field, which is the number
	 *          of valid bytes in this output stream.
	 * @see     java.io.ByteArrayOutputStream#count
	 */	
	public int getSize()
	{
		return _count;
	}

	/**
	 * The current buffer capacity.
	 * 
	 * @return buffer current capacity
	 */	
	public int getCapacity()
	{
		return _buffer.length;
	}
	
	public boolean ensureCapacity(int delta)
	{
		int newcount = _count + delta;
		if (newcount > _buffer.length)
		{
			byte newbuf[] = new byte[Math.max(_buffer.length << 1, newcount)];
			System.arraycopy(_buffer, 0, newbuf, 0, _count);
			_buffer = newbuf;
			return true;
		}
		return false;
	}

	/**
	 * Writes the complete contents of this byte array output stream to 
	 * the specified output stream argument, as if by calling the output 
	 * stream's write method using <code>out.write(buf, 0, count)</code>.
	 *
	 * @param      out   the output stream to which to write the data.
	 * @exception  IOException  if an I/O error occurs.
	 */	
	public void writeTo(OutputStream out) throws IOException 
	{
		out.write(_buffer, 0, _count);
	}

	/**
	 * Resets the <code>count</code> field of this byte array output 
	 * stream to zero, so that all currently accumulated output in the 
	 * output stream is discarded. The output stream can be used again, 
	 * reusing the already allocated buffer space. 
	 *
	 * @see     java.io.ByteArrayInputStream#count
	 */
	public void reset()
	{
		_count = 0;
	}

	/**
	 * Creates a newly allocated byte array. Its size is the current 
	 * size of this output stream and the valid contents of the buffer 
	 * have been copied into it. 
	 *
	 * @return  the current contents of this output stream, as a byte array.
	 * @see     java.io.ByteArrayOutputStream#size()
	 */
	public byte[] toByteArray()
	{
		byte newbuf[] = new byte[_count];
		System.arraycopy(_buffer, 0, newbuf, 0, _count);
		return newbuf;
	}

	/**
	 * Writes the specified byte to this byte array output stream. 
	 *
	 * @param   b   the byte to be written.
	 */
	@Override
	public void write(int b)
	{
		ensureCapacity(1);
		_buffer[_count++] = (byte)b;
	}

	/**
	 * Writes <code>len</code> bytes from the specified byte array 
	 * starting at offset <code>off</code> to this byte array output stream.
	 *
	 * @param   b     the data.
	 * @param   off   the start offset in the data.
	 * @param   len   the number of bytes to write.
	 */
	@Override
	public void write(byte b[], int off, int len)
	{
		if (len == 0)
			return;
		ensureCapacity(len);
		System.arraycopy(b, off, _buffer, _count, len);
		_count += len;
	}
	
	public void writeByte(byte value)
	{
		ensureCapacity(1);
		_buffer[_count++] = value;
	}
	public void writeByteArray(byte[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			write(array, 0, array.length);
		}
	}
	public void writeByteWrapper(Byte value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeByte(value.byteValue());
		}
	}
	public void writeByteWrapperArray(Byte[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeByteWrapper(array[i]);
		}
	}

	public void writeShort(short value)
	{
	    writeInt(value);
	}
	public void writeShortArray(short[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				this.writeShort(array[i]);
		}
	}
	public void writeShortWrapper(Short value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeShort(value.shortValue());
		}
	}
	public void writeShortWrapperArray(Short[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeShortWrapper(array[i]);
		}
	}

	public void writeInt(int value)
	{
	    byte b = 0;
	    if (value < 0)
	    {
	        b = 64;
	        value = ~value;
	    }
	    b |= (byte) (value & 0x3f);
	
	    for (value = (int) (value >> 6); value != 0; value = (int) (value >> 7))
	    {
	        b |= 0x80;
	        ensureCapacity(1);
	        _buffer[_count++] = b;
	        b = (byte) (value & 0x7f);
	    }
	    ensureCapacity(1);
	    _buffer[_count++] = b;
	}
	public void writeIntArray(int[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeInt(array[i]);
		}
	}
	public void writeIntWrapper(Integer value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeInt(value.intValue());
		}
	}
	public void writeIntWrapperArray(Integer[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeIntWrapper(array[i]);
		}
	}

	public void writeIntFixed(int value)
	{
		ensureCapacity(SIZE_INT);
		_buffer[_count++] = (byte)((value >>> 24) & 0xFF);
		_buffer[_count++] = (byte)((value >>> 16) & 0xFF);
		_buffer[_count++] = (byte)((value >>>  8) & 0xFF);
		_buffer[_count++] = (byte)((value >>>  0) & 0xFF);
	}

	public void writeLong(long value)
	{
	    byte b = 0;
	    if (value < 0L)
	    {
	        b = 64;
	        value = ~value;
	    }
	    b |= (byte) ((int) value & 0x3f);
	    for (value = (long) value >> 6; value != 0L; value = (long) (value) >> 7)
	    {
	        b |= 0x80;
	        ensureCapacity(1);
	        _buffer[_count++] = b;
	        b = (byte) ((int) value & 0x7f);
	    }
	
	    ensureCapacity(1);
	    _buffer[_count++] = b;
	}
	public void writeLongArray(long[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeLong(array[i]);
		}
	}
	public void writeLongWrapper(Long value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeLong(value.longValue());
		}
	}
	public void writeLongWrapperArray(Long[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeLongWrapper(array[i]);
		}
	}

	public void writeLongFixed(long value)
	{
		ensureCapacity(SIZE_LONG);
		_buffer[_count++] = (byte)(value >>> 56);
		_buffer[_count++] = (byte)(value >>> 48);
		_buffer[_count++] = (byte)(value >>> 40);
		_buffer[_count++] = (byte)(value >>> 32);
		_buffer[_count++] = (byte)(value >>> 24);
		_buffer[_count++] = (byte)(value >>> 16);
		_buffer[_count++] = (byte)(value >>>  8);
		_buffer[_count++] = (byte)(value >>>  0);
	}

	public void writeFloat(float value)
	{
	    int rawValue = Float.floatToIntBits(value);
	    writeInt(rawValue);
	}
	public void writeFloatArray(float[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeFloat(array[i]);
		}
	}
	public void writeFloatWrapper(Float value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeFloat(value.floatValue());
		}
	}
	public void writeFloatWrapperArray(Float[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeFloatWrapper(array[i]);
		}
	}

	public void writeDouble(double value)
	{
	    long rawValue = Double.doubleToLongBits(value);
	    writeLong(rawValue);
	}
	public void writeDoubleArray(double[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeDouble(array[i]);
		}
	}
	public void writeDoubleWrapper(Double value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeDouble(value.doubleValue());
		}
	}
	public void writeDoubleWrapperArray(Double[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeDoubleWrapper(array[i]);
		}
	}

	public void writeBoolean(boolean value)
	{
		writeByte(value ? BinaryStreamConstants.BOOLEAN_TRUE : BinaryStreamConstants.BOOLEAN_FALSE);
	}
	public void writeBooleanArray(boolean[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeBoolean(array[i]);
		}
	}
	public void writeBooleanWrapper(Boolean value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.BOOLEAN_NULL);
		else
			writeByte(value.booleanValue() ? BinaryStreamConstants.BOOLEAN_TRUE : BinaryStreamConstants.BOOLEAN_FALSE);
	}
	public void writeBooleanWrapperArray(Boolean[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeBooleanWrapper(array[i]);
		}
	}

	public void writeChar(char value)
	{
	    writeInt(value);
	}
	public void writeCharArray(char[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeChar(array[i]);
		}
	}
	public void writeCharWrapper(Character value)
	{
		if (value == null)
			writeByte(BinaryStreamConstants.VALUE_NULL);
		else
		{
			writeByte(BinaryStreamConstants.VALUE_NOT_NULL);
			writeChar(value.charValue());
		}
	}
	public void writeCharWrapperArray(Character[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeCharWrapper(array[i]);
		}
	}

	public void writeString(String value)
	{
		// Write string type
		if (value == null)
		{
			writeByte(BinaryStreamConstants.STRING_NULL);
			return;
		}
        int length = value.length();
		if (length == 0)
		{
			writeByte(BinaryStreamConstants.STRING_EMPTY);
			return;
		}
    	// Save position:
    	int startingPosition = _count;
    	// By default attempt to write the string in ASCII format
		writeByte(BinaryStreamConstants.STRING_ASCII);
		// Write length:
        writeInt(length);
		// Save position from where the string bytes starts
		int positionBeforeContent = _count;
    	// Start by assuming string is not unicode (i.e. 1 byte per char):
    	boolean isUnicode = false;
    	// Used to indicate the ascii part length of the string
    	int asciiIntervalLength = 0;
    	// Get the string characters:
        char[] chars = value.toCharArray();
        // make sure buffer is big enough for 1 byte per char:
    	ensureCapacity(length);
    	// Write characters:
    	for (int i = 0; i < length; i++)
    	{
    		char currChar = chars[i];
    		// If character requires more than a byte, stop:
    		if (currChar > 255)
    		{
    			isUnicode = true;
    			asciiIntervalLength = i;    			
    			// make sure buffer is big enough for 2 bytes per char:
            	ensureCapacity((length*2) - i);    			
    			break;
    		}
    		_buffer[_count++] = (byte)currChar;
    	}

    	if (isUnicode)
    	{        	
    		// Go back to position before content:
    		_count = startingPosition;    		
    		// Switch to unicode format
    		writeByte(BinaryStreamConstants.STRING_UNICODE);
    		// Fix position to start after the already written chars:
        	_count = positionBeforeContent + asciiIntervalLength;
        	// Write characters:
        	for (int i = asciiIntervalLength; i < length; i++, _count++)
        	{        		
        		char currChar = chars[i];
        		// Write first byte:
        		_buffer[_count] = (byte)currChar;
        		// Write second byte at offset of length:
        		_buffer[_count + length] = (byte)(currChar >> 8);        		
        	}
        	// Make sure there are zeros on the ascii chars
        	for(int i = 0; i < asciiIntervalLength; i++)
        		_buffer[_count++] = 0;
        	// Fix position to point to the end of the string bytes:
        	_count += length - asciiIntervalLength;
    	}
	}	
	public void writeStringArray(String[] array)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeString(array[i]);
		}
	}

	public void writeDateTime(Date value, boolean isNullable)
	{
		if (isNullable)
			writeByte(value == null ? BinaryStreamConstants.VALUE_NULL : BinaryStreamConstants.VALUE_NOT_NULL);

		long rawValue = value.getTime();
	    writeLong(rawValue);
	}
	public void writeDateTimeArray(Date[] array, boolean isNullable)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeDateTime(array[i], isNullable);
		}
	}

	public void writeBigDecimal(BigDecimal value, boolean isNullable)
	{
		if (isNullable)
			writeByte(value == null ? BinaryStreamConstants.VALUE_NULL : BinaryStreamConstants.VALUE_NOT_NULL);

		String rawValue = value.toEngineeringString();
	    writeString( rawValue);
	}
	public void writeBigDecimalArray(BigDecimal[] array, boolean isNullable)
	{
		if (array == null)
			writeInt(BinaryStreamConstants.ARRAY_NULL);
		else
		{
			writeInt(array.length);
			for (int i=0 ; i < array.length ; i++)
				writeBigDecimal(array[i], isNullable);
		}
	}
}

package com.test.eds;

import java.io.Serializable;

import com.gigaspaces.annotation.pojo.*;
import com.gigaspaces.metadata.index.SpaceIndexType;

@SpaceClass (persist=true)
public class MyData implements Serializable{

	String id;
	String data;
	Integer routing;

	@SpaceId (autoGenerate=true)
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	@SpaceIndex(type=SpaceIndexType.BASIC)
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	@SpaceRouting
	public Integer getRouting() {
		return routing;
	}
	public void setRouting(Integer routing) {
		this.routing = routing;
	}
}
package com.giagspaces.patterns.uow;

import com.gigaspaces.annotation.pojo.FifoSupport;
import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceIndex;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.metadata.index.SpaceIndexType;

@SpaceClass (fifoSupport=FifoSupport.ALL)
public class UOWMessage {

	public UOWMessage (){}
	Integer id;
	String data;
	String group;
	Integer buketId;
	
	@SpaceId
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	@SpaceIndex(type=SpaceIndexType.BASIC)
	@SpaceRouting
	public String getGroup() {
		return group;
	}
	public void setGroup(String subject) {
		this.group = subject;
	}
	public Integer getBuketId() {
		return buketId;
	}
	
	@SpaceIndex(type=SpaceIndexType.BASIC)
	public void setBuketId(Integer buketId) {
		this.buketId = buketId;
	}
}

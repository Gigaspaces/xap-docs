package example.syncremoting.client;

import org.openspaces.core.GigaSpace;
import org.openspaces.pu.container.servicegrid.deploy.Deploy;

import com.j_spaces.core.client.FinderException;
import com.j_spaces.core.client.SpaceFinder;

import example.syncremoting.common.*;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A simple bean that is run within a Spring context that acts as the processing
 * unit context as well (when executed within a processing unit container).
 * 
 * <p>
 * This bean is designed to be invoked repeatedly by a TaskTimer
 * 
 * <p>
 * The TaskTimer and its factory are specified in the pu.xml
 */
public class AccountFeedAndQuery extends TimerTask {
	GigaSpace space = null;
	private int upperBound = 10;
	private AtomicInteger counter = new AtomicInteger();
	private AccountQuery service = null;

	/**
	 * This method is called repeatedly by the TaskTimer
	 */
	public void run() {
		if ((space != null) && (counter.get() < upperBound)) {
			Account obj = new Account();
			obj.setCreationTimeStamp(System.currentTimeMillis());
			obj.setCreditLimit(new Double((System.nanoTime() % 100) * (1000)));
			obj.setFullName("Owen Taylor the " + System.currentTimeMillis()
					% 1000);
			obj.setId(Long.toHexString(System.currentTimeMillis()));
			obj.setZipCode(buildZipCode());
			obj.setIsProcessed(false);
			obj.setRoutingValue(new Integer(counter.get()));
			space.write(obj);
			counter.incrementAndGet();
			System.out.println(this.getClass().getSimpleName()
					+ " Wrote Account " + obj.getRoutingValue().hashCode());
		} else {
			try {
				Thread.sleep(2000);
			} catch (Throwable t) {
			}
			// The query part - This invokes the service
			String zipCode = buildZipCode();
			long beforeOperation = System.nanoTime();
			Integer result = service
					.getNumberOfApprovedAccountsByZipCode(zipCode);
			long afterOperation = System.nanoTime();
			System.out.println("Number of approved accounts in zip Code: "
					+ zipCode + " == " + result);
			System.out.println("it took "
					+ ((afterOperation - beforeOperation) / 1000)
					+ " microseconds");
			// reset counter to continue writing more ...
			counter = new AtomicInteger(0);
		}
	}

	private String buildZipCode() {
		return "1" + System.nanoTime() % 2 + "0" + System.nanoTime() % 2
				+ System.nanoTime() % 10;
	}

	/**
	 * Here we have injection of the space as part of the constructor
	 * 
	 * param in The GigaSpace to work with
	 */
	public AccountFeedAndQuery(GigaSpace in) {
		System.out.println(this.getClass().getSimpleName()
				+ ": I am being constructed with " + in);
		this.space = in;
	}

	
	public void setUpperBound(int upperBound) {
		this.upperBound = upperBound;
	}

	public int getUpperBound() {
		return upperBound;
	}

	public void setService(AccountQuery service) {
		this.service = service;
	}
	
}
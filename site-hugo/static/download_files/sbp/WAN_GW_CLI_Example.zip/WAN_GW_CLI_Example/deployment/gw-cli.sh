#!/bin/bash

echo "hello $1"

if [ -z "$1" ]; then
    echo "No configuration file provided"
    java -classpath /home/adminuser/gigaspaces-xap-premium-10.1.1-ga/lib/required/*:./lib/*:../target/gw-cli-1.0-SNAPSHOT.jar com.gigaspaces.cli.CommandLineTool
else
    echo "Configuration file $1"
    cat $1 | java -classpath /home/adminuser/gigaspaces-xap-premium-10.1.1-ga/lib/required/*:./lib/*:../target/gw-cli-1.0-SNAPSHOT.jar com.gigaspaces.cli.CommandLineTool
fi
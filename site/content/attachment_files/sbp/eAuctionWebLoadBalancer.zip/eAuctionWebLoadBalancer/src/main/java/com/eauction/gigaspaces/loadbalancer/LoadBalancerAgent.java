package com.eauction.gigaspaces.loadbalancer;

import org.openspaces.admin.pu.ProcessingUnitInstance;


public interface LoadBalancerAgent {
    void processingUnitAdded(ProcessingUnitInstance puInstance);

    void processingUnitRemoved(ProcessingUnitInstance puInstance);
}

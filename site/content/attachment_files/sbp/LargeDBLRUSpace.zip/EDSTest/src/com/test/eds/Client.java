package com.test.eds;

import java.util.List;
import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.gigaspaces.async.AsyncFuture;
import com.j_spaces.core.client.SQLQuery;

public class Client {

	static Logger logger = Logger.getLogger("Client");

	public static void main(String[] args) throws Exception{
		GigaSpace gigaspace = new GigaSpaceConfigurer(
				new UrlSpaceConfigurer("jini://*/*/space")).gigaSpace();

		MyData obj = new MyData();
		obj.setId("a");
		obj.setData("aaaaa");
		obj.setRouting(1);
		logger.info("APP-write");
		gigaspace.write(obj);

		MyData templ1 = new MyData();
		templ1.setId("1");
		templ1.setRouting(1);

		MyData templ2 = new MyData();
		templ2.setId("a");
		templ2.setRouting(1);

		MyData templ3 = new MyData();
		templ3.setId("b");
		templ3.setRouting(1);

		logger.info("APP-read Loaded object from EDS");
		MyData ret = gigaspace.read(templ1);
		if (ret == null)
			logger.info("Could not read loaded object");
		else
			logger.info("read loaded object - OK!");

		logger.info("APP-read");
		ret = gigaspace.read(templ2);
		if (ret == null)
			logger.info("Could not read object");
		else
			logger.info("read object - OK!");

		logger.info("APP-read unloaded object");
		ret = gigaspace.read(templ3);
		if (ret == null)
			logger.info("Can't find the object - OK");
		else
			logger.info("read loaded object - OK!");

		logger.info("APP-readMultiple");
		MyData retArray[] = gigaspace.readMultiple(new MyData(),Integer.MAX_VALUE);
		logger.info("readMultiple - found " + retArray.length + " objects");

		logger.info("APP-execute QueryTask");
		QueryTask queryTask = new QueryTask("", 1);
		AsyncFuture<MyData[]> result = gigaspace.execute(queryTask);
		retArray = result.get();
		logger.info("Execute QueryTask - found " + retArray.length + " objects");

		logger.info("APP-execute CountTask");
		CountTask countTask = new CountTask("");
		AsyncFuture<List<QuerySubResult>> resultCount = gigaspace.execute(countTask);
		logger.info("Execute CountTask - " + resultCount.get());
///////////
		QueryService queryService = new QueryService(gigaspace, new SQLQuery<MyData>(MyData.class,""),50, QueryService.QueryStrategy.BORADCAST);
		MyData resQuery[] = queryService.executeQuery();
		logger.info("QueryService - Found " + resQuery.length + " matching objects");
//////////
		queryService = new QueryService(gigaspace, new SQLQuery<MyData>(MyData.class,""),500, QueryService.QueryStrategy.BORADCAST);
		resQuery = queryService.executeQuery();
		logger.info("QueryService - Found " + resQuery.length + " matching objects");
//////////
		queryService = new QueryService(gigaspace, new SQLQuery<MyData>(MyData.class,""),700, QueryService.QueryStrategy.BORADCAST);
		resQuery = queryService.executeQuery();
		logger.info("QueryService - Found " + resQuery.length + " matching objects");
	}
}

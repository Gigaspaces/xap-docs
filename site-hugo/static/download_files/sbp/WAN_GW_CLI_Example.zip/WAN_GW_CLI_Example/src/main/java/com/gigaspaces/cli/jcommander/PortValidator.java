package com.gigaspaces.cli.jcommander;

import com.beust.jcommander.IParameterValidator;
import com.beust.jcommander.ParameterException;

public class PortValidator implements IParameterValidator{

    @Override
    public void validate(String name, String value) throws ParameterException {
        int port = Integer.parseInt(value);
        if (port < 0 || port > 65535) {
            throw new ParameterException("Parameter " + name + " should be between 0 and 65535 (found " + value +")");
        }
    }

}

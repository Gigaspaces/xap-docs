package com.gs.test.client;

import java.util.logging.Logger;

import net.jini.lease.LeaseListener;
import net.jini.lease.LeaseRenewalEvent;

public class MyLeaseListener implements LeaseListener{

	Logger logger = Logger.getLogger(this.getClass().getName());

	public MyLeaseListener ()
	{
	}
	
	public void notify(LeaseRenewalEvent event) {
		logger.info("LeaseRenewalEvent failed. Received the Event " + event);
	}
}

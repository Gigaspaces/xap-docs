package com.tricode.gigaspaces.rules.shared.remoting;

import com.tricode.gigaspaces.rules.shared.fact.IFact;
import org.openspaces.remoting.Routing;

import java.util.Collection;
import java.util.Map;

/**
 * Interface for rules executing remoting service.
 */
public interface IRulesExecutionService {

    /**
     * Executes rules in given rulesets.
     *
     * @param projectName  Name of the rules project.
     * @param rulesetNames Names of the rulesets to execute.
     * @param globals      Global data for rules engine.
     * @param facts        Facts to use with rules execution.
     * @return (Possibly) updated fact.
     */
    Collection<IFact> executeRules(@Routing String projectName, String[] rulesetNames, Map<String, Object> globals, Collection<IFact> facts);

    /**
     * Executes rules in given rulesets.
     *
     * @param projectName  Name of the rules project.
     * @param rulesetNames Names of the rulesets to execute.
     * @param facts        Facts to use with rules execution.
     * @return (Possibly) updated fact.
     */
    Collection<IFact> executeRules(@Routing String projectName, String[] rulesetNames, Collection<IFact> facts);

}
package com.gigaspaces.util;

import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;

import com.j_spaces.core.admin.IRemoteJSpaceAdmin;
import com.j_spaces.core.admin.SpaceRuntimeInfo;

/**
 * Space related common functions
 */
public class SpaceUtil {

    private static final Logger logger = Logger.getLogger(SpaceUtil.class.getName());

    /**
     * Returns a count of the objects in the provided space.
     *
     * @param space Space proxy
     * @param objectName Class name to count instances
     * @return Count of the instances
     * @throws java.rmi.RemoteException Errors connecting to space
     */
    public static int getEntryCount(GigaSpace space, String objectName) {

    	IRemoteJSpaceAdmin spaceAdmin;
		try {
			spaceAdmin = (IRemoteJSpaceAdmin) space.getSpace().getAdmin();
	        SpaceRuntimeInfo rtInfo = spaceAdmin.getRuntimeInfo();

	        logger.info("Object types found in Space = " + rtInfo.m_ClassNames.size());

	        for (int i = 0; (i < rtInfo.m_ClassNames.size()); i++) {

	            if (logger.isLoggable(Level.FINE))
	                logger.fine(rtInfo.m_ClassNames.get(i));

	            if (rtInfo.m_ClassNames.get(i).equals(objectName)) {
	                if (logger.isLoggable(Level.FINEST))
	                    logger.finest(rtInfo.m_NumOFEntries.get(i).toString());
	                return rtInfo.m_NumOFEntries.get(i);
	            }
	        }

		} catch (RemoteException e) {
			logger.severe(e.getMessage());
			e.printStackTrace();
		}
        return 0;
    }
}

package com.giagspaces.patterns.uow;

public interface UOWProcessorService {
	int getBucketsCount();
}

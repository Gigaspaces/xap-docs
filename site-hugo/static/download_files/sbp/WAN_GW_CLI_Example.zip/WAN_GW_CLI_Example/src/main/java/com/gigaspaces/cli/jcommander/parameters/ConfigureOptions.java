package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;
import com.gigaspaces.cli.jcommander.PortValidator;

import java.util.List;

public class ConfigureOptions extends ValidateableOptions {
    @Parameter(names={"--name"}, description = "Name of gateway to configure.")
    private String gatewayName;

    @Parameter(names = {"-a", "--add"}, description = "Perform task as an add operation.")
    private boolean add;

    @Parameter(names = {"-r", "--remove"}, description = "Perform task as a remove operation.")
    private boolean remove;

    @Parameter(names = {"-m", "--modify"}, description = "Perform task as a change operation.")
    private boolean modify;

    @Parameter(names = {"-n", "--remote-gateway-name"}, description = "The remote gateway name.")
    private String remoteGatewayName;

    //Lookup + delegator + sink
    @Parameter(names = {"-c", "--communication-port"}, description = "The gateway communication port.", validateWith = PortValidator.class)
    private Integer communicationPort;

    // Sink + delegator
    @Parameter(names = {"--username"}, description = "Username for sinking/delegating to a secured grid.")
    private String username;

    @Parameter(names = {"--password"}, description = "Password for sinking/delegating to a secured grid.")
    private String password;

    //Delegator parameters
    @Parameter(names = {"-D", "--delegator"}, description = "Indicates the desired task will be against this gateway's delegators.")
    private String delegator;

    @Parameter(names = {"--target"}, description = "The delegator's target.")
    protected String target;

    //Sink parameters
    @Parameter(names = {"-S", "--sink"}, description = "Indicates the desired task will be against this gateway's sinks.")
    private String sink;

    @Parameter(names = {"--local-space-url"}, description = "The space local to this gateway instance.")
    private String localSpaceURL;

    @Parameter(names = {"--source"}, description = "The sink's data source.")
    protected String source;

    @Parameter(names = {"--requires-bootstrap"}, description = "Indicates if this gateway requires bootstrapping on deploy.")
    protected boolean requireBootstrap;

    // Lookup-specific parameters
    @Parameter(names = {"-L", "--gateway-lookup"}, description = "The gateway's lookup locator")
    private boolean gatewayLookup;

    @Parameter(names = {"-h", "--host"}, description = "The host of the gateway.")
    private String hostName;

    @Parameter(names = {"-d", "--discovery-port"}, description = "Discovery port for the lookup locator.", validateWith = PortValidator.class)
    private Integer discoveryPort;

    public boolean isStartEmbeddedLus() {
        return startEmbeddedLus;
    }

    @Parameter(names ={ "--start-embedded-lus" }, description = "Will start an embedded LUS instance.")
    private boolean startEmbeddedLus;

    public String getGatewayName(){
        return gatewayName;
    }

    public boolean isAdd() {
        return add;
    }

    public boolean isRemove() {
        return remove;
    }

    public boolean isModify() {
        return modify;
    }

    public boolean isGatewayLookup() {
        return gatewayLookup;
    }

    public String getRemoteGatewayName() {
        return remoteGatewayName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSink() {
        return sink;
    }

    public boolean isSink() {
        return sink != null;
    }

    public String getLocalSpaceURL() {
        return localSpaceURL;
    }

    public boolean isRequireBootstrap() {
        return requireBootstrap;
    }

    public String getSource() {
        return source;
    }

    public String getDelegator() {
        return delegator;
    }

    public boolean isDelegator(){
        return delegator != null;
    }

    public String getTarget() {
        return target;
    }

    public String getHostName() {
        return hostName;
    }

    public Integer getDiscoveryPort() {
        return discoveryPort;
    }

    public Integer getCommunicationPort() {
        return communicationPort;
    }

    @Override
    public String toString() {
        return "ConfigureOptions{" +
                "gatewayName=" + gatewayName +
                ", add=" + add +
                ", remove=" + remove +
                ", modify=" + modify +
                ", remoteGatewayName='" + remoteGatewayName + '\'' +
                ", communicationPort=" + communicationPort +
                ", username='" + username + '\'' +
                ", password='" + getScrubbedPassword() + '\'' +
                ", delegator='" + delegator + '\'' +
                ", target='" + target + '\'' +
                ", sink='" + sink + '\'' +
                ", localSpaceURL='" + localSpaceURL + '\'' +
                ", source='" + source + '\'' +
                ", requireBootstrap=" + requireBootstrap +
                ", gatewayLookup=" + gatewayLookup +
                ", hostName='" + hostName + '\'' +
                ", discoveryPort=" + discoveryPort +
                '}';
    }

    private String getScrubbedPassword() {
        return password == null ? password : "*****";
    }

    @Override
    public void validate() {
        if(getGatewayName() == null) throw new IllegalArgumentException("Argument [name] cannot be null.");

        int taskCount = 0;

        if(isAdd()) taskCount++;
        if(isRemove()) taskCount++;
        if(isModify()) taskCount++;

        if((!isAdd() && !isModify() && !isRemove()) || taskCount > 1) throw new IllegalArgumentException("One and only one task should be specified (add,remove,modify)");
    }
}

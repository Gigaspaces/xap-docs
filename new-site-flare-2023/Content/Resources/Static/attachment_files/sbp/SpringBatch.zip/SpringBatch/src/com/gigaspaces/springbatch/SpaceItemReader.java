package com.gigaspaces.springbatch;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoContext;
import org.openspaces.core.context.GigaSpaceContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.InitializingBean;

import com.j_spaces.core.client.SpaceURL;

public class SpaceItemReader<T> implements ItemReader<T>, InitializingBean  {

	@GigaSpaceContext
	GigaSpace space;
	
	@ClusterInfoContext
	ClusterInfo clusterInfo;
	int instanceID = 0;

	boolean blocking = true;
	boolean dedicatedWorker= true;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		if (clusterInfo!=null) instanceID=clusterInfo.getInstanceId();
		System.out.println("SpaceItemReader been created - Instance ID:"+instanceID + " Blocking mode:" + blocking);
	}

	@Override
	public T read() throws Exception, UnexpectedInputException, ParseException,
			NonTransientResourceException {
		System.out.println("SpaceItemReader called");
		ItemRequest request=null;
		ItemRequest requestTemplate=new ItemRequest();

		if (dedicatedWorker)
		{
			if (clusterInfo == null)
			{
				System.out.println("Running a single Item Reader");
			}
			else
			{
				String total_members = space.getSpace().getURL().getProperty(SpaceURL.CLUSTER_TOTAL_MEMBERS);
				int partitionCount=1;
				if (total_members != null)
					partitionCount = Integer.valueOf(total_members .substring(0,total_members.indexOf(","))).intValue();

		        int routingValue = (clusterInfo.getInstanceId() - 1) % partitionCount;
				requestTemplate.setRouting(routingValue);
				System.out.println("-> "+ space.getSpace().getName() +" Space got " + partitionCount+ " partitions - Worker Routing value:"+routingValue);
			}
		}
		
		while (true)
		{
			if (blocking)
				request =space.take(requestTemplate, 10000); 
			else
			{
				request=space.take(requestTemplate, 0);
				if (request==null)
				{
					Thread.sleep(1000);
				}
			}
			if (request !=null)
				break;
		}
		return (T)request; 
	}

	public boolean isBlocking() {
		return blocking;
	}

	public void setBlocking(boolean blocking) {
		this.blocking = blocking;
	}

	public boolean isDedicatedWorker() {
		return dedicatedWorker;
	}

	public void setDedicatedWorker(boolean dedicatedWorker) {
		this.dedicatedWorker = dedicatedWorker;
	}
}

package com.gigaspaces.client;

import java.util.Random;
import java.util.logging.Logger;

import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.core.transaction.manager.LocalJiniTxManagerConfigurer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.gigaspaces.domain.Order;
import com.gigaspaces.domain.OrderType;
import com.gigaspaces.domain.Product;
import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.ReadModifiers;
import com.j_spaces.core.client.SQLQuery;
import com.j_spaces.core.client.UpdateModifiers;

public class WriteOrders {

	Logger logger = Logger.getLogger(this.getClass().getName());
	GigaSpace gigaSpace = null;
	PlatformTransactionManager ptm = null;
	int batchSize = 1000;
	int totalProducts;

	static Random r = new Random();

	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("Usage: java TestClient <space URL>");
			System.exit(1);
		}

		WriteOrders testClient = new WriteOrders(args[0]);
	}

	/**
	 * Here we have the only constructor for this example TestClient
	 * 
	 * @param url
	 *            : the url to the space
	 */
	public WriteOrders(String url) {
		// connect to the space using its URL

		// connect to the space using its URL
		IJSpace space = new UrlSpaceConfigurer(url).space();
		// use gigaspace wrapper to for simpler API
		this.gigaSpace = new GigaSpaceConfigurer(space).gigaSpace();

		// Get a count of products in the space
		this.totalProducts = this.gigaSpace.count(new Product());

		try {
			ptm = new LocalJiniTxManagerConfigurer(space).transactionManager();
		} catch (Exception e1) {
			e1.printStackTrace();
			System.exit(-1);
		}

		this.gigaSpace = new GigaSpaceConfigurer(space).transactionManager(ptm)
				.gigaSpace();

		try {
			feed(); // run the feeder (start feeding)
		} catch (NumberFormatException e) {
			logger.info("Invalid argument passed, count not a number");
		}

	}

	public void feed() {

		logger.info("Feeder Starting write of messages");
		int counter = 0;
		Random r = new Random();

		while (true) {

			Order o = new Order();

			o.setId(counter);
			o.setRawData("Raw Order data " + counter);
			o.setProcessed(false);
			o.setOrderTime(System.currentTimeMillis());

			switch (r.nextInt(10)) {

			case 1:
			case 2:
				o.setType(OrderType.LOW);
				break;
			case 9:
				o.setType(OrderType.VIP);
				break;
			default:
				o.setType(OrderType.NORMAL);
			}

			// Add productId to the order
			int prodId = r.nextInt(totalProducts);
			o.setProductId(prodId + "");

			DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
			// configure the definition...
			TransactionStatus status = ptm.getTransaction(definition);

			gigaSpace.write(o, Lease.FOREVER, 10000,
					UpdateModifiers.UPDATE_OR_WRITE);

			if (updateQuantity(o)) {
				// Products exist
				ptm.commit(status);
				logger.info("Wrote new order " + o);
			} else {
				// Products dont exist
				logger.info("New order failed. No more products left " + o);
				ptm.rollback(status);
				
			}

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			counter ++;
		}
	}

	private boolean updateQuantity(Order o) {
		// Get the product and update quantities
		SQLQuery<Product> query = new SQLQuery<Product>(Product.class, "id = ? and quantity > 0", o.getProductId());
		
		Product p = gigaSpace.read(query);

		// Check if there are still products
		if (p != null) { 		
			// Write updated quantity
			p.setQuantity(p.getQuantity() - 1);
	
			gigaSpace.write(p, Lease.FOREVER, 10000,
					UpdateModifiers.UPDATE_OR_WRITE);
			
			return true;
		} else {
			return false;
		}
	}
}

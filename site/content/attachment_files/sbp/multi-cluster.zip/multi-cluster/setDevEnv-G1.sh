export JAVA_HOME=/opt/java/jdk1.6.0_21
export JSHOMEDIR=/opt/GigaSpaces/gigaspaces-xap-premium-7.1.2-ga
export GS_HOME=$JSHOMEDIR
export ANT_HOME=/opt/tools/apache-ant-1.8.1/
export M2_HOME=$JSHOMEDIR/tools/maven/apache-maven-2.0.9

export PATH=$JAVA_HOME/bin:$ANT_HOME/bin:$M2_HOME/bin:$JSHOMEDIR/bin:$PATH$

export LOOKUPGROUPS=group1
export LOOKUPLOCATORS=SK-GS

export COMMON_JAVA_OPTIONS=-Dcom.gs.multicast.enabled=false \
-XX:MaxPermSize=128m

echo $JSHOMEDIR
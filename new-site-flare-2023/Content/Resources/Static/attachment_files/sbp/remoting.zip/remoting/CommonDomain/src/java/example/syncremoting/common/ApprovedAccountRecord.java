package example.syncremoting.common;

import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceProperty;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.annotation.pojo.SpaceProperty.IndexType;

public class ApprovedAccountRecord {
    private String id;
    private String accountID;
    private Boolean isApproved;
    private String approvalCode;
  
	@SpaceId(autoGenerate=false)
    public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@SpaceRouting
	@SpaceProperty(index=IndexType.BASIC)
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public Boolean getIsApproved() {
		return isApproved;
	}
	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}
	public String getApprovalCode() {
		return approvalCode;
	}
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
  
}

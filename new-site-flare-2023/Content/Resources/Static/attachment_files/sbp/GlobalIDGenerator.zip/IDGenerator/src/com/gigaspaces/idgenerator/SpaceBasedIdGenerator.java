package com.gigaspaces.idgenerator;

import com.j_spaces.core.client.ReadModifiers;
import com.j_spaces.core.client.UpdateModifiers;
import net.jini.core.lease.Lease;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.context.GigaSpaceContext;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.springframework.transaction.annotation.*;

public class SpaceBasedIdGenerator {

    private int currentId = 0;
    
    @GigaSpaceContext
    GigaSpace gigaSpace;
    
    private int idLimit = -1;

	@Transactional(propagation=Propagation.REQUIRES_NEW)
    public synchronized Integer generateId() {
        if (currentId < 0 || currentId > idLimit) {
            getNextIdBatchFromSpace();
        }
        return currentId++;
    }

    private void getNextIdBatchFromSpace() {
        IdCounterEntry idCounterEntry = gigaSpace.readById(IdCounterEntry.class,0,0, 5000, ReadModifiers.EXCLUSIVE_READ_LOCK);
        if (idCounterEntry == null) {
            throw new RuntimeException("Could not get ID object from Space");
        }
        int[] range = idCounterEntry.getIdRange();
        currentId = range[0];
        idLimit = range[1];
        gigaSpace.write(idCounterEntry, Lease.FOREVER, 5000, UpdateModifiers.UPDATE_ONLY);
    }

    public void setGigaSpace(GigaSpace gigaSpace) {
        this.gigaSpace = gigaSpace;
    }


    public static void main(String[] args) throws Exception {
        GigaSpace gigaSpace = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/mySpace").space()).gigaSpace();
        SpaceBasedIdGenerator generator = new SpaceBasedIdGenerator();
        generator.setGigaSpace(gigaSpace);
        for (int i=0; i<300;i++) {
            int id = generator.generateId();
            if (i != id) {
                System.out.println("Unexpected ID, expected " + i +" and got " + id);
            }
        }
    }
}

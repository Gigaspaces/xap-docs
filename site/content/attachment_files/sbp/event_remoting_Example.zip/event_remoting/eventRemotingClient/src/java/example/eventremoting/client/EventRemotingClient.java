package example.eventremoting.client;

import java.util.TimerTask;
import java.util.concurrent.Future;

import example.eventremoting.common.SimpleService;

/**
 * A simple bean that is run within a Spring context that acts as the processing
 * unit context as well (when executed within a processing unit container).
 * 
 * <p>
 * This bean is designed to be invoked repeatedly by a TaskTimer
 * 
 * <p>
 * The TaskTimer and its factory are specified in the pu.xml
 */
public class EventRemotingClient extends TimerTask {
	SimpleService service = null;
	int count = 0;
	
	/**
	 * This method is called repeatedly by the TaskTimer
	 */
	public void run() {
		count++;
		System.out.println("---------------------------------------------------");
		System.out.println(new java.sql.Timestamp(System.currentTimeMillis()) + " About to invoke Service - Request #" + count);
		Future<String> result = service.asyncSay("Hi ", count);
		System.out.println(new java.sql.Timestamp(System.currentTimeMillis()) + " Got " + result.getClass().getSimpleName()+ " back...");
		try {
			System.out.println(new java.sql.Timestamp(System.currentTimeMillis()) + " Future.get() returns " + result.get() );
		} catch (Throwable t) {
		}
	}

	/**
	 * constructor
	 */
	public EventRemotingClient() {
		System.out.println(this.getClass().getSimpleName()
				+ ": I am being constructed.");
	}

	public void setService(SimpleService service) {
		this.service = service;
	}
}
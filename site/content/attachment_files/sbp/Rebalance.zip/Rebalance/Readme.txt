Readme for Rebalancing Agent
============================

1.  Rebalancing agent takes 4 arguments: 

    <locators>			Mandatory Lookup Locators
    <PU-name>			Mandatory PU name
    <sleep interval-ms>		Optional, default=2000ms
    <rebalance primaries>	Optional, default=true
					  false=concentrate PUs on one host

2.  Assumptions:

    This program makes the simplifying assumption that all machines have the same number of GSCs.


3.  Algorithm for rebalancing

    Rebalancing as implemented here is a 2 step process.  In the first step, partitions are "moved" from the most 
    crowded machine and GSC (machine and GSC with most partitions) to the least crowded Machine and GSC (GSC with least partitions) until the most and
    least crowded GSCs only have a partition number difference of one.  In the second step, on machines with too many
    primary partitions, these primary partition instances are restarted such that the corresponding backup becomes 
    a primary and the restarted partition becomes a backup.

4.  Instructions

    A. Rename run.xat to run.bat
    B. Modify paths in run.bat / run.sh
    C. Execute as below

5.  Sample Output


Ravi@Ravi-X201 /cygdrive/c/Work/GigaSpaces/Code/Eclipse/RebalancingAgent
$ ./run.bat Ravi-X201 datagrid
Args Length 2
Log file: C:\Software\gigaspaces-xap-premium-7.1.1-ga-b4515-2\logs\2010-06-29~22.59-gigaspaces-service-10.10.254.109-6724.log
2010-06-29 22:59:14,132  INFO [Rebalace Util] - Looking for datagrid ...
2010-06-29 22:59:15,169  INFO [Rebalace Util] - Found PU datagrid
2010-06-29 22:59:15,172  INFO [Rebalace Util] - datagrid--Number of partitions:      2
2010-06-29 22:59:15,173  INFO [Rebalace Util] - datagrid--Number of backup/primary:  1
2010-06-29 22:59:15,173  INFO [Rebalace Util] - datagrid--Number of instances:       4
2010-06-29 22:59:15,174  INFO [Rebalace Util] - ---- balancePrimariesOnAllHosts STARTED ----
2010-06-29 22:59:15,174  INFO [Rebalace Util] -
2010-06-29 22:59:15,175  INFO [Rebalace Util] - ===========================================================
2010-06-29 22:59:15,175  INFO [Rebalace Util] - Before Rebalancing:   Getting Spaces on Hosts
2010-06-29 22:59:15,175  INFO [Rebalace Util] - ===========================================================
2010-06-29 22:59:15,175  INFO [Rebalace Util] - Host:10.10.254.109
2010-06-29 22:59:15,175  INFO [Rebalace Util] - -------------------------
2010-06-29 22:59:16,468  INFO [Rebalace Util] -   ID:2 BACKUP   Instance Count:0
2010-06-29 22:59:16,513  INFO [Rebalace Util] -   ID:2 PRIMARY  Instance Count:0
2010-06-29 22:59:16,561  INFO [Rebalace Util] -   ID:1 PRIMARY  Instance Count:0
2010-06-29 22:59:16,608  INFO [Rebalace Util] -   ID:1 BACKUP   Instance Count:0
2010-06-29 22:59:16,608  INFO [Rebalace Util] - ===========================================================
2010-06-29 22:59:16,609  INFO [Rebalace Util] -
2010-06-29 22:59:16,609  INFO [Rebalace Util] -   ---- rebalanceInstanceCount STARTED ----
2010-06-29 22:59:16,610  INFO [Rebalace Util] -   Moving instance [1,2,BACKUP] from [GSC:host=Ravi-X201,pid=7084] to [GSC:host=Ravi-X201,pid=8760]
2010-06-29 22:59:31,116  INFO [Rebalace Util] -   Done Moving instance [1,2,BACKUP], hosting GSC is [GSC:host=Ravi-X201,pid=8760]
2010-06-29 22:59:31,117  INFO [Rebalace Util] -   Moving instance [2,2,BACKUP] from [GSC:host=Ravi-X201,pid=5716] to [GSC:host=Ravi-X201,pid=10044]
2010-06-29 22:59:44,825  INFO [Rebalace Util] -   Done Moving instance [2,2], hosting GSC is [GSC:host=Ravi-X201,pid=10044]
2010-06-29 22:59:46,827  INFO [Rebalace Util] -   Number of instances per GSC is balanced, delta = 0
2010-06-29 22:59:46,828  INFO [Rebalace Util] -   Attempted moving 2 instances!
2010-06-29 22:59:46,829  INFO [Rebalace Util] -   ---- rebalanceInstanceCount DONE ----
2010-06-29 22:59:46,831  INFO [Rebalace Util] -
2010-06-29 22:59:46,834  INFO [Rebalace Util] -   ---- rebalancePrimaryToBackup STARTED ----
2010-06-29 22:59:46,837  INFO [Rebalace Util] -   Num GSC per Machine = 4
2010-06-29 22:59:46,841  INFO [Rebalace Util] -   Num Machines = 1
2010-06-29 22:59:46,843  INFO [Rebalace Util] -   Max Amount Of Primary Spaces to Restart Per GSC = 1
2010-06-29 22:59:46,846  INFO [Rebalace Util] -   ==>> Moved 0 spaces into Backup Mode.
2010-06-29 22:59:46,849  INFO [Rebalace Util] -   ---- rebalancePrimaryToBackup DONE ----
2010-06-29 22:59:46,851  INFO [Rebalace Util] -
2010-06-29 22:59:46,854  INFO [Rebalace Util] - ---- balancePrimariesOnAllHosts DONE ----


package com.gigaspaces.examples.priorityq;

import org.openspaces.core.GigaSpace;
import com.j_spaces.core.client.SQLQuery;

class Monitor extends Thread {
	GigaSpace space;

	Monitor(GigaSpace  space) {
		this.space = space;
	}

	public void run() {
		System.out.println("Monitor Started");
		String queryStr = "priority > 0 order by priority" ; 
		SQLQuery query = new SQLQuery(Order.class.getName(),queryStr);

		try {
			while (true) {
				Object[] res = space.readMultiple(query , 1000);
				if (res.length >0)
				{
					String out ="The space Got:";
					for (int i=0;i<res.length ; i++)
					{
						Order res_ = (Order) res[i];
						out = out + " (prio="  + res_.priority + ") (id=" +res_.id + ") ," ;
					}
					System.out.println(out);
					
				}
				Thread.sleep(5000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
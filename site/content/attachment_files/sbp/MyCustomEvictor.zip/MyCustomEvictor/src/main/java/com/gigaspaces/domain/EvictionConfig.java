package com.gigaspaces.domain;

public class EvictionConfig {

	private Double evictionStartThreshold;
	private Double evictionStopThreshold;
	private Class[] evictionClasses;

	public Class[] getEvictionClasses() {
		return evictionClasses;
	}

	public void setEvictionClasses(Class[] evictionClasses) {
		this.evictionClasses = evictionClasses;
	}

	public Double getEvictionStartThreshold() {
		return evictionStartThreshold;
	}

	public void setEvictionStartThreshold(Double evictionStartThreshold) {
		this.evictionStartThreshold = evictionStartThreshold;
	}

	public Double getEvictionStopThreshold() {
		return evictionStopThreshold;
	}

	public void setEvictionStopThreshold(Double evictionStopThreshold) {
		this.evictionStopThreshold = evictionStopThreshold;
	}

}

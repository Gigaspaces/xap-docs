using System;

using GigaSpaces.Core;
using GigaSpaces.Examples.ExcelStocks.StockEntities;
using System.Threading;

namespace GigaSpaces.Examples.ExcelStocks.Feeder
{
	/// <summary>
	/// Writes Stock Data objects to the space and simulates Market behaviour.
	/// </summary>
	public class DataFeeder
	{
		private readonly ISpaceProxy _proxy;
		private const int _sleepTime = 100;


		public DataFeeder(ISpaceProxy proxy)
		{
			_proxy = proxy;
		}

		public void Load()
		{
			try
			{
				//	Clearing the space from Stock Data objects to ensure unique IDs
				ClearExistingStockData();
				// Write new Stock Data:
				Utils.LogMessage("\nWriting Stock Data objects to space:");
				WriteStocks();
				// Simulate market changes
				ChannelSimulate(_sleepTime);
			}
			catch (Exception ex)
			{
				Utils.LogException("Exception in ExcelStocks Feeder", ex);
			}
		}

		private void ClearExistingStockData()
		{
			// Create an empty Stock Data template:
			StockData template = new StockData();
			Utils.LogMessage("Clearing space of Stock Data objects...");
			_proxy.Clear(template);			
		}

		/// <summary>
		/// write the stock symbols to the spaces
		/// </summary>
		private void WriteStocks()
		{
			InitialStock[] initialStocks = InitialStock.InitialStocks;
			StockData[] stockData = new StockData[initialStocks.Length];
			for (int i = 0; i < initialStocks.Length; i++)
			{
				InitialStock initialStock = initialStocks[i];
				stockData[i] = new StockData(initialStock.Symbol, initialStock.OpeningValue);
				Utils.LogMessage(stockData[i].ToString());
			}
						
			_proxy.WriteMultiple(stockData);
			Utils.LogMessage("wrote " + stockData.Length + " to the Space");
		}

		private StockData ReadStock(String stockSymbol)
		{
			StockData stock = new StockData(stockSymbol);
			return _proxy.Read((stock));
		}

		private static String PickStockAtRandom()
		{
			Random random = new Random();
			InitialStock[] initialStocks = InitialStock.InitialStocks;
			return initialStocks[random.Next(initialStocks.Length)].Symbol;
		}

		private void GenerateNewStockValue()
		{
			String stockSymbol = PickStockAtRandom();
			StockData stockData = ReadStock(stockSymbol);
			Random random = new Random();
			double change = (Math.Round(random.NextDouble() * 100)) / 100.0;
			int bidSize = random.Next(10000000);
			int askSize = random.Next(10000000);
			double bid = ((Math.Round(random.NextDouble() * 100)) / 100.0) + stockData.Last.Value;
			bid = Math.Max(Math.Round(bid * 100) / 100.0, 0.0);
			double ask = ((Math.Round(random.NextDouble() * 100)) / 100.0) + stockData.Last.Value;
			ask = Math.Max(Math.Round(ask * 100) / 100, 0.0);
			stockData = stockData.ChangeRate(change, bidSize, askSize, bid, ask);
			_proxy.Update(stockData, null, int.MaxValue, 1000);
			Utils.LogMessage(stockData.Symbol + " was updated: " + stockData.Last + " " + DateTime.Now);
		}

		private void ChannelSimulate(int sleepTime)
		{
			Utils.LogMessage("Please open your Excel");
			while (true)
			{
				GenerateNewStockValue();
				Thread.Sleep(sleepTime);
			}
		}
	}
}
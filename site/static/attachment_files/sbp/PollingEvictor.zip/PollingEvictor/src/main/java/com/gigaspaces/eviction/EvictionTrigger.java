package com.gigaspaces.eviction;

import java.util.logging.Logger;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.polling.trigger.TriggerOperationHandler;
import org.springframework.dao.DataAccessException;

import com.gigaspaces.domain.Order;
import com.j_spaces.core.client.SQLQuery;

public class EvictionTrigger implements TriggerOperationHandler {

	Logger logger = Logger.getLogger(this.getClass().getName());

	private boolean useTriggerAsTemplate = false;

	// Purge order age - 1 day = 24 * 60 * 60 * 1000
	private long purgeAge = 24 * 60 * 60 * 1000;

	// Keep track of oldest order in space using this
	private long oldestOrderInSpace = 0;

	/**
	 * Controls if the object returned from
	 * {@link #triggerReceive(Object,org.openspaces.core.GigaSpace,long)} will
	 * be used as the template for the receive operation by returning
	 * <code>true</code>. If <code>false</code> is returned, the actual template
	 * configured in the polling event container will be used.
	 * 
	 * @see TriggerOperationHandler#isUseTriggerAsTemplate()
	 */
	public void setUseTriggerAsTemplate(boolean useTriggerAsTemplate) {
		this.useTriggerAsTemplate = useTriggerAsTemplate;
	}

	/**
	 * @see TriggerOperationHandler#isUseTriggerAsTemplate()
	 */
	public boolean isUseTriggerAsTemplate() {
		return this.useTriggerAsTemplate;
	}

	/**
	 * Uses {@link org.openspaces.core.GigaSpace#read(Object,long)} and returns
	 * its result.
	 */
	public Object triggerReceive(Object template, GigaSpace gigaSpace,
			long receiveTimeout) throws DataAccessException {
		
		// Create the query to get the orders
		SQLQuery<Order> newQuery = new SQLQuery<Order>(Order.class,
				" processed = true and orderTime < ?");

		oldestOrderInSpace = System.currentTimeMillis() - getPurgeAge();
		newQuery.setParameter(1, oldestOrderInSpace);

		Object snap = gigaSpace.snapshot(newQuery);

		Order order = (Order) gigaSpace.read(snap, receiveTimeout);

		// There are orders that can be evicted
		if (order != null) {
			return snap;
		} else {
			return null;
		}
	}
	
	public long getPurgeAge() {
		return purgeAge;
	}

	public void setPurgeAge(long purgeAge) {
		this.purgeAge = purgeAge;
	}

	public long getOldestOrderInSpace() {
		return oldestOrderInSpace;
	}

	public void setOldestOrderInSpace(long oldestOrder) {
		this.oldestOrderInSpace = oldestOrder;
	}
	
	@Override
	public String toString() {
		return "Read Trigger, useTriggerAsTemplate[" + useTriggerAsTemplate
				+ "], purgeAge[" + purgeAge + "]";
	}
}

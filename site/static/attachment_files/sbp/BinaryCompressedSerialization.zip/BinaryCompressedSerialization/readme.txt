-------
Purpose:
-------

The Binary Compressed Serialization example illustrates the default entry serialization and the Binary Compressed Serialization technique that provides better throughput and better memory footprint .

------------------------------
Building and running the demo:
------------------------------

Execute bin\compile.bat/sh in order to compile the demos. Execute bin\startSpace.bat/sh to start the space instance.  
Execute bin\runSimpleEntryTest.bat/sh to test the default Serialization.
See the output

Execute bin\runBinaryFormatEntryTest.bat/sh to test the Binary Compressed Serialization.
See the output

The runSimpleEntryTest and the runBinaryFormatEntryTest benchmark the writeMultiple , write , readMultiple , read , operations throughput.

The expected results for 32 Bit JVM:
The results for :BinaryFormatEntry
Average BinaryFormatEntry size = 525
BinaryFormatEntry - Average writeMultiple (1000 entries batch) TP = 42344 oper/sec
BinaryFormatEntry - Average write TP = 3350 oper/sec
BinaryFormatEntry - Average readMultiple  (1000 entries batch) TP = 90090 oper/sec
BinaryFormatEntry - Average read TP = 6031 oper/sec

The results for :SimpleEntry
Average SimpleEntry size = 1408
SimpleEntry - Average writeMultiple (1000 entries batch) TP = 12314 oper/sec
SimpleEntry - Average write TP = 2257 oper/sec
SimpleEntry - Average readMultiple  (1000 entries batch) TP = 44810 oper/sec
SimpleEntry - Average read TP = 3909 oper/sec


---------
The expected results for 64 Bit JVM:
The results for :BinaryFormatEntry
Average BinaryFormatEntry size = 758
BinaryFormatEntry - Average writeMultiple (1000 entries batch) TP = 23184 oper/sec
BinaryFormatEntry - Average write TP = 1715 oper/sec
BinaryFormatEntry - Average readMultiple  (1000 entries batch) TP = 44099 oper/sec
BinaryFormatEntry - Average read TP = 2738 oper/sec

The results for :SimpleEntry
Average SimpleEntry size = 2069
SimpleEntry - Average writeMultiple (1000 entries batch) TP = 21648 oper/sec
SimpleEntry - Average write TP = 1575 oper/sec
SimpleEntry - Average readMultiple  (1000 entries batch) TP = 36289 oper/sec
SimpleEntry - Average read TP = 3629 oper/sec

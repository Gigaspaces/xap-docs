package com.epam.openspaces.persistency.kafka;

import com.gigaspaces.datasource.SpaceDataSource;

public class DummyExternalDataSource extends SpaceDataSource {

}

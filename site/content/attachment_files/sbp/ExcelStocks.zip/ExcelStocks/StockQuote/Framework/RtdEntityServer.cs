using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Office.Interop.Excel;

using GigaSpaces.Core;
using GigaSpaces.Core.Events;
using System.Windows.Forms;

namespace GigaSpaces.Examples.ExcelStocks.Quote.Framework
{
    /// <summary>
    /// Base class for Rtd entity servers
    /// </summary>
    /// <typeparam name="T"></typeparam>
    internal abstract class RtdEntityServer<T> : IDisposable where T : new()
    {
        private StringBuilder _errorLog;
        private Dictionary<object, RtdEntityInfo<T>> _entityCache;
        private Dictionary<int, object> _changes;
        private IRTDUpdateEvent _rtdUpdate;
    	private bool _messageBoxShown = false;
        
        private ISpaceProxy _proxy;

        public RtdEntityServer()
        {
            this._errorLog = new StringBuilder();
            this._entityCache = new Dictionary<object, RtdEntityInfo<T>>();
            this._changes = new Dictionary<int, object>();
        }

        /// <summary>
        /// Get pono instance field value by Pono's fieldName.
        /// </summary>
        /// <param name="instance">Pono instance</param>
        /// <param name="fieldName">Pono's field name</param>
        /// <returns>value of Pono's field by the fieldName</returns>
        protected abstract object GetFieldValue(T instance, string fieldName);

        /// <summary>
        /// update the Pono's key field value.
        /// </summary>
        /// <param name="instance">Pono instance</param>
        /// <param name="key">value to update the Pono</param>
        protected abstract void SetKey(T instance, object key);

        /// <summary>
        /// Get key value from instance
        /// </summary>
        /// <param name="instance"></param>
        /// <returns></returns>
        protected abstract object GetKey(T instance);

       
        /// <summary>
        /// connect to the remote space
        /// </summary>
        /// <param name="rtdUpdateEvent"></param>
        /// <param name="spaceUrl">connection url to the remote space</param>
        public void Connect(IRTDUpdateEvent rtdUpdateEvent, string spaceUrl)
        {
            this._rtdUpdate = rtdUpdateEvent;
            this._proxy = _proxy = SpaceProxyProviderFactory.Instance.FindSpace(spaceUrl);
        }

        /// <summary>
        /// get excel sell value from the sheet by topikId
        /// </summary>
        /// <param name="topicId">topicId is unique for the excel sell in this RTD function call</param>
        /// <param name="arguments">arguments array should be at least with key and </param>
        /// <returns></returns>
        public object GetTopicValue(int topicId, Array arguments)
        {
            // Validate number of arguments
            if (arguments.Length < 2)
                return "Error: Please provide the proper parameters.";

            // First argument is the Symbol.
            object key = arguments.GetValue(0).ToString().ToUpper();
            // Second argument is the type.
            string fieldName = arguments.GetValue(1).ToString().ToLower();
            // 3rd argument indicates if cell should be refreshed on change
            bool refreshOnChange = false;
            if (arguments.Length >= 3)
                refreshOnChange = arguments.GetValue(2).ToString().ToLower() == "true";

            if (fieldName.Equals("error log"))
                return GetErrorLog();
            
            RtdEntityInfo<T> rtdContainer;
            if (!_entityCache.TryGetValue(key, out rtdContainer))
            {
                rtdContainer = new RtdEntityInfo<T>();
                T template = new T();
                SetKey(template, key);
                rtdContainer.Entity = _proxy.Read<T>(template);
                if (rtdContainer.Entity == null)
                    return "Symbol not found";
                rtdContainer.Listener = _proxy.DefaultDataEventSession.AddListener<T>(
                    template, Space_DataChanged);
                _entityCache.Add(key, rtdContainer);
            }

            rtdContainer.Topics[topicId] = new RtdTopicInfo(topicId, fieldName, refreshOnChange);

            // Check the value and act appropriately.  
            return GetFieldValue(rtdContainer.Entity, fieldName);
        }

        /// <summary>
        /// update excel about changed entities in the remote space.
        /// </summary>
        /// <param name="topicCount">number of excel sells to be updated</param>
        /// <returns>topicIds and new sell values to update in the excel sheet </returns>
        public Array GetChanges(ref int topicCount)
        {
            object[,] resultArray = new object[2, _changes.Count];

            topicCount = 0;
            lock (_changes)
            {
                foreach (KeyValuePair<int, object> kvp in _changes)
                {   
                    //kvp.key contains topicId
                    resultArray[0, topicCount] = kvp.Key;
                    //kvp.Value contains new field value
                    resultArray[1, topicCount] = kvp.Value;
                    topicCount++;
                }

                _changes.Clear();
            }
            // Return the updates.
            return resultArray;
        }

        /// <summary>
        /// save error in errors log
        /// </summary>
        /// <param name="logMessage">error message header</param>
        /// <param name="ex">exception to put in error log</param>
        public void LogError(string logMessage, Exception ex)
        {

			if (!_messageBoxShown)
			{
				_messageBoxShown = true;
				MessageBox.Show(logMessage + ex.Message + ex.StackTrace);
			}

        	_errorLog.Append(DateTime.Now.ToString());
            _errorLog.Append(logMessage + " Message:");
            _errorLog.AppendLine(ex.Message);
            _errorLog.AppendLine();
            _errorLog.AppendLine(ex.StackTrace);
            _errorLog.AppendLine();
        }

        /// <summary>
        /// convert errors from errors log
        /// </summary>
        /// <returns>errors list in one string</returns>
        public string GetErrorLog()
        {
            if (_errorLog.ToString().Trim().Equals(""))
            {
                return "Error log is empty.";
            }
            else
            {
                return _errorLog.ToString();
            }
        }

        /// <summary>
        /// called from notification delegate
        /// </summary>
        /// <param name="sender"> sender JsDataEventSession instance</param>
        /// <param name="e">SpaceDataEventArgs instance with changed Pono instance</param>
        private void Space_DataChanged(object sender, SpaceDataEventArgs<T> e)
        {
            try
            {
                RtdEntityInfo<T> container;
                if (_entityCache.TryGetValue(GetKey(e.Object), out container))
                {
					container.Entity = e.Object;
                    foreach (RtdTopicInfo topicInfo in container.Topics.Values)
                    {
                        if (topicInfo.RefreshOnChange)
                        {
                            lock (_changes)
                            {
                                _changes[topicInfo.TopicId] = GetFieldValue(container.Entity, topicInfo.FieldName);
                            }
                        }
                    }
                    //Tell Excel that we have updates. 
                    _rtdUpdate.UpdateNotify();

                }
            }
            catch (Exception ex)
            {
				LogError("Error in Stock.Quote. Message:", ex);
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            // Clear the RTDUpdateEvent reference
            _rtdUpdate = null;

            // removing the listener 
            foreach (RtdEntityInfo<T> container in _entityCache.Values)
                _proxy.DefaultDataEventSession.RemoveListener(container.Listener);

            // clear the tables
            _entityCache.Clear();
            _changes.Clear();

            // clear the error log
            _errorLog = new StringBuilder();
        }

        #endregion
    }
}

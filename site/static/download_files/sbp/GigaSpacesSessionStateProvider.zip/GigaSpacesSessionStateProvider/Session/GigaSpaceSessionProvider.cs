using System;
using System.Configuration;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Diagnostics;
using System.Web;
using System.Web.Configuration;
using System.Web.SessionState;
using GigaSpaces.Core;
using GigaSpaces.Core.Events;
using GigaSpaces.Core.Exceptions;

namespace GigaSpaces.Practices.HttpSessionProvider
{
    /// <summary>
    /// Gigaspaces implementation of the Session State Store Provider abstract class
    /// </summary>
    public sealed class GigaSpaceSessionProvider : SessionStateStoreProviderBase
    {
        #region Members

        private SessionStateSection             _configSessionState;        
                
        private string                          _applicationName;
        private ISpaceProxy                     _proxy;

        /// <summary>
        /// If false, provider will not support expired sessions (Session_OnEnd events)
        /// </summary>
        private bool                            _supportSessionOnEndEvents;

        private SessionStateItemExpireCallback  _expireCallback;
        private IEventRegistration              _expireEventRegistration;        

        private IPreparedTemplate<SessionDataEntry> _applicationSessionTemplate;        

        /// <summary>
        /// If false, exceptions are thrown to the caller. If true,
        /// exceptions are written to the event log and a general exception is thrown to the caller
        /// </summary>
        private bool                            _writeExceptionsToEventLog;

        private const string _exceptionMessage = "An exception occurred. Please contact your administrator.";

        #endregion

        #region  Properties

        public bool WriteExceptionsToEventLog
        {
            get { return _writeExceptionsToEventLog; }
            set { _writeExceptionsToEventLog = value; }
        }

        public bool SupportSessionOnEndEvents
        {
            get { return _supportSessionOnEndEvents; }           
        }


        /// <summary>
        /// The ApplicationName property is used to differentiate sessions
        /// in the data source by application.
        /// </summary>
        public string ApplicationName
        {
            get { return _applicationName; }
        }

        #endregion

        #region  Dispose Methods

        /// <summary>
        /// Frees resources that are no longer in use.
        /// </summary>
        public override void Dispose()
        {
            if (_proxy != null)
            {
                //Clears the notify registration from the space            
                if (_supportSessionOnEndEvents && _expireEventRegistration != null)
                    _proxy.DefaultDataEventSession.RemoveListener(_expireEventRegistration);
                _proxy = null;
            }
        }

        #endregion

        #region Implemented Derived Abstract Methods

        /// <summary>
        /// This method is used to set property values for the provider 
        /// instance, including implementation-specific values and 
        /// options specified in the configuration file 
        /// (Machine.config or Web.config).
        /// </summary>
        /// <param name="name">The name of the provider</param>
        /// <param name="config">A NameValueCollection instance of configuration settings</param>
        public override void Initialize(string name, NameValueCollection config)
        {
           
            // Initialize values from web.config.        
            if (config == null)
                throw new ArgumentNullException("config");            

            if (String.IsNullOrEmpty( name ))
                name = "SpaceSessionProvider";

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Sample Space Session State Store provider");
            }

            // Initialize the abstract base class.
            base.Initialize(name, config);
                       
            // Initialize the ApplicationName property.          
            _applicationName =
              System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;            
           
            // Get <sessionState> configuration element.
            Configuration cfg =
              WebConfigurationManager.OpenWebConfiguration(ApplicationName);
            _configSessionState =
              (SessionStateSection)cfg.GetSection("system.web/sessionState");

            // Initialize connection string.
            ConnectionStringSettings connectionStringSettings =
              ConfigurationManager.ConnectionStrings[config["connectionStringName"]];

            if ( connectionStringSettings == null ||
              String.IsNullOrEmpty( connectionStringSettings.ConnectionString ))
            {
                throw new ProviderException("Connection string cannot be blank.");
            }

            // Initialize WriteExceptionsToEventLog
            _writeExceptionsToEventLog = false;

            if (config["writeExceptionsToEventLog"] != null)
            {
                if (config["writeExceptionsToEventLog"].ToUpper() == "TRUE")
                    _writeExceptionsToEventLog = true;
            }

            // Initialize SupportSessionOnEndEvents
            _supportSessionOnEndEvents = false;

            if (config["supportSessionOnEndEvents"] != null)
            {
                if (config["supportSessionOnEndEvents"].ToUpper() == "TRUE")
                    _supportSessionOnEndEvents = true;
            }             
            
            // Create a proxy to the space
			_proxy = GigaSpacesFactory.FindSpace(connectionStringSettings.ConnectionString); 
            _proxy.OptimisticLocking = true;

            // Creates a Session Data Entry template for this application
            _applicationSessionTemplate = _proxy.Snapshot( new SessionDataEntry(_applicationName) );
        }

        /// <summary>
        /// Takes as input a delegate that references the Session_OnEnd event defined 
        /// in the Global.asax file. If the session-state store provider supports the 
        /// Session_OnEnd event, a local reference to the SessionStateItemExpireCallback 
        /// parameter is set and the method returns true; otherwise, the method returns false.
        /// </summary>
        /// <param name="expireCallback">A delegate that references the Session_OnEnd event defined in the Global.asax file</param>
        /// <returns>true - if the session-state store provider supports the Session_OnEnd event</returns>
        public override bool SetItemExpireCallback(SessionStateItemExpireCallback expireCallback)
        {
            if (_supportSessionOnEndEvents)
            {
                try
                {
                    _expireCallback = expireCallback;

                    //Creates event session config that will auto renew its lease for session expire notification
                    //If this IIS will be removed that after 15 minutes the lease will expire
                    EventSessionConfig eventConfig = new EventSessionConfig();
                    eventConfig.AutoRenew = true;
                    eventConfig.AutoRenewFailed += new EventHandler<LeaseRenewalEventArgs>(eventConfig_AutoRenewFailed);
                    _proxy.DefaultDataEventSession = _proxy.CreateDataEventSession(eventConfig);
                    //Registers the listener to the lease expire event
                    _expireEventRegistration = _proxy.DefaultDataEventSession.AddListener(_applicationSessionTemplate, NotifySessionExpired, DataEventType.LeaseExpiration, 900000);

                    return true;
                }
                catch (Exception ex)
                {
                    if (WriteExceptionsToEventLog)
                    {
                        WriteToEventLog(ex, "SetItemExpireCallback");
                        throw new ProviderException(_exceptionMessage);
                    }
                    else
                    {
                        throw;
                    }
                }

            }
            else
                return false;

        }

        /// <summary>
        /// When auto renew on lease expire event fails, reregister to the data event session
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void eventConfig_AutoRenewFailed(object sender, LeaseRenewalEventArgs e)
        {
            _expireEventRegistration = _proxy.DefaultDataEventSession.AddListener(_applicationSessionTemplate, NotifySessionExpired, DataEventType.LeaseExpiration, 900000);
        }       


        /// <summary>
        /// If the newItem parameter is true, the SetAndReleaseItemExclusive method 
        /// inserts a new item into the data store with the supplied values. 
        /// Otherwise, the existing item in the data store is updated with the 
        /// supplied values, and any lock on the data is released. 
        /// Note that only session data for the current application that 
        /// matches the supplied SessionID value and lock identifier values is updated. 
        /// After the SetAndReleaseItemExclusive method is called, 
        /// the ResetItemTimeout method is called by SessionStateModule 
        /// to update the expiration date and time of the session-item data.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="data">A SessionStateStoreData object that contains the current session values to be stored</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        /// <param name="newItem">true - new item, false - existing item. </param>
        public override void SetAndReleaseItemExclusive(HttpContext context,
          string id,
          SessionStateStoreData item,
          object lockId,
          bool newItem)
        {                                      
            try
            {
                SessionDataEntry template = new SessionDataEntry(id, ApplicationName, lockId == null ? 0 : (int)lockId);

                if (newItem)
                {
                    // Clear an existing expired session if it exists.
                    _proxy.Clear(template);

                    // Write the new session item.
                    SessionDataEntry newSde = new SessionDataEntry(id, ApplicationName, item.Timeout, item);                    
                    _proxy.Write(newSde, item.Timeout * 60000);

                }
                else
                {
                    
                    if (_proxy.Count(template) == 1)                    
                    {
                        // found the entry for the same id, application and lockid
                        template.SetSessionStateStoreData(item);                        
                        template.Locked = LockedState.Unlocked;
						_proxy.Write(template, null, item.Timeout * 60000, _proxy.DefaultTimeout, WriteModifiers.PartialUpdate | WriteModifiers.UpdateOnly);
                    }                    
                }
            }
            // There could be two concurrent calls to set and release item exclusive
            catch (EntryVersionConflictException) { }
            // The session could have expired by now, in this case simply do nothing.
            catch (EntryNotInSpaceException) { }
            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "SetAndReleaseItemExclusive");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                {
                    throw;
                }
            }
        }        

        /// <summary>
        /// This method performs the same work as the GetItemExclusive method,
        /// except that it does not attempt to lock the session item in the data store. 
        /// The GetItem method is called when the EnableSessionState attribute is set to 
        /// ReadOnly
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="locked">Returns if the session is locked</param>
        /// <param name="lockAge">Returns the lock age if the session is locked</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        /// <param name="action">Returns the actions flags associated with this session</param>
        /// <returns>Session State Store Data</returns>
        public override SessionStateStoreData GetItem(HttpContext context,
          string id,
          out bool locked,
          out TimeSpan lockAge,
          out object lockId,
          out SessionStateActions actions)
        {
            
            return GetSessionStoreItem(
                    false,
                    context,
                    id,
                    out locked,
                    out lockAge,
                    out lockId,
                    out actions);            

        }


        /// <summary>
        /// Retrieves session values and information from the session data store and locks the
        /// session-item data at the data store for the duration of the request. 
        /// The GetItemExclusive method sets several output-parameter values that inform the 
        /// calling SessionStateModule about the state of the current session-state item in 
        /// the data store. 
        /// If no session item data is found at the data store, the GetItemExclusive method 
        /// sets the locked output parameter to false and returns null. 
        /// This causes SessionStateModule to call the CreateNewStoreData method 
        /// to create a new SessionStateStoreData object for the request. 
        /// If session-item data is found at the data store but the data is locked, 
        /// the GetItemExclusive method sets the locked output parameter to true, 
        /// sets the lockAge output parameter to the current date and time minus the 
        /// date and time when the item was locked, sets the lockId output parameter 
        /// to the lock identifier retrieved from the data store, and returns null. 
        /// This causes SessionStateModule to call the GetItemExclusive method again 
        /// after a half-second interval, to attempt to retrieve the session-item 
        /// information and obtain a lock on the data. If the value that the 
        /// lockAge output parameter is set to exceeds the ExecutionTimeout value, 
        /// SessionStateModule calls the ReleaseItemExclusive method to clear the lock 
        /// on the session-item data and then call the GetItemExclusive method again. 
        /// The actionFlags parameter is used with sessions whose Cookieless property 
        /// is true, when the regenerateExpiredSessionId attribute is set to true. 
        /// An actionFlags value set to InitializeItem (1) indicates that the entry 
        /// in the session data store is a new session that requires initialization. 
        /// Uninitialized entries in the session data store are created by a call 
        /// to the CreateUninitializedItem method. If the item from the session 
        /// data store is already initialized, the actionFlags parameter is set 
        /// to zero. 
        /// If your provider supports cookieless sessions, 
        /// set the actionFlags output parameter to the value returned from 
        /// the session data store for the current item. If the actionFlags 
        /// parameter value for the requested session-store item equals the 
        /// InitializeItem enumeration value (1), the GetItemExclusive method 
        /// should set the value in the data store to zero after setting the 
        /// actionFlags out parameter.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="locked">Returns if the session is locked</param>
        /// <param name="lockAge">Returns the lock age if the session is locked</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        /// <param name="actions">Returns the actions flags associated with this session</param>
        /// <returns>Session State Store Data</returns>
        public override SessionStateStoreData GetItemExclusive(HttpContext context,
          string id,
          out bool locked,
          out TimeSpan lockAge,
          out object lockId,
          out SessionStateActions actions)
        {
            return GetSessionStoreItem(
                    true,
                    context,
                    id,
                    out locked,
                    out lockAge,
                    out lockId,
                    out actions);
        }



        /// <summary>
        /// GetSessionStoreItem is called by both the GetItem and 
        /// GetItemExclusive methods. GetSessionStoreItem retrieves the 
        /// session data from the space. If the lockRecord parameter
        /// is true (in the case of GetItemExclusive), then GetSessionStoreItem
        /// locks the record and sets a new LockId and LockDate.
        /// </summary>
        /// <param name="lockRecord">Should the item be locked</param>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="locked">Returns if the session is locked</param>
        /// <param name="lockAge">Returns the lock age if the session is locked</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        /// <param name="actions">Returns the actions flags associated with this session</param>
        /// <returns>Session State Store Data</returns>
        private SessionStateStoreData GetSessionStoreItem(bool lockRecord,
          HttpContext context,
          string id,
          out bool locked,
          out TimeSpan lockAge,
          out object lockId,
          out SessionStateActions actions)
        {
            
            // Initial values for return value and out parameters.            
            lockAge = TimeSpan.Zero;
            lockId = null;
            locked = false;
            actions = SessionStateActions.None;

            try
            {
                /** 
                 * If no session item data is found at the data store, the GetItem/GetItemExclusive
                 * method sets the locked output parameter to false and returns null. 
                 */
                SessionDataEntry template = new SessionDataEntry(id, ApplicationName);
                SessionDataEntry sde = _proxy.Read(template);

                if (null == sde)
                {
                    return null;
                }

                // Set up some of the common return elements
                lockAge = new TimeSpan(DateTime.UtcNow.Ticks - sde.LockedTimeTicks);
                lockId = sde.LockId;
                actions = sde.Flags;
                // if its already locked then indicate that its locked and return null;
                if (sde.Locked == LockedState.Locked)
                {
                    locked = true;
                    return null;
                }

                // The entry is non-null, is not expired, and is not locked.   
                // Its not locked, increment the lockId, zero out the action flags, and return false for locked.   
                sde.LockId = (int)lockId + 1;
                sde.Flags = SessionStateActions.None;
                if (lockRecord)
                {
                    //GetItemExclusive
                    // Update the session with the new data, set the lock date to now
                    sde.Locked = LockedState.Locked;
                    sde.LockedTimeTicks = DateTime.UtcNow.Ticks;                                                                                
                }                

                _proxy.Write(sde, null, sde.Timeout * 60000, _proxy.DefaultTimeout, WriteModifiers.UpdateOnly);
                // updated successfully - prepare out variables accordingly
                lockAge = TimeSpan.Zero;
                lockId = sde.LockId;

                // If the actionFlags parameter is not InitializeItem, 
                // return stored SessionStateItemCollection.
                if (actions == SessionStateActions.InitializeItem)
                    return CreateNewStoreData(context, _configSessionState.Timeout.Minutes);
                else
                    return sde.GetSessionStateStoreData();
            }
            // A previous update was done, treat this as a locked session
            catch (EntryVersionConflictException)
            {
                locked = true;
                return null;
            }            
            // The session could have expired by now
            catch (EntryNotInSpaceException) 
            {
                locked = false;
                return null;
            }

            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "ReleaseItemExclusive");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                {
                    throw;
                }
            }
        }       

        /// <summary>
        /// Takes as input the HttpContext instance for the current request, 
        /// the SessionID value for the current request, and the lock identifier for the current request, 
        /// and releases the lock on an item in the session data store. 
        /// This method is called when the GetItem or GetItemExclusive method is called 
        /// and the data store specifies that the requested item is locked, but the lock age has exceeded 
        /// the ExecutionTimeout value. The lock is cleared by this method, freeing the item for use by other requests.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        public override void ReleaseItemExclusive(HttpContext context,
          string id,
          object lockId)
        {
            try
            {
                // Creates a template for the item to release
                SessionDataEntry template = new SessionDataEntry(id, ApplicationName, (int)lockId);
                // Make sure we are holding the right lockId
                SessionDataEntry sde = _proxy.Read(template);
                if (sde != null)                                
                {
                    //Reduce network load
                    sde.SessionItems = null;
                    sde.StaticObjects = null;
                    sde.ApplicationName = null;                    
                    sde.Locked = LockedState.Unlocked;
					_proxy.Write(sde, null, sde.Timeout * 60000, _proxy.DefaultTimeout, WriteModifiers.PartialUpdate | WriteModifiers.UpdateOnly);
                }                
            }
            // There could be two concurrent calls to release item exclusive.
            catch (EntryVersionConflictException) { }
            // The session could have expired by now, in this case simply do nothing.
            catch (EntryNotInSpaceException) { }

            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "ReleaseItemExclusive");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                {
                    throw;
                }
            }
        }


        /// <summary>
        /// Deletes the session information from the 
        /// data store where the data store item matches the supplied SessionID value, 
        /// the current application, and the supplied lock identifier. This method is 
        /// called when the Abandon method is called.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="lockId">The lock identifier for the current request</param>
        /// <param name="item">The session information</param>
        public override void RemoveItem(HttpContext context,
          string id,
          object lockId,
          SessionStateStoreData item)
        {
            try
            {                
                SessionDataEntry template = new SessionDataEntry(id, ApplicationName, (int)lockId);
                _proxy.Clear(template);
            }
            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "RemoveItem");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                    throw;
            }

        }



        /// <summary>
        /// The CreateUninitializedItem method is used with cookieless sessions 
        /// when the regenerateExpiredSessionId attribute is set to true, 
        /// which causes SessionStateModule to generate a new SessionID value 
        /// when an expired session ID is encountered.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        /// <param name="timeout">The Timeout value for the current session (In minutes)</param>
        public override void CreateUninitializedItem(HttpContext context,
          string id,
          int timeout)
        {
            try
            {
                SessionDataEntry sde = new SessionDataEntry(id, ApplicationName, timeout, null);
                sde.Flags = SessionStateActions.InitializeItem;
               
                _proxy.Write(sde, timeout * 60000);
               
            }
            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "CreateUninitializedItem");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                    throw;
            }

        }


        /// <summary>
        /// Returns a new 
        /// SessionStateStoreData object with an empty ISessionStateItemCollection object, 
        /// an HttpStaticObjectsCollection collection, and the specified Timeout value. 
        /// The HttpStaticObjectsCollection instance for the ASP.NET application can be 
        /// retrieved using the GetSessionStaticObjects method.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="timeout">The Timeout value for the current session( In Minutes )</param>
        /// <returns>New Store Data</returns>
        public override SessionStateStoreData CreateNewStoreData(
          HttpContext context,
          int timeout)
        {
            return new SessionStateStoreData(new SessionStateItemCollection(),
              SessionStateUtility.GetSessionStaticObjects(context),
              timeout);
        }



        /// <summary>
        /// The ResetItemTimeout method is called by SessionStateModule to update 
        /// the expiration date and time of the session-item data
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        /// <param name="id">The SessionID value for the current request</param>
        public override void ResetItemTimeout(HttpContext context,
                                              string id)
        {
            try
            {                
                SessionDataEntry template = new SessionDataEntry(id, ApplicationName);
                SessionDataEntry sde = _proxy.Read(template);
                if (sde != null)
                {
                    //Reduce network load
                    sde.SessionItems = null;
                    sde.StaticObjects = null;
                    sde.ApplicationName = null;
					_proxy.Write(sde, null, sde.Timeout * 60000, _proxy.DefaultTimeout, WriteModifiers.PartialUpdate | WriteModifiers.UpdateOnly);
                }                
            }
            // There could be two concurrent calls to reset item timeout.
            catch (EntryVersionConflictException) { }
            // The session could have expired by now, in this case simply do nothing.
            catch (EntryNotInSpaceException) { }
            catch (Exception ex)
            {
                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(ex, "ResetItemTimeout");
                    throw new ProviderException(_exceptionMessage);
                }
                else
                    throw;
            }
        }


        /// <summary>
        /// Performs any initialization required by your session-state store provider.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        public override void InitializeRequest(HttpContext context)
        {
        }


        /// <summary>
        /// Performs any cleanup required by our session-state store provider.
        /// </summary>
        /// <param name="context">The HttpContext instance for the current request</param>
        public override void EndRequest(HttpContext context)
        {
        }

        #endregion

        #region Private Methods

        /// <summary>
        ///  WriteToEventLog
        ///  This is a helper function that writes exception detail to the 
        ///  event log. Exceptions are written to the event log as a security
        ///  measure to ensure private database details are not returned to 
        ///  browser. If a method does not return a status or Boolean
        ///  indicating the action succeeded or failed, the caller also 
        ///  throws a generic exception.
        /// </summary>
        /// <param name="e"></param>
        /// <param name="action"></param>
        private void WriteToEventLog(Exception ex, string action)
        {
            EventLog log = new EventLog();
            log.Source = "SpaceSessionProvider";
            log.Log = "Application";

            string message =
              "An exception occurred communicating with the data source.\n\n";
            message += "Action: " + action + "\n\n";
            message += "Exception: " + ex.ToString();

            log.WriteEntry(message);
        }        


        /// <summary>
        /// Calls the call back method when a session has timed out
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Space data event arguments</param>
        private void NotifySessionExpired(object sender, SpaceDataEventArgs<SessionDataEntry> e)
        {
            //The session object that triggered the lease expire event
            SessionDataEntry releasedSession = e.Object;
            //Call the callback method with the session id and session state store data
            if (_expireCallback != null)
            {
                _expireCallback(releasedSession.SessionId, releasedSession.GetSessionStateStoreData());
            }

        }


        #endregion    
    }
}
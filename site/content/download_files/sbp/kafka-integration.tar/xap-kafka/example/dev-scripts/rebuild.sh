#!/bin/bash

pushd ..
mvn clean install
popd

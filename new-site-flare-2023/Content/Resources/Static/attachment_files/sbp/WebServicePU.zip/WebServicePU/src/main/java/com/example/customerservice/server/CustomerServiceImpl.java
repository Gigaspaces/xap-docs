/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.example.customerservice.server;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.xml.ws.WebServiceContext;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.context.GigaSpaceContext;
import org.springframework.beans.factory.InitializingBean;

import com.example.customerservice.Customer;
import com.example.customerservice.CustomerService;
import com.example.customerservice.NoSuchCustomer;
import com.example.customerservice.NoSuchCustomerException;
import com.j_spaces.core.client.SQLQuery;

public class CustomerServiceImpl implements CustomerService , InitializingBean{
    public CustomerServiceImpl()
    {
    	System.out.println(">>>>>>>>>> CustomerServiceImpl created");
    }
    /**
     * The WebServiceContext can be used to retrieve special attributes like the 
     * user principal. Normally it is not needed
     */
    @Resource
    WebServiceContext wsContext;
    
    @GigaSpaceContext
    GigaSpace space;
    
    public List<Customer> getCustomersByName(String name) throws NoSuchCustomerException {
        if ("None".equals(name)) {
            NoSuchCustomer noSuchCustomer = new NoSuchCustomer();
            noSuchCustomer.setCustomerName(name);
            throw new NoSuchCustomerException("Did not find any matching customer for name=" + name,
                                              noSuchCustomer);
        }

        List<Customer> customers = new ArrayList<Customer>();
        
        SQLQuery<Customer> query = new SQLQuery<Customer> (Customer.class , "name = ?");
        query.setParameter(1, name);
        Customer customersArry[] = space.readMultiple(query , Integer.MAX_VALUE);
        System.out.println("found " + customersArry.length + " Customers matching the name:"+name);

        for (int i = 0; i < customersArry.length; i++) {
        	customers.add(customersArry[i]);
		}
        return customers;
    }

    public void updateCustomer(Customer customer) {
        System.out.println(">>>>>>> update request was received");
        space.write(customer);
        System.out.println(">>>>>>> Customer written into the space");
    }

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println(">>>>>>>>>>> space " +space);
	}
}
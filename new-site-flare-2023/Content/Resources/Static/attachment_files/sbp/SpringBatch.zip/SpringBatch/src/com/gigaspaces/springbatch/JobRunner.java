package com.gigaspaces.springbatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.job.flow.FlowJob;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class JobRunner implements ApplicationContextAware,InitializingBean ,DisposableBean{

	FlowJob job ;
	SimpleJobLauncher launcher;
	Task launcherTask;
	
	@Override
	public void setApplicationContext(ApplicationContext appContent)
			throws BeansException {
		job = (FlowJob)appContent.getBean("spaceJob");
		launcher = (SimpleJobLauncher)appContent.getBean("jobLauncher");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		ExecutorService threadExecutor = Executors.newFixedThreadPool(1);
		launcherTask = new Task (launcher,job);
		threadExecutor.execute(launcherTask); 
	}

	static class Task implements Runnable
	{
		SimpleJobLauncher launcher;
		FlowJob job ;
		public JobExecution jobExecution;
		
		public Task(SimpleJobLauncher _launcher, FlowJob _job)
		{
			this.launcher=_launcher;
			this.job=_job;
		}
		
		public void run() {
			org.springframework.batch.core.JobParameters jobParameters = new JobParameters(); 
			try {
				jobExecution = launcher.run(job, jobParameters);
			} catch (Exception e) {
				e.printStackTrace();
			} 		
			
		}
		
	}

	public void destroy() throws Exception {
		launcherTask.jobExecution.stop();
	}
}

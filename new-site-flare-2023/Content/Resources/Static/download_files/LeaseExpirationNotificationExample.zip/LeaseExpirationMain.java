package com.test;

import java.util.concurrent.TimeUnit;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.space.Space;
import org.openspaces.admin.space.Spaces;
import org.openspaces.admin.space.events.SpaceModeChangedEventManager;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.notify.SimpleNotifyContainerConfigurer;
import org.openspaces.events.notify.SimpleNotifyEventListenerContainer;

public class LeaseExpirationMain {

	static int MAX_PARTITIONS = 1;

	public static void main(String[] args) throws Exception{
		GigaSpace spacePrimary = startClusterNode(1, true);
		GigaSpace spaceBackup = startClusterNode(1, false);

		GigaSpace gigaSpace = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/space")).gigaSpace();
		
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().createAdmin();
		Space space = admin.getSpaces().waitFor("space", 10, TimeUnit.SECONDS);
		
		Thread.sleep(2000);
		for (int i=0;i<space.getInstances().length;i++)
		{
			SimpleListener.spaceMode.put(space.getInstances()[i].getUid(), space.getInstances()[i].getMode());
		}
		
		SpaceModeChangedEventManager modeManager =  space.getSpaceModeChanged();
		MySpaceModeListener spaceModeListener = new MySpaceModeListener(space);
		modeManager.add(spaceModeListener);
		
		SimpleListener myListenr = new SimpleListener();
		SimpleNotifyEventListenerContainer notifyEventListenerContainer = new SimpleNotifyContainerConfigurer(
				gigaSpace).notifyLeaseExpire(true).
				template(new MyData()).eventListener(myListenr)
				.notifyContainer();

		int count = 0;
		while (true)
		{
			gigaSpace.write(new MyData(count) , 3000);
			count ++;
			Thread.sleep(1000);
		}
	}

	static GigaSpace startClusterNode(int id, boolean primary) {
		GigaSpace space;
		if (primary)
			space = new GigaSpaceConfigurer(new UrlSpaceConfigurer(
					"/./space?cluster_schema=partitioned-sync2backup&total_members="
							+ MAX_PARTITIONS + ",1&id=" + id)).gigaSpace();
		else
			space = new GigaSpaceConfigurer(new UrlSpaceConfigurer(
					"/./space?cluster_schema=partitioned-sync2backup&total_members="
							+ MAX_PARTITIONS + ",1&backup_id=1&id=" + id))
					.gigaSpace();

		return space;
	}

}

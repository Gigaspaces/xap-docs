package example.syncremoting.common;

public interface AccountQuery {	
    public Integer getNumberOfApprovedAccountsByZipCode(String zipCode);
}

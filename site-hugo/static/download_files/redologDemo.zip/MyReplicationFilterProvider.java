package com.test;

import org.openspaces.core.space.filter.replication.ReplicationFilterProviderFactory;

import com.j_spaces.core.cluster.IReplicationFilter;
import com.j_spaces.core.cluster.ReplicationFilterProvider;

public class MyReplicationFilterProvider extends ReplicationFilterProvider{

	public MyReplicationFilterProvider(IReplicationFilter inputFilter, IReplicationFilter outputFilter) {
		super(inputFilter, outputFilter);
	}


}

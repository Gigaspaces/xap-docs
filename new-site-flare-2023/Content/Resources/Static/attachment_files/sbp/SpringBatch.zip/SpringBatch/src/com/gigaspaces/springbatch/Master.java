package com.gigaspaces.springbatch;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.j_spaces.core.client.SpaceURL;

public class Master {
	static GigaSpace space;
	static int partitions;

	public static void main(String[] args) {
		space = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/mySpace")).gigaSpace(); 

		String total_members = space.getSpace().getURL().getProperty(SpaceURL.CLUSTER_TOTAL_MEMBERS);
		if (total_members != null)
			partitions = Integer.valueOf(total_members .substring(0,total_members.indexOf(","))).intValue();
		else
			partitions =1;

		for (int i=0;i<10;i++)
		{
			submitJob(i, 100);
		}
		System.exit(0);
	}

	static public void submitJob(int jobId , int tasksCount)
	{
		System.out.println(new Date(System.currentTimeMillis())+ " - Executing Job " +jobId);
		ItemRequest requests [] = new ItemRequest [tasksCount]; 
		AtomicInteger index = new AtomicInteger(0);
		for (int i=0;i<tasksCount; i++)
		{
			requests [i] = new  ItemRequest ();
			requests [i].setJobID(jobId);
			requests [i].setId(jobId + "_"+i);
			requests [i].setRouting(index.getAndIncrement() %partitions );
		}
		
		space.writeMultiple(requests);
		ItemResult resultTemplate = new ItemResult();
		resultTemplate.setJobID(jobId);
		while (true)
		{
			if (space.count(resultTemplate) == tasksCount)
			{	
				ItemResult results[] = space.takeMultiple(resultTemplate,Integer.MAX_VALUE);
				System.out.println(new Date(System.currentTimeMillis())+ " - Done executing Job " +jobId);
				break;
			}
			else
			{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

package com.gs.util;

import org.openspaces.remoting.RemoteResultReducer;
import org.openspaces.remoting.SpaceRemotingInvocation;
import org.openspaces.remoting.SpaceRemotingResult;

public class DataProcessorServiceReducer implements RemoteResultReducer<PartitionCount, PartitionCount >{

	public PartitionCount reduce(SpaceRemotingResult<PartitionCount>[] results, SpaceRemotingInvocation sri) throws Exception {

	    PartitionCount minPart = null;
	    for (SpaceRemotingResult<PartitionCount> result : results) {
	      if (result.getException() != null) {
	        System.out.println("Error in one of the partitions");
	      }
	      if (minPart != null) {
	    	  if (minPart.getCount() > result.getResult().getCount()) {
	    		  minPart = result.getResult();
	    	  }
	      }
	      else {
	    	  minPart = result.getResult();
	      }
	    }
	    return minPart;

	}
}

package com.test;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.SpaceProxyConfigurer;
import com.gigaspaces.async.AsyncFuture;

public class MainTaskExecutor {

	public static void main(String[] args) throws Exception{
		System.out.println("MainTaskExecutor started");

		String spaceName = "space";
		GigaSpace gigaSpace = new GigaSpaceConfigurer(new SpaceProxyConfigurer(spaceName)).gigaSpace();
		
		StartPollingContainerTask taskStartPC = new StartPollingContainerTask();
		System.out.println("Client Side - Executing Task version:" + taskStartPC.getVersionID());

		AsyncFuture result = gigaSpace.execute(taskStartPC);
		result.get();
		System.out.println("Client Side - Executed Task version:" + taskStartPC.getVersionID());

		Thread.sleep(5000);
		System.out.println("MainTaskExecutor terminated");
	}
}

package com.gigaspaces.web.jaas;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;

import org.eclipse.jetty.http.security.Credential;
import org.eclipse.jetty.plus.jaas.spi.AbstractLoginModule;
import org.eclipse.jetty.plus.jaas.spi.UserInfo;
import org.eclipse.jetty.util.log.Log;

/**
 * PropertyFileLoginModule
 * 
 * 
 */
public class MySecurityModule extends AbstractLoginModule {
	public static final String DEFAULT_FILENAME = "realm.properties";
	public static final Map fileMap = new HashMap();

	private String propertyFileName;

	/**
	 * Read contents of the configured property file.
	 * 
	 * @see javax.security.auth.spi.LoginModule#initialize(javax.security.auth.Subject,
	 *      javax.security.auth.callback.CallbackHandler, java.util.Map,
	 *      java.util.Map)
	 * @param subject
	 * @param callbackHandler
	 * @param sharedState
	 * @param options
	 */
	public void initialize(Subject subject, CallbackHandler callbackHandler,
			Map sharedState, Map options) {
		super.initialize(subject, callbackHandler, sharedState, options);
	}

	/**
	 * Any user with password as "password" will go thru successfully
	 * 
	 * @param username
	 * @throws Exception
	 */
	public UserInfo getUserInfo(String username) throws Exception {
		
		ArrayList roleList = new ArrayList();
		roleList.add("admin");
		UserInfo ui =  new UserInfo(username, Credential.getCredential("password") , roleList);
		
		return ui;
		
	}

}

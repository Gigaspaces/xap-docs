package com.tricode.gigaspaces.rules.shared.drools.model;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import org.drools.KnowledgeBase;

import java.io.Serializable;

@SpaceClass(persist = false, replicate = false)
public class DroolsContext implements Serializable {

    private static final long serialVersionUID = 3738043534134325175L;

    private String id;

    private String projectName;

    /**
     * Comma-separated list of ruleset names.
     */
    private String rulesetNames;

    private KnowledgeBase knowledgeBase;

    /**
     * Public no-arg constructor is required by GigaSpaces.
     */
    public DroolsContext() {
    }

    @SpaceId(autoGenerate = true)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRulesetNames() {
        return rulesetNames;
    }

    public void setRulesetNames(String rulesetNames) {
        this.rulesetNames = rulesetNames;
    }

    @SpaceRouting
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public KnowledgeBase getKnowledgeBase() {
        return knowledgeBase;
    }

    public void setKnowledgeBase(KnowledgeBase knowledgeBase) {
        this.knowledgeBase = knowledgeBase;
    }

}
package com.gigaspaces.examples.binaryserialization;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceIndex;
import com.gigaspaces.annotation.pojo.SpaceProperty;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.annotation.pojo.SpaceClass.IncludeProperties;

import com.gigaspaces.examples.binaryserialization.utils.BinaryInputStream;
import com.gigaspaces.examples.binaryserialization.utils.BinaryOutputStream;
import com.gigaspaces.metadata.index.SpaceIndexType;

@SpaceClass(includeProperties=IncludeProperties.EXPLICIT)
public class BinaryFormatEntry implements Externalizable
{
    private Long     queryField;
    private byte[]   _binary;

    private Long	_longFieldA1;
    private Long	_longFieldB1;
    private Long	_longFieldC1;
    private Long	_longFieldD1;
    private Integer	_intFieldA1;
    private Integer	_intFieldB1;
    private Integer	_intFieldC1;
    private Integer	_intFieldD1;
    private String	_stringFieldA1;
    private String	_stringFieldB1;
    private String	_stringFieldC1;
    private String	_stringFieldD1;

    private Long	_longFieldA2;
    private Long	_longFieldB2;
    private Long	_longFieldC2;
    private Long	_longFieldD2;
    private Integer	_intFieldA2;
    private Integer	_intFieldB2;
    private Integer	_intFieldC2;
    private Integer	_intFieldD2;
    private String	_stringFieldA2;
    private String	_stringFieldB2;
    private String	_stringFieldC2;
    private String	_stringFieldD2;

    private Long	_longFieldA3;
    private Long	_longFieldB3;
    private Long	_longFieldC3;
    private Long	_longFieldD3;
    private Integer	_intFieldA3;
    private Integer	_intFieldB3;
    private Integer	_intFieldC3;
    private Integer	_intFieldD3;
    private String	_stringFieldA3;
    private String	_stringFieldB3;
    private String	_stringFieldC3;
    private String	_stringFieldD3;

    public BinaryFormatEntry()
    {
    }

    public BinaryFormatEntry(long _queryField, 
			long longFieldA1, long longFieldB1, long longFieldC1, long longFieldD1,
			int intFieldA1, int intFieldB1, int intFieldC1, int intFieldD1,
			String stringFieldA1, String stringFieldB1, String stringFieldC1, String stringFieldD1,
			long longFieldA2, long longFieldB2, long longFieldC2, long longFieldD2,
			int intFieldA2, int intFieldB2, int intFieldC2, int intFieldD2,
			String stringFieldA2, String stringFieldB2, String stringFieldC2, String stringFieldD2,
			long longFieldA3, long longFieldB3, long longFieldC3, long longFieldD3,
			int intFieldA3, int intFieldB3, int intFieldC3, int intFieldD3,
			String stringFieldA3, String stringFieldB3, String stringFieldC3, String stringFieldD3)
    {
        queryField   = _queryField;

        _longFieldA1   = longFieldA1;
        _longFieldB1   = longFieldB1;
        _longFieldC1   = longFieldC1;
        _longFieldD1   = longFieldD1;
        _intFieldA1    =  intFieldA1;
        _intFieldB1    =  intFieldB1;
        _intFieldC1    =  intFieldC1;
        _intFieldD1    =  intFieldD1;
        _stringFieldA1 = stringFieldA1;
        _stringFieldB1 = stringFieldB1;
        _stringFieldC1 = stringFieldC1;
        _stringFieldD1 = stringFieldD1;

        _longFieldA2   = longFieldA2;
        _longFieldB2   = longFieldB2;
        _longFieldC2   = longFieldC2;
        _longFieldD2   = longFieldD2;
        _intFieldA2   =  intFieldA2;
        _intFieldB2    =  intFieldB2;
        _intFieldC2    =  intFieldC2;
        _intFieldD2    =  intFieldD2;
        _stringFieldA2 = stringFieldA2;
        _stringFieldB2 = stringFieldB2;
        _stringFieldC2 = stringFieldC2;
        _stringFieldD2 = stringFieldD2;

        _longFieldA3   = longFieldA3;
        _longFieldB3   = longFieldB3;
        _longFieldC3   = longFieldC3;
        _longFieldD3   = longFieldD3;
        _intFieldA3    =  intFieldA3;
        _intFieldB3    =  intFieldB3;
        _intFieldC3    =  intFieldC3;
        _intFieldD3    =  intFieldD3;
        _stringFieldA3 = stringFieldA3;
        _stringFieldB3 = stringFieldB3;
        _stringFieldC3 = stringFieldC3;
        _stringFieldD3 = stringFieldD3;
    }

    
	@SpaceRouting
	@SpaceIndex(type=SpaceIndexType.BASIC)
    public Long getQueryField()
    {
        return queryField;
    }
	
    public void setQueryField(Long _queryField)
    {
        queryField = _queryField;
    }

    @SpaceProperty()
	public byte[] getBinary() {
		return _binary;
	}

	public void setBinary(byte[] _binary) {
		this._binary = _binary;
	}

    public Long getLongFieldA1()
    {
        return _longFieldA1;
    }
    public void setLongFieldA1(Long longFieldA1)
    {
        _longFieldA1 = longFieldA1;
    }
    public Long getLongFieldB1()
    {
        return _longFieldB1;
    }
    public void setLongFieldB1(Long longFieldB1)
    {
        _longFieldB1 = longFieldB1;
    }
    public Long getLongFieldC1()
    {
        return _longFieldC1;
    }
    public void setLongFieldC1(Long longFieldC1)
    {
        _longFieldC1 = longFieldC1;
    }
    public Long getLongFieldD1()
    {
        return _longFieldD1;
    }
    public void setLongFieldD1(Long longFieldD1)
    {
        _longFieldD1 = longFieldD1;
    }
    public Integer getIntFieldA1()
    {
        return _intFieldA1;
    }
    public void setIntFieldA1(Integer intFieldA1)
    {
        _intFieldA1 = intFieldA1;
    }
    public Integer getIntFieldB1()
    {
        return _intFieldB1;
    }
    public void setIntFieldB1(Integer intFieldB1)
    {
        _intFieldB1 = intFieldB1;
    }
    public Integer getIntFieldC1()
    {
        return _intFieldC1;
    }
    public void setIntFieldC1(Integer intFieldC1)
    {
        _intFieldC1 = intFieldC1;
    }
    public Integer getIntFieldD1()
    {
        return _intFieldD1;
    }
    public void setIntFieldD1(Integer intFieldD1)
    {
        _intFieldD1 = intFieldD1;
    }
    public String getStringFieldA1()
    {
        return _stringFieldA1;
    }
    public void setStringFieldA1(String stringFieldA1)
    {
        _stringFieldA1 = stringFieldA1;
    }
    public String getStringFieldB1()
    {
        return _stringFieldB1;
    }
    public void setStringFieldB1(String stringFieldB1)
    {
        _stringFieldB1 = stringFieldB1;
    }
    public String getStringFieldC1()
    {
        return _stringFieldC1;
    }
    public void setStringFieldC1(String stringFieldC1)
    {
        _stringFieldC1 = stringFieldC1;
    }
    public String getStringFieldD1()
    {
        return _stringFieldD1;
    }
    public void setStringFieldD1(String stringFieldD1)
    {
        _stringFieldD1 = stringFieldD1;
    }

    public Long getLongFieldA2()
    {
        return _longFieldA2;
    }
    public void setLongFieldA2(Long longFieldA2)
    {
        _longFieldA2 = longFieldA2;
    }
    public Long getLongFieldB2()
    {
        return _longFieldB2;
    }
    public void setLongFieldB2(Long longFieldB2)
    {
        _longFieldB2 = longFieldB2;
    }
    public Long getLongFieldC2()
    {
        return _longFieldC2;
    }
    public void setLongFieldC2(Long longFieldC2)
    {
        _longFieldC2 = longFieldC2;
    }
    public Long getLongFieldD2()
    {
        return _longFieldD2;
    }
    public void setLongFieldD2(Long longFieldD2)
    {
        _longFieldD2 = longFieldD2;
    }
    public Integer getIntFieldA2()
    {
        return _intFieldA2;
    }
    public void setIntFieldA2(Integer intFieldA2)
    {
        _intFieldA2 = intFieldA2;
    }
    public Integer getIntFieldB2()
    {
        return _intFieldB2;
    }
    public void setIntFieldB2(Integer intFieldB2)
    {
        _intFieldB2 = intFieldB2;
    }
    public Integer getIntFieldC2()
    {
        return _intFieldC2;
    }
    public void setIntFieldC2(Integer intFieldC2)
    {
        _intFieldC2 = intFieldC2;
    }
    public Integer getIntFieldD2()
    {
        return _intFieldD2;
    }
    public void setIntFieldD2(Integer intFieldD2)
    {
        _intFieldD2 = intFieldD2;
    }
    public String getStringFieldA2()
    {
        return _stringFieldA2;
    }
    public void setStringFieldA2(String stringFieldA2)
    {
        _stringFieldA2 = stringFieldA2;
    }
    public String getStringFieldB2()
    {
        return _stringFieldB2;
    }
    public void setStringFieldB2(String stringFieldB2)
    {
        _stringFieldB2 = stringFieldB2;
    }
    public String getStringFieldC2()
    {
        return _stringFieldC2;
    }
    public void setStringFieldC2(String stringFieldC2)
    {
        _stringFieldC2 = stringFieldC2;
    }
    public String getStringFieldD2()
    {
        return _stringFieldD2;
    }
    public void setStringFieldD2(String stringFieldD2)
    {
        _stringFieldD2 = stringFieldD2;
    }

    public Long getLongFieldA3()
    {
        return _longFieldA3;
    }
    public void setLongFieldA3(Long longFieldA3)
    {
        _longFieldA3 = longFieldA3;
    }
    public Long getLongFieldB3()
    {
        return _longFieldB3;
    }
    public void setLongFieldB3(Long longFieldB3)
    {
        _longFieldB3 = longFieldB3;
    }
    public Long getLongFieldC3()
    {
        return _longFieldC3;
    }
    public void setLongFieldC3(Long longFieldC3)
    {
        _longFieldC3 = longFieldC3;
    }
    public Long getLongFieldD3()
    {
        return _longFieldD3;
    }
    public void setLongFieldD3(Long longFieldD3)
    {
        _longFieldD3 = longFieldD3;
    }
    public Integer getIntFieldA3()
    {
        return _intFieldA3;
    }
    public void setIntFieldA3(Integer intFieldA3)
    {
        _intFieldA3 = intFieldA3;
    }
    public Integer getIntFieldB3()
    {
        return _intFieldB3;
    }
    public void setIntFieldB3(Integer intFieldB3)
    {
        _intFieldB3 = intFieldB3;
    }
    public Integer getIntFieldC3()
    {
        return _intFieldC3;
    }
    public void setIntFieldC3(Integer intFieldC3)
    {
        _intFieldC3 = intFieldC3;
    }
    public Integer getIntFieldD3()
    {
        return _intFieldD3;
    }
    public void setIntFieldD3(Integer intFieldD3)
    {
        _intFieldD3 = intFieldD3;
    }
    public String getStringFieldA3()
    {
        return _stringFieldA3;
    }
    public void setStringFieldA3(String stringFieldA3)
    {
        _stringFieldA3 = stringFieldA3;
    }
    public String getStringFieldB3()
    {
        return _stringFieldB3;
    }
    public void setStringFieldB3(String stringFieldB3)
    {
        _stringFieldB3 = stringFieldB3;
    }
    public String getStringFieldC3()
    {
        return _stringFieldC3;
    }
    public void setStringFieldC3(String stringFieldC3)
    {
        _stringFieldC3 = stringFieldC3;
    }
    public String getStringFieldD3()
    {
        return _stringFieldD3;
    }
    public void setStringFieldD3(String stringFieldD3)
    {
        _stringFieldD3 = stringFieldD3;
    }

    public void pack() throws Exception
	{
        BinaryOutputStream output = new BinaryOutputStream();
        long nulls = getNulls();
        output.writeLong(nulls);

        if (_longFieldA1 != null)
        	output.writeLong(_longFieldA1);
        if (_longFieldB1 != null)
        	output.writeLong(_longFieldB1);
        if (_longFieldC1 != null)
        	output.writeLong(_longFieldC1);
        if (_longFieldD1 != null)
        	output.writeLong(_longFieldD1);
        if (_intFieldA1 != null)
        	output.writeInt(_intFieldA1);
        if (_intFieldB1 != null)
        	output.writeInt(_intFieldB1);
        if (_intFieldC1 != null)
        	output.writeInt(_intFieldC1);
        if (_intFieldD1 != null)
        	output.writeInt(_intFieldD1);
        if (_stringFieldA1 != null)
        	output.writeString(_stringFieldA1);
        if (_stringFieldB1 != null)
        	output.writeString(_stringFieldB1);
        if (_stringFieldC1 != null)
        	output.writeString(_stringFieldC1);
        if (_stringFieldD1 != null)
        	output.writeString(_stringFieldD1);

        if (_longFieldA2 != null)
        	output.writeLong(_longFieldA2);
        if (_longFieldB2 != null)
        	output.writeLong(_longFieldB2);
        if (_longFieldC2 != null)
        	output.writeLong(_longFieldC2);
        if (_longFieldD2 != null)
        	output.writeLong(_longFieldD2);
        if (_intFieldA2 != null)
        	output.writeInt(_intFieldA2);
        if (_intFieldB2 != null)
        	output.writeInt(_intFieldB2);
        if (_intFieldC2 != null)
        	output.writeInt(_intFieldC2);
        if (_intFieldD2 != null)
        	output.writeInt(_intFieldD2);
        if (_stringFieldA2 != null)
        	output.writeString(_stringFieldA2);
        if (_stringFieldB2 != null)
        	output.writeString(_stringFieldB2);
        if (_stringFieldC2 != null)
        	output.writeString(_stringFieldC2);
        if (_stringFieldD2 != null)
        	output.writeString(_stringFieldD2);

        if (_longFieldA3 != null)
        	output.writeLong(_longFieldA3);
        if (_longFieldB3 != null)
        	output.writeLong(_longFieldB3);
        if (_longFieldC3 != null)
        	output.writeLong(_longFieldC3);
        if (_longFieldD3 != null)
        	output.writeLong(_longFieldD3);
        if (_intFieldA3 != null)
        	output.writeInt(_intFieldA3);
        if (_intFieldB3 != null)
        	output.writeInt(_intFieldB3);
        if (_intFieldC3 != null)
        	output.writeInt(_intFieldC3);
        if (_intFieldD3 != null)
        	output.writeInt(_intFieldD3);
        if (_stringFieldA3 != null)
        	output.writeString(_stringFieldA3);
        if (_stringFieldB3 != null)
        	output.writeString(_stringFieldB3);
        if (_stringFieldC3 != null)
        	output.writeString(_stringFieldC3);
        if (_stringFieldD3 != null)
        	output.writeString(_stringFieldD3);

        _binary = output.toByteArray();
        output.close();
    }

	public void unpack() throws Exception
	{
        BinaryInputStream input = new BinaryInputStream(_binary);
        long nulls = input.readLong();
        int i = 0;

        if ((nulls & 1L << i) == 0)
            _longFieldA1 = input.readLong();
        i++;
        if ((nulls & 1L << i) == 0)
            _longFieldB1 = input.readLong();
        i++;
        if ((nulls & 1L << i) == 0)
            _longFieldC1 = input.readLong();
        i++;
        if ((nulls & 1L << i) == 0)
            _longFieldD1 = input.readLong();
        i++;
        if ((nulls & 1L << i) == 0)
            _intFieldA1 = input.readInt();
        i++;
        if ((nulls & 1L << i) == 0)
            _intFieldB1 = input.readInt();
        i++;
        if ((nulls & 1L << i) == 0)
            _intFieldC1 = input.readInt();
        i++;
        if ((nulls & 1L << i) == 0)
            _intFieldD1 = input.readInt();
        i++;
        if ((nulls & 1L << i) == 0)
            _stringFieldA1 = input.readString();
        i++;
        if ((nulls & 1L << i) == 0)
            _stringFieldB1 = input.readString();
        i++;
        if ((nulls & 1L << i) == 0)
            _stringFieldC1 = input.readString();
        i++;
        if ((nulls & 1L << i) == 0)
            _stringFieldD1 = input.readString();
        i++;

        if( (nulls & 2L << i) == 0 )
            _longFieldA2 = input.readLong();
        i++;
        if( (nulls & 2L << i) == 0 )
            _longFieldB2 = input.readLong();
        i++;
        if( (nulls & 2L << i) == 0 )
            _longFieldC2 = input.readLong();
        i++;
        if( (nulls & 2L << i) == 0 )
            _longFieldD2 = input.readLong();
        i++;
        if( (nulls & 2L << i) == 0 )
            _intFieldA2 = input.readInt();
        i++;
        if( (nulls & 2L << i) == 0 )
            _intFieldB2 = input.readInt();
        i++;
        if( (nulls & 2L << i) == 0 )
            _intFieldC2 = input.readInt();
        i++;
        if( (nulls & 2L << i) == 0 )
            _intFieldD2 = input.readInt();
        i++;
        if( (nulls & 2L << i) == 0 )
            _stringFieldA2 = input.readString();
        i++;
        if( (nulls & 2L << i) == 0 )
            _stringFieldB2 = input.readString();
        i++;
        if( (nulls & 2L << i) == 0 )
            _stringFieldC2 = input.readString();
        i++;
        if( (nulls & 2L << i) == 0 )
            _stringFieldD2 = input.readString();
        i++;

        if( (nulls & 3L << i) == 0 )
            _longFieldA3 = input.readLong();
        i++;
        if( (nulls & 3L << i) == 0 )
            _longFieldB3 = input.readLong();
        i++;
        if( (nulls & 3L << i) == 0 )
            _longFieldC3 = input.readLong();
        i++;
        if( (nulls & 3L << i) == 0 )
            _longFieldD3 = input.readLong();
        i++;
        if( (nulls & 3L << i) == 0 )
            _intFieldA3 = input.readInt();
        i++;
        if( (nulls & 3L << i) == 0 )
            _intFieldB3 = input.readInt();
        i++;
        if( (nulls & 3L << i) == 0 )
            _intFieldC3 = input.readInt();
        i++;
        if( (nulls & 3L << i) == 0 )
            _intFieldD3 = input.readInt();
        i++;
        if( (nulls & 3L << i) == 0 )
            _stringFieldA3 = input.readString();
        i++;
        if( (nulls & 3L << i) == 0 )
            _stringFieldB3 = input.readString();
        i++;
        if( (nulls & 3L << i) == 0 )
            _stringFieldC3 = input.readString();
        i++;
        if( (nulls & 3L << i) == 0 )
            _stringFieldD3 = input.readString();
        i++;

        input.close();
        _binary = null;
	}


    public void writeExternal(ObjectOutput out) throws IOException {
        short nulls = checkNulls();

        out.writeShort(nulls);
        if (queryField != null)
            out.writeLong(queryField);
        if (_binary != null)
        {
        	out.writeInt(_binary.length);
            out.write(_binary);
        }
	}

	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        int i=0;
        short nulls = in.readShort();

        if ((nulls & 1L << i) == 0)
          queryField = in.readLong();
        i++;
        
        if ((nulls & 1L << i) == 0)
        {
        	int length = in.readInt();
        	_binary = new byte[length];
             in.read(_binary);
        }
	}

    private long getNulls()
    {
        long nulls = 0;
        int i=0;


        nulls = ((_longFieldA1 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldB1 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldC1 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldD1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldA1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldB1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldC1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldD1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldA1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldB1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldC1 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldD1 == null) ? nulls | 1L << i : nulls );
        i++;

        nulls = ((_longFieldA2 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldB2 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldC2 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldD2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldA2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldB2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldC2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldD2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldA2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldB2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldC2 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldD2 == null) ? nulls | 1L << i : nulls );
        i++;

        nulls = ((_longFieldA3 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldB3 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldC3 == null)  ? nulls | 1L << i : nulls ) ;
        i++;
        nulls = ((_longFieldD3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldA3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldB3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldC3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_intFieldD3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldA3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldB3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldC3 == null) ? nulls | 1L << i : nulls );
        i++;
        nulls = ((_stringFieldD3 == null) ? nulls | 1L << i : nulls );
        i++;
        return nulls;
    }

    private short checkNulls() {
        short nulls = 0;
        int i = 0;

        nulls = (short) ((queryField == null) ? nulls | 1 << i : nulls);
        i++;
        nulls = (short) ((_binary == null) ? nulls | 1 << i : nulls);
        i++;
        return nulls;
    }
}

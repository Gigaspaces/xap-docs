package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;

public class DeployOptions extends ValidateableOptions {
    @Parameter( names = { "-n", "--name" }, description = "Name of gateway to deploy.")
    private String name;

    @Parameter( names = { "-z", "--zone" }, description = "Zone required for deployment.")
    private String zone;

    @Parameter(names = { "-b", "--bootstrap-source"}, description = "Causes bootstrapping to take place.")
    private String bootStrapSource;

    @Parameter(names = { "-t", "--bootstrap-timeout"}, description = "The number of seconds before a bootstrap timeout is reached.")
    private int timeout = 3600;

    @Parameter(names = { "--xap9" }, description = "Indicates whether or not this is XAP 9.x or 10.x.")
    private boolean xap9 = false;

    public String getBootStrapSource() {
        return bootStrapSource;
    }

    public String getName(){
        return name;
    }

    public String getZone() {
        return zone;
    }

    @Override
    public String toString() {
        return "DeployOptions{" +
                "name='" + name + '\'' +
                ", zone='" + zone + '\'' +
                ", bootStrapSource='" + bootStrapSource + '\'' +
                ", timeout=" + timeout +
                ", xap9=" + xap9 +
                '}';
    }

    @Override
    public void validate() {
        if(getName() == null) throw new IllegalArgumentException("Argument [name] cannot be null.");
    }

    public int getTimeout() {
        return timeout;
    }

    public boolean isXap9() {
        return xap9;
    }
}

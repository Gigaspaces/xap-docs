package com.gigaspaces.springbatch;

public class ItemResult  extends ItemBase{
	public ItemResult(){}	
}

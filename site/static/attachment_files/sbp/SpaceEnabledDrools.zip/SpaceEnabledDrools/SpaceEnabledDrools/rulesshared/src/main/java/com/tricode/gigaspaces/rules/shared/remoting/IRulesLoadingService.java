package com.tricode.gigaspaces.rules.shared.remoting;

import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRuleset;
import org.openspaces.remoting.Routing;

/**
 * Interface for rules loading remoting service.
 */
public interface IRulesLoadingService {

    /**
     * Loads the ruleset that is passed as argument (means: stores it in the space).
     *
     * @param ruleSet A rule set.
     */
    void loadRuleset(@Routing("getProjectName") DroolsRuleset ruleSet);

    /**
     * Unloads a ruleset. Passed object is used as template for finding the proper set to unload.
     *
     * @param ruleSet The ruleset to unload.
     */
    void unloadRuleset(@Routing("getProjectName") DroolsRuleset ruleSet);

    /**
     * Unloads all rule sets.
     */
    void unloadAllRulesets();

}
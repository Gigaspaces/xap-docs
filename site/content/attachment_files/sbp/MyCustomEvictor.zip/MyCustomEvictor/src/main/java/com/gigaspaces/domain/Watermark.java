package com.gigaspaces.domain;

import java.util.HashMap;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;

@SpaceClass
public class Watermark {

	private Class spaceClass = null;

	private String spaceClassName = null;

	private Long boundaryValue = null;

	private HashMap<Long,String> evictionStatistics = null;
	
	private Boolean evictionInProgress = null;

	@SpaceId(autoGenerate = false)
	public String getSpaceClassName() {
		return spaceClassName;
	}

	public void setSpaceClassName(String spaceClassName) {
		this.spaceClassName = spaceClassName;
	}

	public Class getSpaceClass() {
		return spaceClass;
	}

	public void setSpaceClass(Class spaceClass) {
		this.spaceClass = spaceClass;
	}

	public Long getBoundaryValue() {
		return boundaryValue;
	}

	public void setBoundaryValue(Long boundaryValue) {
		this.boundaryValue = boundaryValue;
	}

	
	public Boolean getEvictionInProgress() {
		return evictionInProgress;
	}

	public void setEvictionInProgress(Boolean evictionInProgress) {
		this.evictionInProgress = evictionInProgress;
	}

	public HashMap<Long, String> getEvictionStatistics() {
		return evictionStatistics;
	}

	public void setEvictionStatistics(HashMap<Long, String> evictionStatistics) {
		this.evictionStatistics = evictionStatistics;
	}

}

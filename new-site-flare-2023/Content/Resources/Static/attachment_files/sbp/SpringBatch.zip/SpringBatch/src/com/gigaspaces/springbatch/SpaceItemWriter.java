package com.gigaspaces.springbatch;

import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.context.GigaSpaceContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;

public class SpaceItemWriter<T> implements ItemWriter<T> , InitializingBean  {

	@GigaSpaceContext
	GigaSpace space;

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("SpaceItemWriter been created");
	}

	@Override
	public void write(List<? extends T> items) throws Exception {
		System.out.println("SpaceItemWriter called with "+  items.size()+" Space Have " + space.count(new ItemResult()) + " results");
	}
}

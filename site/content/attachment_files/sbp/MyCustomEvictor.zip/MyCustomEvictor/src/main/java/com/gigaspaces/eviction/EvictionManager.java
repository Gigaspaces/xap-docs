package com.gigaspaces.eviction;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryNotificationInfo;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

import javax.management.Notification;
import javax.management.NotificationEmitter;
import javax.management.NotificationListener;
import javax.management.openmbean.CompositeData;

import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.gigaspaces.domain.EvictionConfig;
import com.gigaspaces.domain.Watermark;
import com.j_spaces.core.client.SQLQuery;
import com.j_spaces.core.client.UpdateModifiers;

public class EvictionManager implements InitializingBean, NotificationListener {

	private final int EVICTION_BATCH_SIZE = 1000;
	private final int EVICTION_WINDOW_SIZE = 1000;

	private static final Logger logger = Logger.getLogger(EvictionManager.class
			.getName());

	private GigaSpace gs = null;
	private PlatformTransactionManager tm = null;

	private MemoryPoolMXBean heapMemory = null;
	private EvictionConfig ec = null;
	private AtomicBoolean evictionInProgress = new AtomicBoolean(false);
	private long evictionStartValue = 0;
	private long evictionStopValue = 0;

	private long spaceStartTime = 0l;

	public EvictionConfig getEc() {
		return ec;
	}

	public void setEc(EvictionConfig ec) {
		this.ec = ec;
	}

	public PlatformTransactionManager getTm() {
		return tm;
	}

	public void setTm(PlatformTransactionManager tm) {
		this.tm = tm;
	}

	public GigaSpace getGs() {
		return gs;
	}

	public void setGs(GigaSpace gs) {
		this.gs = gs;
	}

	@Override
	public void afterPropertiesSet() throws Exception {

		setJVMUsageThreshold();
		initializeData();
	}

	/**
	 * 
	 * Method uses the Java Memory Management API to register for memory usage
	 * notification whenever usage of Old gen pool reaches highWatermark
	 * 
	 * @param highWatermark
	 *            - Memory Usage Level where Eviction Logic should be triggered
	 * @throws RuntimeException
	 *             - RunTime Exception thrown on unsupported JVM
	 */
	private void setJVMUsageThreshold() throws RuntimeException {

		// Get Memory MXBean
		MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();

		// Add current object as the listener
		NotificationEmitter ne = (NotificationEmitter) memBean;
		ne.addNotificationListener(this, null, null);

		// Get the memory pools supported by the JVM and size of each pool
		List<MemoryPoolMXBean> memPools = ManagementFactory
				.getMemoryPoolMXBeans();

		for (MemoryPoolMXBean pool : memPools) {

			if (pool.getType() == MemoryType.HEAP
					&& pool.isUsageThresholdSupported()) {

				heapMemory = pool;

				long maxMemory = pool.getUsage().getMax();
				evictionStartValue = (long) (maxMemory * (ec
						.getEvictionStartThreshold() / 100));
				evictionStopValue = (long) (maxMemory * (ec
						.getEvictionStopThreshold() / 100));

				logger.info("Maximum Heap Memory : " + maxMemory);
				logger.info("Eviction Starts at heap size : "
						+ evictionStartValue);

				try {
					pool.setUsageThreshold(evictionStartValue);
				} catch (Exception e) {
					logger
							.severe("***** Setting usage Threshold on Old Gen pool failed "
									+ e.getMessage());
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Eviction status of each evictable object is tracked in space using a
	 * Watermark entry
	 */
	public void initializeData() {

		spaceStartTime = System.currentTimeMillis();

		logger.info("Creating Watermark objects in space");

		for (Class clazz : ec.getEvictionClasses()) {
			Watermark wm = new Watermark();
			wm.setSpaceClass(clazz);
			wm.setSpaceClassName(clazz.getName());
			wm.setBoundaryValue(null);

			// If it is a space restart/relocation or data already exists dont
			// write it again
			if (gs.read(wm) == null) {
				logger.info("Writing Watermark entry for class: "
						+ wm.getSpaceClass().getName());

				wm.setEvictionStatistics(new HashMap<Long, String>());
				wm.setBoundaryValue(spaceStartTime);
				gs.write(wm);
			}
		}

	}

	@Override
	public void handleNotification(Notification n, Object handback) {

		String type = n.getType();

		if (type.equals(MemoryNotificationInfo.MEMORY_THRESHOLD_EXCEEDED)) {

			// Run eviction logic only if no other instance of eviction is in
			// process right now
			if (evictionInProgress.compareAndSet(false, true)) {
				// Retrieve Memory Notification information
				CompositeData cd = (CompositeData) n.getUserData();
				MemoryNotificationInfo memInfo = MemoryNotificationInfo
						.from(cd);

				logger
						.info("Eviction Process Notification received. Memory Usage before Eviction started : "
								+ memInfo.getUsage().getUsed());

				evictObjects();
			} else {
				logger
						.warning("Memory Notification Worker received another notification while eviction is in progress. "
								+ type);
			}
		} else {
			logger
					.warning("Memory Notification Worker received invalid notification. "
							+ type);
		}
		// Set Eviction is not in process
		evictionInProgress.set(false);

	}

	/**
	 * 
	 */
	public void evictObjects() {

		Watermark[] evictionWatermarks = null;

		// Retrieve the Watermark objects from space
		try {
			logger.info("Eviction Logic started");

			Watermark template = new Watermark();
			evictionWatermarks = gs.readMultiple(template, Integer.MAX_VALUE);

			logger.info("Found " + evictionWatermarks.length
					+ " Eviction WaterMarks");

		} catch (Exception e) {
			logger.severe("Exception occured when reading Eviction WaterMarks "
					+ e.getMessage());
			e.printStackTrace();
		}

		// Execute eviction logic for each WaterMark retrieved from
		// the space
		if (evictionWatermarks != null && evictionWatermarks.length > 0) {

			for (Watermark curWM : evictionWatermarks) {
				evictObject(curWM);
			}
		}
	}

	/**
	 * Eviction of Objects passed in the argument
	 * 
	 * @param wMark
	 *            Watermark with the Eviction criterion
	 */
	public void evictObject(Watermark wMark) {

		String className = wMark.getSpaceClassName();
		long evictStartTime = 0L;
		long evictEndTime = 0L;
		long evictionStartMemoryUsage = heapMemory.getUsage().getUsed();
		long currentMemoryUsage = evictionStartMemoryUsage;
		boolean evictionObjectsAvailable = true;
		long evictionMaxKey = 0L;

		// Get the maximum key value for the entry. Assuming current maximum key
		// value. This logic is implemented to
		// eliminate the possiblity of going into an infinite loop which can
		// occur if app is clearing data and Eviction
		// Logic is running at the same time which might make the exit criterion
		// of eviction logic to never reach
		evictionMaxKey = getMaxKey(wMark);

		logger.info("Eviction of entry - " + className + " started");
		logger.info("Eviction Limit is [" + evictionStopValue
				+ "], Max Key is [" + evictionMaxKey + "]");

		// Update the Watermark object to indicate eviction is in progress
		wMark.setEvictionInProgress(true);
		gs.write(wMark, Lease.FOREVER, 5000, UpdateModifiers.UPDATE_OR_WRITE);

		evictStartTime = System.currentTimeMillis();

		// Keep evicting until eviction limit is reached
		// Some JVM's this may be expensive and might need
		// to switch to a limit that is based on heuristics
		while (currentMemoryUsage > evictionStopValue
				&& evictionObjectsAvailable) {

			long nextWindow = wMark.getBoundaryValue() + EVICTION_WINDOW_SIZE;

			String qryStr = "orderTime " + " < " + nextWindow + "L and processed = true";
			logger.info("SQL Query string \"" + qryStr + "\"");

			// Configure Transaction definition ...
			DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
			TransactionStatus status = tm.getTransaction(definition);

			boolean moreDataInBatch = true;
			try {
				SQLQuery template;

				template = new SQLQuery(wMark.getSpaceClass().newInstance(),
						qryStr);

				// Clear data in smaller batches in order to not create lots of
				// garbage in space and trigger GC activity
				// Execute the Space.clear() with the SQL Query template
				gs.clear(template);

			} catch (Exception e) {
				e.printStackTrace();
			}

			// Update EvictionWaterMarkEntry with current eviction statistics
			wMark.setBoundaryValue(nextWindow);

			gs.write(wMark, Lease.FOREVER, 5000,
					UpdateModifiers.UPDATE_OR_WRITE);

			// Commit the Transaction
			tm.commit(status);

			// Not recommended to perform GC from within the application. Doing
			// this only for making the prototype work
			Runtime.getRuntime().gc();

			if (nextWindow >= evictionMaxKey) {
				evictionObjectsAvailable = false;
			}

			currentMemoryUsage = heapMemory.getUsage().getUsed();
			logger.info("Current Memory Usage [" + currentMemoryUsage + "]");
		}

		evictEndTime = System.currentTimeMillis();

		// Update the Watermark object with statistics and mark that eviction is
		// complete
		HashMap<Long, String> wMarkStatistics = wMark.getEvictionStatistics();

		wMarkStatistics.put(evictStartTime, "startingMemoryUsage["
				+ evictionStartMemoryUsage + "],endingMemoryUsage["
				+ currentMemoryUsage + "],ended[" + evictEndTime + "]");

		wMark.setEvictionStatistics(wMarkStatistics);

		wMark.setEvictionInProgress(false);
		gs.write(wMark, Lease.FOREVER, 5000, UpdateModifiers.UPDATE_OR_WRITE);

		logger.info("Eviction for " + className
				+ " completed. Starting Memory Usage ["
				+ evictionStartMemoryUsage + "], Ending Memory Usage ["
				+ currentMemoryUsage + "]");

	}

	/**
	 * Retrieve the MAX Key for each Entry passed in the Watermark as argument
	 * 
	 * @param wMark
	 *            - Gets Information about the entry
	 * @return - Returns the maximum value
	 */
	public long getMaxKey(Watermark wMark) {
		// TODO Implement generic max ley retrieval logic
		return System.currentTimeMillis();
	}

}

package org.openspaces.riskcalc;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.core.ExecutorBuilder;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import com.gigaspaces.async.AsyncFuture;

public class Client {

	static String locator = System.getProperty("locators", "127.0.0.1");
	static Logger logger = Logger.getLogger("Client");
	static DecimalFormat formater = new DecimalFormat("0.0");
	static int MAX_TRADES = 10000;
	static double rates[] = {2,3,4,5,6,7,8};
	
	public static void main(String[] args) throws Exception{
		
		GigaSpace gigaspace = new GigaSpaceConfigurer(new UrlSpaceConfigurer("jini://*/*/RiskAnalysisDataGrid")).gigaSpace();
		// Try unmanaged Spaces. Maybe running the space within the IDE or using gsInstance
		Admin 	admin = new AdminFactory().discoverUnmanagedSpaces().addLocator(locator).createAdmin();

		if (admin == null)
		{
			System.out.println("Can locate lookup service and generate admin object. Exit");
			System.exit(0);
		}
		
		int partitionCount = admin.getSpaces().waitFor("RiskAnalysisDataGrid", 5, TimeUnit.SECONDS).getPartitions().length;

		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);

		System.out.println("We have " + partitionCount + " partitions");
		
		Integer[] ids  = new Integer[MAX_TRADES];
		for (int i=0;i<MAX_TRADES;i++)
		{
			ids [i] = i ;
		}
		
		// Mapping IDs to partition
		HashMap<Integer , HashSet<Integer>> partitionIDSDistro = splitIDs(ids , partitionCount );
		AnalysisTask analysisTasks[] = new AnalysisTask[partitionCount];
		
		for (int c=0;c<10000;c++)
		{
			Map<String, Double> positions = null;
			logger.info("Calculating Net present value for "  + MAX_TRADES + " Trades ...");
			ExecutorBuilder executorBuilder = gigaspace.executorBuilder(new NPVResultsReducer());
	
			// Creating the Tasks. Each partition getting a Task with the exact Trade IDs to calculate
			for (int r=0;r<rates.length; r++)
			{
				long startTime = System.currentTimeMillis();
				for (int i=0;i<partitionCount ; i++)
				{
					Integer partIDs[] = new Integer[partitionIDSDistro.get(i).size()];
					partitionIDSDistro.get(i).toArray(partIDs);
					analysisTasks[i] = new AnalysisTask(partIDs,i,rates[r]);
					executorBuilder.add(analysisTasks[i]);
				}
				
				AsyncFuture<HashMap<String, Double>> future = executorBuilder.execute();
				
				if (future !=null)
				{
					try
					{
						positions = future.get();
						long endTime = System.currentTimeMillis();
						logger.info("\nTime to calculate Net present value for " +MAX_TRADES  + " Trades using " +rates[r] + " % rate:" + (endTime - startTime) + " ms");
						for(String key: positions.keySet()){
							logger.info("Book = " + key + ", NPV = " + formater.format(positions.get(key)));
						}
						Thread.sleep(1000);
					}
					catch (Exception e)
					{}
				}
			}
		}		
		admin.close();
	}
	
	// splitting the IDs into chunks
	static HashMap<Integer , HashSet<Integer>> splitIDs(Integer[] ids , int partitionCount)
	{
		HashMap<Integer , HashSet<Integer>> routings = new HashMap<Integer , HashSet<Integer>> ();
		for (Integer id: ids) {
			int partition = (id % partitionCount);
			HashSet<Integer> partitionIDS = null;
			if (routings.containsKey(partition))
			{
				partitionIDS  = routings.get(partition);
			}
			else
			{
				partitionIDS = new HashSet<Integer>();
			}
			partitionIDS.add(id); 
			routings.put(partition, partitionIDS);
		}
		return routings ;
	}
}

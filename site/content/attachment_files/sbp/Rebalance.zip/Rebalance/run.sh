#!/bin/bash

export gs_home=/export/home//gigaspaces-xap-premium-7.1.1-ga-b4515-2/


set JARS=${gs_home}/lib/required/commons-logging.jar:${gs_home}/lib/required/gs-openspaces.jar:${gs_home}/lib/required/gs-runtime.jar:${gs_home}/lib/required/org.springframework.beans-3.0.1.RELEASE-A.jar:${gs_home}/lib/required/org.springframework.context-3.0.1.RELEASE-A.jar:${gs_home}/lib/required/org.springframework.context.support-3.0.1.RELEASE-A.jar:${gs_home}/lib/required/org.springframework.core-3.0.1.RELEASE-A.jar:${gs_home}/lib/required/org.springframework.expression-3.0.1.RELEASE-A.jar:${gs_home}/lib/required/org.springframework.transaction-3.0.1.RELEASE-A.jar

set CLASSES=./bin

java -classpath ${CLASSES}:${JARS} com.gigaspaces.admin.rebalance.RebalancingAgent $@

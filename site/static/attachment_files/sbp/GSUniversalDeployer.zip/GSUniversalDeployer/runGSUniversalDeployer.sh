JSHOMEDIR=`dirname $0`/../gigaspaces-xap-premium-8.0.1-ga; export JSHOMEDIR
. ${JSHOMEDIR}/bin/setenv.sh

export JARS=$GS_JARS:./bin

java -cp $JARS com.gigaspaces.admin.GSUniversalDeployer -config puList.txt -locators 127.0.0.1  -abortDeployOnFailure true -command deploy

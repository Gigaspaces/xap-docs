cmd.exe /C "$JAVA_HOME\bin\java.exe -classpath C:\opt\gigaspaces\xap-10.1.0-ga\lib\required\*;deployment\lib\*;target\* com.gigaspaces.cli.CommandLineTool"

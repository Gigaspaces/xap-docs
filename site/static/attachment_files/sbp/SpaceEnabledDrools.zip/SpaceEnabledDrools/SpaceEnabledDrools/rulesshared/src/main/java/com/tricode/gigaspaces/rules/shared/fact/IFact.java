package com.tricode.gigaspaces.rules.shared.fact;

import java.io.Serializable;

/**
 * Fact interface.
 */
public interface IFact extends Serializable {

    /**
     * Enforcing custom implementation of Object.equals() because required by Drools.
     *
     * @param o Object to compare this object to.
     * @return True if logically same object.
     */
    boolean equals(Object o);

    /**
     * Enforcing custom implementation of Object.hashCode() because required by Drools.
     *
     * @return Hashcode value.
     */
    int hashCode();

}
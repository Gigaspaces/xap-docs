package com.gigaspaces.datasource;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.gigaspaces.domain.MultiClusterEnabled;
import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.UpdateModifiers;

public class MyExternalDataSource implements DataProvider, BulkDataPersister {

	Logger logger = Logger.getLogger(this.getClass().getName());

	private GigaSpace remoteGigaSpace = null;
	private String remoteUrl = null;
	
	//Modify this appropriately
	private long WRITE_TIMEOUT = 10000l;

	public void executeBulk(List<BulkItem> bulkItems)
			throws DataSourceException {

		for (BulkItem bulkItem : bulkItems) {
			logger.info(bulkItem.toString());

			Object item = bulkItem.getItem();
			if (item instanceof MultiClusterEnabled) {

				switch (bulkItem.getOperation()) {
				case BulkItem.REMOVE:
					logger.info("REMOVING " + item);
					remoteGigaSpace.take(item);
					logger.info("After take operation");
					break;
				case BulkItem.WRITE:
					logger.info("WRITING " + item);

					// Disable write back to this space
					if (((MultiClusterEnabled) item).isMultiClusterReplicate()) {
						((MultiClusterEnabled) item)
								.setMultiClusterReplicate(false);
						remoteGigaSpace.write(item);
						logger.info("After write operation");
					}
					break;
				case BulkItem.UPDATE:
					logger.info("UPDATING " + item);

					// Disable write back to this space
					if (((MultiClusterEnabled) item).isMultiClusterReplicate()) {
						((MultiClusterEnabled) item)
								.setMultiClusterReplicate(false);
						remoteGigaSpace.write(item, Lease.FOREVER, WRITE_TIMEOUT, UpdateModifiers.UPDATE_OR_WRITE);
						logger.info("After update operation");
					}
					break;
				}
			}

		}

	}

	public void initialize() {

		// connect to the remote space using its URL
		IJSpace space = new UrlSpaceConfigurer(remoteUrl).space();
		// use gigaspace wrapper to for simpler API
		this.remoteGigaSpace = new GigaSpaceConfigurer(space).gigaSpace();

	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public void init(Properties arg0) throws DataSourceException {
		// TODO Auto-generated method stub
		
	}

	public DataIterator initialLoad() throws DataSourceException {
		// TODO Auto-generated method stub
		return null;
	}

	public void shutdown() throws DataSourceException {
		// TODO Auto-generated method stub
		
	}

	public DataIterator iterator(Object arg0) throws DataSourceException {
		// TODO Auto-generated method stub
		return null;
	}

	public Object read(Object arg0) throws DataSourceException {
		// TODO Auto-generated method stub
		return null;
	}

}

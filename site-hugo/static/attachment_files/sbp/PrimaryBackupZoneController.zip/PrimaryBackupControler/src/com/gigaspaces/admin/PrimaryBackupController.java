package com.gigaspaces.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.gsc.GridServiceContainer;
import org.openspaces.admin.gsm.GridServiceManager;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitPartition;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class PrimaryBackupController implements InitializingBean , DisposableBean{

	public PrimaryBackupController() {
	}

	public static void main(String[] arge) throws Exception {
		
		String puName = System.getProperty("puName");
		String primaryZone = System.getProperty("primaryZone");
		String backupZone = System.getProperty("backupZone");
		String locators = System.getProperty("locators");
		String groups = System.getProperty("groups");
		int delayBetweenChecks = Integer.valueOf(System.getProperty("delayBetweenChecks","60")).intValue();
		
		logger.info("Primary Zone:" + primaryZone + " Backup Zone:" + backupZone);
		if (primaryZone.equals(backupZone))
		{
			logger.info("Identical Zone for Primary and Backup:" + primaryZone);
			return;
		}
		PrimaryBackupController pbc = new PrimaryBackupController();
		pbc.setLocators(locators);
		pbc.setGroups(groups);
		
		pbc.init();
		pbc.setPuName(puName);
		pbc.setBackupZone(backupZone);
		pbc.setPrimaryZone(primaryZone);
		pbc.setDelayBetweenChecks(delayBetweenChecks);
		
		Task task = pbc.new Task();
		pbc.scheduler = Executors.newScheduledThreadPool(1);
		pbc.handle = pbc.scheduler.scheduleWithFixedDelay(task, 10, pbc.delayBetweenChecks, TimeUnit.SECONDS);
	}

	String primaryZone;
	String backupZone;
	String locators;
	String groups;

	Admin admin = null;
	GridServiceManager gsm = null;
	ScheduledExecutorService scheduler;
	ScheduledFuture<?> handle ;
	String puName;
	int delayBetweenChecks = 60;
	
	private static Logger logger = Logger
			.getLogger(PrimaryBackupController.class.getSimpleName());

	public void afterPropertiesSet() throws Exception {
		init();
		Task task = new Task();
		scheduler = Executors.newScheduledThreadPool(1);
		
		handle = scheduler.scheduleWithFixedDelay(task, 10, delayBetweenChecks, TimeUnit.SECONDS);	        
//		threadExecutor.execute(task);
	}

	public void init() throws Exception {
		AdminFactory af = new AdminFactory();
		if ((locators != null) && (locators.length() > 0))
			af.addLocator(locators);

		if ((groups != null) && (groups.length() > 0))
			af.addLocator(groups);

		admin = af.createAdmin();

		if (admin == null) {
			logger.info("Can't find Admin - Abort deploy");
			return;
		}
		gsm = admin.getGridServiceManagers().waitForAtLeastOne(10,TimeUnit.SECONDS);
		if (gsm == null) {
			logger.info("Can't find GSM - Abort deploy");
			return;
		}
	}

	GridServiceContainer getFreeContainer(String zone) {
		List<GridServiceContainer> gscsList = new ArrayList<GridServiceContainer>();
		admin.getZones().getByName(zone).getGridServiceContainers()
				.waitFor(100, 5, TimeUnit.SECONDS);
		GridServiceContainer gscs[] = admin.getZones().getByName(zone)
				.getGridServiceContainers().getContainers();
		if (gscs == null)
			return null;

		if (gscs.length == 0)
			return null;

		for (int i = 0; i < gscs.length; i++) {
			gscsList.add(gscs[i]);
		}

		java.util.Collections.sort(gscsList, new GridServiceContainerSorter());

		return gscsList.get(0);
	}

	void relocateBackupInstances() {
		logger.info("Placing Backup Instances on Zone:" + backupZone);
		int relocatedCount = relocateBackupsPrimarys(false);
		logger.info(relocatedCount + " Backup Instances moved to Zone:" + backupZone);
	}

	void relocatePrimaryInstances() {
		logger.info("Placing Primary Instances on Zone:" + primaryZone);
		int relocatedCount = relocateBackupsPrimarys(true);
		logger.info(relocatedCount + " Primary Instances moved to Zone:" + primaryZone);
		// restart primary instances
		int restartedCount = restartPrimarys();
		logger.info(restartedCount + " Primary Instances restarted");
	}

	void printPUInstnacesInfo() {
		// get all PU instances
		ProcessingUnit pu = admin.getProcessingUnits().waitFor(puName, 10,
				TimeUnit.SECONDS);
		if (pu == null) {
			logger.info("Can't get PU " + puName);
			return;
		}
		ProcessingUnitPartition[] partitions = pu.getPartitions();

		logger.info(pu.getName() + " - Number Of Instances:"+ pu.getNumberOfInstances());

		while (partitions.length < pu.getNumberOfInstances()) {
			pu = admin.getProcessingUnits().waitFor(puName, 10,TimeUnit.SECONDS);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Arrays.sort(partitions, new PUSorter());
		
		for (int i = 0; i < partitions.length; i++) {
			while (partitions[i].getPrimary() == null) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			partitions[i].getPrimary().waitForSpaceInstance(10,
					TimeUnit.SECONDS);
			logger.info("Primary Partition "
					+ partitions[i].getPrimary().getInstanceId()
					+ " located on machine ["
					+ partitions[i].getPrimary().getMachine().getHostName()
					+ ":"
					+ partitions[i].getPrimary().getMachine().getHostAddress()
					+ "] zone:"
					+ partitions[i].getPrimary().getZones().keySet());
		}
		for (int i = 0; i < partitions.length; i++) {

			while (partitions[i].getBackup() == null) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			partitions[i].getBackup()
					.waitForSpaceInstance(10, TimeUnit.SECONDS);
			logger.info("Backup Partition "
					+ partitions[i].getBackup().getInstanceId()
					+ " located on machine ["
					+ partitions[i].getBackup().getMachine().getHostName()
					+ ":"
					+ partitions[i].getBackup().getMachine().getHostAddress()
					+ "] zone:" + partitions[i].getBackup().getZones().keySet());
		}
	}

	int relocateBackupsPrimarys(boolean isPrimary) {
		int relocationCount=0;
		// get all PU instances
		ProcessingUnit pu = admin.getProcessingUnits().waitFor(puName, 10,
				TimeUnit.SECONDS);
		if (pu == null) {
			logger.info("Can't get PU " + puName);
			return relocationCount;
		}
		ProcessingUnitPartition[] partitions = pu.getPartitions();
		
		Arrays.sort(partitions, new PUSorter());
		
		if (isPrimary) {
			for (int i = 0; i < partitions.length; i++) {
				GridServiceContainer gsc = getFreeContainer(primaryZone);
				if (gsc == null) {
					logger.info("No available GSC on zone " + primaryZone
							+ " to host primary instance");
					return relocationCount;
				}
				if (!partitions[i].getPrimary().getZones()
						.containsKey(primaryZone)) {
					logger.info("Primary ID "
							+ (partitions[i].getPartitionId() + 1)
							+ " Instance located on machine ["
							+ partitions[i].getPrimary().getMachine()
									.getHostName()
							+ ":"
							+ partitions[i].getPrimary().getMachine()
									.getHostAddress() + "] running on zone "
							+ partitions[i].getPrimary().getZones().keySet()
							+ " moving into zone " + primaryZone);
					partitions[i].getPrimary().relocateAndWait(gsc, 60,
							TimeUnit.SECONDS);
					relocationCount++;
				}
			}
		} else {
			for (int i = 0; i < partitions.length; i++) {
				GridServiceContainer gsc = getFreeContainer(backupZone);
				if (gsc == null) {
					logger.info("No available GSC on zone " + backupZone
							+ " to host backup instance");
					return relocationCount;
				}
				if (!partitions[i].getBackup().getZones()
						.containsKey(backupZone)) {
					logger.info("Backup ID "
							+ (partitions[i].getPartitionId() + 1)
							+ " Instance located on machine ["
							+ partitions[i].getBackup().getMachine()
									.getHostName()
							+ ":"
							+ partitions[i].getBackup().getMachine()
									.getHostAddress() + "] running on zone "
							+ partitions[i].getBackup().getZones().keySet()
							+ " moving into zone " + backupZone);
					partitions[i].getBackup().relocateAndWait(gsc, 60,
							TimeUnit.SECONDS);
					relocationCount++;
				}
			}
		}
		return relocationCount;
	}

	int restartPrimarys() {
		int restartCount =0 ;
		// get all PU instances
		ProcessingUnit pu = admin.getProcessingUnits().waitFor(puName, 10,TimeUnit.SECONDS);
		if (pu == null) {
			logger.info("Can't get PU " + puName);
			return restartCount ;
		}
		ProcessingUnitPartition[] partitions = pu.getPartitions();
		for (int i = 0; i < partitions.length; i++) {
			// restart only if it is wrong zone
			if (!partitions[i].getPrimary().getZones().containsKey(primaryZone)) {
				partitions[i].getPrimary().restartAndWait(60, TimeUnit.SECONDS);
				restartCount ++;
			}
		}
		return restartCount ;
	}

	class GridServiceContainerSorter implements
			Comparator<GridServiceContainer> {
		public int compare(GridServiceContainer o1, GridServiceContainer o2) {

			int o1Count = o1.getProcessingUnitInstances().length;
			int o2Count = o2.getProcessingUnitInstances().length;
			return o1Count - o2Count;
		}
	}

	
	class PUSorter implements Comparator<ProcessingUnitPartition> {
		public int compare(ProcessingUnitPartition o1, ProcessingUnitPartition o2) {
			int o1Count = o1.getPartitionId();
			int o2Count = o2.getPartitionId();
			return o1Count - o2Count;
		}
	}

	public String getPuName() {
		return puName;
	}

	public void setPuName(String puName) {
		this.puName = puName;
	}

	public String getPrimaryZone() {
		return primaryZone;
	}

	public void setPrimaryZone(String primaryZone) {
		this.primaryZone = primaryZone;
	}

	public String getBackupZone() {
		return backupZone;
	}

	public void setBackupZone(String backupZone) {
		this.backupZone = backupZone;
	}

	public String getLocators() {
		return locators;
	}

	public void setLocators(String locators) {
		this.locators = locators;
	}

	public String getGroups() {
		return groups;
	}

	public void setGroups(String groups) {
		this.groups = groups;
	}

	class Task implements Runnable {
		public void run() {
			logger.info("Primary Zone:" + primaryZone + " Backup Zone:" + backupZone);
			logger.info("Before relocation");
			printPUInstnacesInfo();
			// Periodically check the cluster status
			relocatePrimaryInstances();
			relocateBackupInstances();
			logger.info("After relocation");
			printPUInstnacesInfo();
			logger.info("Next check in " + delayBetweenChecks + " Seconds");
			logger.info("------------------------------------------------------------");
		}
	}

	@Override
	public void destroy() throws Exception {
		if (admin!=null)
			admin.close();
		
		if (scheduler!=null)
		{
			handle.cancel(true);
			scheduler.shutdown();
		}
	}

	public int getDelayBetweenChecks() {
		return delayBetweenChecks;
	}

	public void setDelayBetweenChecks(int delayBetweenChecks) {
		this.delayBetweenChecks = delayBetweenChecks;
	}
}

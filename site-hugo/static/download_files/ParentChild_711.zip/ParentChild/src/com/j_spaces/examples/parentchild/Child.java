package com.j_spaces.examples.parentchild;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceIndex;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.metadata.index.SpaceIndexType;
;

@SpaceClass
public class Child {
	
	private String parentID;
	private Long data;
	private String id;

	public Child(){}
	
	public Child(String id, String _parentID) 
	{
		this.parentID = _parentID;
		this.id = id;
	}

	public String toString()
	{
		return "ID:" + id + " data:" + data;
	}

	@SpaceIndex(type=SpaceIndexType.BASIC)
	public Long getData() {
		return data;
	}

	public void setData(Long data) {
		this.data= data;
	}
	
	@SpaceId (autoGenerate = false)
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	@SpaceIndex(type=SpaceIndexType.BASIC)
	@SpaceRouting
	public String getParentID() {
		return parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}
}

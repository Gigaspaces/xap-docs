package com.gigaspaces.cli.jcommander;

import com.beust.jcommander.JCommander;
import com.gigaspaces.cli.jcommander.parameters.*;

import java.util.ArrayList;
import java.util.Objects;

public class OptionsParser {

    public void parse(String[] args, Options options){
        if(options == null){
            throw new IllegalArgumentException("Argument [options] cannot be null.");
        }

        JCommander jCommander = new JCommander(options);
        jCommander.parse(args);

        if(options.isHelp()){
            jCommander.usage();
        } else if (options instanceof ValidateableOptions){
            ((ValidateableOptions)options).validate();
        }
    }

    public String[] createArguments(String input) {
        ArrayList<String> output = new ArrayList<>();

        String currentArgument = "";
        boolean isInPhrase = false;
        boolean isDoubleQuotes = false;

        for(int x = 0; x < input.length(); x++){
            char currentCharacter = input.charAt(x);
            boolean isQuoteCharacter = currentCharacter == '\'' || currentCharacter == '"';
            if(isQuoteCharacter){
                boolean isEscaped = (x != 0 && input.charAt(x - 1) =='\\');

                if(!isInPhrase){
                    isInPhrase = true;
                    isDoubleQuotes = '"' == currentCharacter;
                } else if(isEscaped || (!isDoubleQuotes && currentCharacter == '"') || (isDoubleQuotes && currentCharacter == '\'')){
                    if(isEscaped)
                        currentArgument = currentArgument.substring(0, currentArgument.length()-1);
                    currentArgument += input.charAt(x);
                } else {
                    if(!Objects.equals(currentArgument, ""))
                        output.add(currentArgument);
                    currentArgument = "";
                    isInPhrase = false;
                    isDoubleQuotes = false;
                }
            }

            else if(currentCharacter != ' ' || (isInPhrase)) {
                currentArgument += currentCharacter;
            }

            if(!isQuoteCharacter && ((currentCharacter == ' ' && !isInPhrase) || x == (input.length() - 1))){
                if(!Objects.equals(currentArgument, ""))
                    output.add(currentArgument);
                currentArgument = "";
            }
        }

        return output.toArray(new String[output.size()]);
    }
}

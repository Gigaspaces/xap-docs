Steps to run the example,
> Extract the archive to a folder with no spaces.
> Modify the GigaSpaces and Java installation path's in the jetty-ssl\setDevEnv.bat folder and build.properties
> Modify the ssl.keystore and ssl.truststore path's in jetty-ssl\webapp-ssl\WebContent\META-INF\spring folder appropriately
> Build updated war file using "build.bat dist" command
> Start a gs-agent using the included script
> Run deploy.bat command to deploy the WAR.
> After deployment is completed, access the app using, https://localhost:8443/webapp-ssl/ URL (Use appropriate host name if deploying into non local machine)

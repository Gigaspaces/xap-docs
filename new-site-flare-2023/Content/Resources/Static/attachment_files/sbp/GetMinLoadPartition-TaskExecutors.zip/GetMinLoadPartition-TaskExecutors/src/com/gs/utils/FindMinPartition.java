package com.gs.utils;

import java.sql.Time;
import java.util.concurrent.ExecutionException;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.gigaspaces.async.AsyncFuture;
import com.j_spaces.core.IJSpace;

public class FindMinPartition {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

		IJSpace ijs = new UrlSpaceConfigurer("jini://*/*/space").space();
		GigaSpace gigaSpace = new GigaSpaceConfigurer(ijs).gigaSpace();
		
		AsyncFuture<Integer> future = gigaSpace.execute(new MyDistributedTask());
		try {
			Integer result = future.get();
			
			System.out.println(" Partition :" + result.intValue());
	
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

	}

}

#!/bin/sh

mvn os:hsql-ui -Ddriver=org.hsqldb.jdbcDriver -Durl=jdbc:hsqldb:hsql://EPUAKHAW0281/testDB -Duser=sa -Dpassword=


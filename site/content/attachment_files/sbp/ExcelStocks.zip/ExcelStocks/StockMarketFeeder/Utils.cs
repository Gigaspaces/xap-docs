using System;

namespace GigaSpaces.Examples.ExcelStocks.Feeder
{
    /// <summary>
    /// Log and Messages
    /// </summary>
	public static class Utils
    {
        public static void LogMessage(string message)
        {
            Console.WriteLine(message);
        }

        public static void LogException(string message, Exception ex)
        {
			Console.Error.WriteLine("{0}: {1}\nStacktrace: {2}", message, ex.Message, ex.StackTrace);
        }
    }
}
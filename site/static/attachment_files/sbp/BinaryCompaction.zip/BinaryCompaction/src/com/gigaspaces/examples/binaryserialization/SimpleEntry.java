package com.gigaspaces.examples.binaryserialization;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceIndex;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.gigaspaces.metadata.index.SpaceIndexType;

@SpaceClass
public class SimpleEntry {

    private Long  queryField;

    private Long		_longFieldA1;
    private Long		_longFieldB1;
    private Long		_longFieldC1;
    private Long		_longFieldD1;

    private Integer	_intFieldA1;
    private Integer	_intFieldB1;
    private Integer	_intFieldC1;
    private Integer	_intFieldD1;

    private String	_stringFieldA1;
    private String	_stringFieldB1;
    private String	_stringFieldC1;
    private String	_stringFieldD1;
////

    private Long		_longFieldA2;
    private Long		_longFieldB2;
    private Long		_longFieldC2;
    private Long		_longFieldD2;

    private Integer	_intFieldA2;
    private Integer	_intFieldB2;
    private Integer	_intFieldC2;
    private Integer	_intFieldD2;

    private String	_stringFieldA2;
    private String	_stringFieldB2;
    private String	_stringFieldC2;
    private String	_stringFieldD2;

////
    private Long		_longFieldA3;
    private Long		_longFieldB3;
    private Long		_longFieldC3;
    private Long		_longFieldD3;

    private Integer	_intFieldA3;
    private Integer	_intFieldB3;
    private Integer	_intFieldC3;
    private Integer	_intFieldD3;

    private String	_stringFieldA3;
    private String	_stringFieldB3;
    private String	_stringFieldC3;
    private String	_stringFieldD3;

	public SimpleEntry()
	{}

    public SimpleEntry(long _queryField, 
			long longFieldA1, long longFieldB1, long longFieldC1, long longFieldD1,
                       int intFieldA1, int intFieldB1, int intFieldC1, int intFieldD1,
                       String stringFieldA1, String stringFieldB1, String stringFieldC1, String stringFieldD1,
			long longFieldA2, long longFieldB2, long longFieldC2, long longFieldD2,
                       int intFieldA2, int intFieldB2, int intFieldC2, int intFieldD2,
                       String stringFieldA2, String stringFieldB2, String stringFieldC2, String stringFieldD2,
			long longFieldA3, long longFieldB3, long longFieldC3, long longFieldD3,
                       int intFieldA3, int intFieldB3, int intFieldC3, int intFieldD3,
                       String stringFieldA3, String stringFieldB3, String stringFieldC3, String stringFieldD3
)
	{
        queryField   = _queryField;

        _longFieldA1   = longFieldA1;
        _longFieldB1   = longFieldB1;
        _longFieldC1   = longFieldC1;
        _longFieldD1   = longFieldD1;
        _intFieldA1    =  intFieldA1;
        _intFieldB1    =  intFieldB1;
        _intFieldC1    =  intFieldC1;
        _intFieldD1    =  intFieldD1;
        _stringFieldA1 = stringFieldA1;
        _stringFieldB1 = stringFieldB1;
        _stringFieldC1 = stringFieldC1;
        _stringFieldD1 = stringFieldD1;
////
        _longFieldA2   = longFieldA2;
        _longFieldB2   = longFieldB2;
        _longFieldC2   = longFieldC2;
        _longFieldD2   = longFieldD2;
        _intFieldA2   =  intFieldA2;
        _intFieldB2    =  intFieldB2;
        _intFieldC2    =  intFieldC2;
        _intFieldD2    =  intFieldD2;
        _stringFieldA2 = stringFieldA2;
        _stringFieldB2 = stringFieldB2;
        _stringFieldC2 = stringFieldC2;
        _stringFieldD2 = stringFieldD2;


///
        _longFieldA3   = longFieldA3;
        _longFieldB3   = longFieldB3;
        _longFieldC3   = longFieldC3;
        _longFieldD3   = longFieldD3;
        _intFieldA3    =  intFieldA3;
        _intFieldB3    =  intFieldB3;
        _intFieldC3    =  intFieldC3;
        _intFieldD3    =  intFieldD3;
        _stringFieldA3 = stringFieldA3;
        _stringFieldB3 = stringFieldB3;
        _stringFieldC3 = stringFieldC3;
        _stringFieldD3 = stringFieldD3;



    }


	public Integer get_intFieldA1() {
		return _intFieldA1;
	}

	public void set_intFieldA1(Integer fieldA1) {
		_intFieldA1 = fieldA1;
	}

	public Integer get_intFieldA2() {
		return _intFieldA2;
	}

	public void set_intFieldA2(Integer fieldA2) {
		_intFieldA2 = fieldA2;
	}

	public Integer get_intFieldA3() {
		return _intFieldA3;
	}

	public void set_intFieldA3(Integer fieldA3) {
		_intFieldA3 = fieldA3;
	}

	public Integer get_intFieldB1() {
		return _intFieldB1;
	}

	public void set_intFieldB1(Integer fieldB1) {
		_intFieldB1 = fieldB1;
	}

	public Integer get_intFieldB2() {
		return _intFieldB2;
	}

	public void set_intFieldB2(Integer fieldB2) {
		_intFieldB2 = fieldB2;
	}

	public Integer get_intFieldB3() {
		return _intFieldB3;
	}

	public void set_intFieldB3(Integer fieldB3) {
		_intFieldB3 = fieldB3;
	}

	public Integer get_intFieldC1() {
		return _intFieldC1;
	}

	public void set_intFieldC1(Integer fieldC1) {
		_intFieldC1 = fieldC1;
	}

	public Integer get_intFieldC2() {
		return _intFieldC2;
	}

	public void set_intFieldC2(Integer fieldC2) {
		_intFieldC2 = fieldC2;
	}

	public Integer get_intFieldC3() {
		return _intFieldC3;
	}

	public void set_intFieldC3(Integer fieldC3) {
		_intFieldC3 = fieldC3;
	}

	public Integer get_intFieldD1() {
		return _intFieldD1;
	}

	public void set_intFieldD1(Integer fieldD1) {
		_intFieldD1 = fieldD1;
	}

	public Integer get_intFieldD2() {
		return _intFieldD2;
	}

	public void set_intFieldD2(Integer fieldD2) {
		_intFieldD2 = fieldD2;
	}

	public Integer get_intFieldD3() {
		return _intFieldD3;
	}

	public void set_intFieldD3(Integer fieldD3) {
		_intFieldD3 = fieldD3;
	}

	public Long get_longFieldA1() {
		return _longFieldA1;
	}

	public void set_longFieldA1(Long fieldA1) {
		_longFieldA1 = fieldA1;
	}

	public Long get_longFieldA2() {
		return _longFieldA2;
	}

	public void set_longFieldA2(Long fieldA2) {
		_longFieldA2 = fieldA2;
	}

	public Long get_longFieldA3() {
		return _longFieldA3;
	}

	public void set_longFieldA3(Long fieldA3) {
		_longFieldA3 = fieldA3;
	}

	public Long get_longFieldB1() {
		return _longFieldB1;
	}

	public void set_longFieldB1(Long fieldB1) {
		_longFieldB1 = fieldB1;
	}

	public Long get_longFieldB2() {
		return _longFieldB2;
	}

	public void set_longFieldB2(Long fieldB2) {
		_longFieldB2 = fieldB2;
	}

	public Long get_longFieldB3() {
		return _longFieldB3;
	}

	public void set_longFieldB3(Long fieldB3) {
		_longFieldB3 = fieldB3;
	}

	public Long get_longFieldC1() {
		return _longFieldC1;
	}

	public void set_longFieldC1(Long fieldC1) {
		_longFieldC1 = fieldC1;
	}

	public Long get_longFieldC2() {
		return _longFieldC2;
	}

	public void set_longFieldC2(Long fieldC2) {
		_longFieldC2 = fieldC2;
	}

	public Long get_longFieldC3() {
		return _longFieldC3;
	}

	public void set_longFieldC3(Long fieldC3) {
		_longFieldC3 = fieldC3;
	}

	public Long get_longFieldD1() {
		return _longFieldD1;
	}

	public void set_longFieldD1(Long fieldD1) {
		_longFieldD1 = fieldD1;
	}

	public Long get_longFieldD2() {
		return _longFieldD2;
	}

	public void set_longFieldD2(Long fieldD2) {
		_longFieldD2 = fieldD2;
	}

	public Long get_longFieldD3() {
		return _longFieldD3;
	}

	public void set_longFieldD3(Long fieldD3) {
		_longFieldD3 = fieldD3;
	}

	@SpaceRouting
	@SpaceIndex(type=SpaceIndexType.BASIC)
	public Long getQueryField() {
		return queryField;
	}

	public void setQueryField(Long _queryField) {
		queryField = _queryField;
	}

	public String get_stringFieldA1() {
		return _stringFieldA1;
	}

	public void set_stringFieldA1(String fieldA1) {
		_stringFieldA1 = fieldA1;
	}

	public String get_stringFieldA2() {
		return _stringFieldA2;
	}

	public void set_stringFieldA2(String fieldA2) {
		_stringFieldA2 = fieldA2;
	}

	public String get_stringFieldA3() {
		return _stringFieldA3;
	}

	public void set_stringFieldA3(String fieldA3) {
		_stringFieldA3 = fieldA3;
	}

	public String get_stringFieldB1() {
		return _stringFieldB1;
	}

	public void set_stringFieldB1(String fieldB1) {
		_stringFieldB1 = fieldB1;
	}

	public String get_stringFieldB2() {
		return _stringFieldB2;
	}

	public void set_stringFieldB2(String fieldB2) {
		_stringFieldB2 = fieldB2;
	}

	public String get_stringFieldB3() {
		return _stringFieldB3;
	}

	public void set_stringFieldB3(String fieldB3) {
		_stringFieldB3 = fieldB3;
	}

	public String get_stringFieldC1() {
		return _stringFieldC1;
	}

	public void set_stringFieldC1(String fieldC1) {
		_stringFieldC1 = fieldC1;
	}

	public String get_stringFieldC2() {
		return _stringFieldC2;
	}

	public void set_stringFieldC2(String fieldC2) {
		_stringFieldC2 = fieldC2;
	}

	public String get_stringFieldC3() {
		return _stringFieldC3;
	}

	public void set_stringFieldC3(String fieldC3) {
		_stringFieldC3 = fieldC3;
	}

	public String get_stringFieldD1() {
		return _stringFieldD1;
	}

	public void set_stringFieldD1(String fieldD1) {
		_stringFieldD1 = fieldD1;
	}

	public String get_stringFieldD2() {
		return _stringFieldD2;
	}

	public void set_stringFieldD2(String fieldD2) {
		_stringFieldD2 = fieldD2;
	}

	public String get_stringFieldD3() {
		return _stringFieldD3;
	}

	public void set_stringFieldD3(String fieldD3) {
		_stringFieldD3 = fieldD3;
	}
}

namespace GigaSpaces.Examples.ExcelStocks.Quote.Framework
{
    /// <summary>
    /// Holds Rtd information per topic
    /// </summary>
    internal class RtdTopicInfo
    {
        private int _topicId;
        private string _fieldName;
        private bool _refreshOnChange;

        public int TopicId
        {
            get { return _topicId; }
            set { _topicId = value; }
        }
        public string FieldName
        {
            get { return _fieldName; }
            set { _fieldName = value; }
        }
        public bool RefreshOnChange
        {
            get { return _refreshOnChange; }
            set { _refreshOnChange = value; }
        }

        /// <summary>
        /// RtdTopicInfo constractor
        /// </summary>
        /// <param name="topicId">topicId is unique for the excel sell in a RTD function call</param>
        /// <param name="fieldName">Pono's fieldName that is displayed in the topicId's sell</param>
        /// <param name="refreshOnChange">indicates to refreash the topicId's sell on field value change in the remote space</param>
        public RtdTopicInfo(int topicId, string fieldName, bool refreshOnChange)
        {
            this._topicId = topicId;
            this._fieldName = fieldName;
            this._refreshOnChange = refreshOnChange;
        }
    }
}

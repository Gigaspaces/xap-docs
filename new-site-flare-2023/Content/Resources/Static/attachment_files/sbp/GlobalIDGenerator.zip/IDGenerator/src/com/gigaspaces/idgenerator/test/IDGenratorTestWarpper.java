package com.gigaspaces.idgenerator.test;

import org.springframework.beans.factory.InitializingBean;

public class IDGenratorTestWarpper implements InitializingBean{

	IDGenratorTest idGenratorTest;

	@Override
	public void afterPropertiesSet() throws Exception {
		idGenratorTest.go();
	}

	public IDGenratorTest getIdGenratorTest() {
		return idGenratorTest;
	}

	public void setIdGenratorTest(IDGenratorTest idGenratorTest) {
		this.idGenratorTest = idGenratorTest;
	}
}

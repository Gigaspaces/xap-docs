param ([String]$configuration)

if($configuration){
	cat $configuration | cmd /C "C:\opt\java\jdk1.7.0_75\bin\java.exe -classpath C:\opt\gigaspaces\xap-10.1.0-ga\lib\required\*;.\lib\* com.gigaspaces.cli.CommandLineTool"
}
else {
	cmd /C "C:\opt\java\jdk1.7.0_75\bin\java.exe -classpath C:\opt\gigaspaces\xap-10.1.0-ga\lib\required\*;.\lib\* com.gigaspaces.cli.CommandLineTool"
} 

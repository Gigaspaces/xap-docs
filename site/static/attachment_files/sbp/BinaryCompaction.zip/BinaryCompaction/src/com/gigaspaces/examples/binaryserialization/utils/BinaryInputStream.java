package com.gigaspaces.examples.binaryserialization.utils;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;

/**
 * This class provides helper methods for low footprint binary deserialization.
 * 
 * It should only be used by experienced developers in scenarios which require low footprint optimizations.
 * 
 * NOTE: This class is NOT part of GigaSpaces XAP API. It is a porting of a class which was originally created for internal 
 * usage in modules which require high performance. Since performance was the major design guideline, some safety checks 
 * (e.g. validations) were intentionally not included, which means common user errors might result in unexpected behavior 
 * at runtime.
 * 
 * @author GigaSpaces
 */
public class BinaryInputStream extends InputStream
{
    /**
     * An array of bytes that was provided by the creator of the stream.
     * Elements <code>buf[0]</code> through <code>buffer[count-1]</code>
     * are the only bytes that can ever be read from the stream;
     * element <code>buffer[pos]</code> is the next byte to be read.
     */
    private byte _buffer[];

    /**
     * The index of the next character to read from the input stream buffer.
     * This value should always be nonnegative and not larger than the  
     * value of <code>count</code>. The next byte to be read from the  
     * input stream buffer will be <code>buffer[position]</code>.
     */
    private int _position;

    /**
     * The index one greater than the last valid character in the input 
     * stream buffer. 
     * This value should always be nonnegative
     * and not larger than the length of <code>buffer</code>.
     * It  is one greater than the position of
     * the last byte within <code>buffer</code> that
     * can ever be read  from the input stream buffer.
     */
    private int _count;

    /**
     * Creates a <code>ByteArrayInputStream</code>
     * so that it  uses <code>buffer</code> as its
     * buffer array. 
     * The buffer array is not copied. 
     * The initial value of <code>pos</code>
     * is <code>0</code> and the initial value
     * of  <code>count</code> is the length of
     * <code>buffer</code>.
     *
     * @param   buffer   the input buffer.
     */
    public BinaryInputStream(byte buffer[])
    {
    	setBuffer(buffer);
    }

    /**
     * Sets a <code>GSByteArrayInputStream</code>
     * so that it  uses <code>buffer</code> as its
     * buffer array. 
     * The buffer array is not copied. 
     * The initial value of <code>pos</code>
     * is <code>0</code> and the initial value
     * of  <code>count</code> is the length of
     * <code>buffer</code>.
     *
     * @param   buffer   the input buffer.
     */
    public void setBuffer( byte[] buffer)
    {
    	this._buffer = buffer;
        this._position = 0;
        this._count = buffer.length;
    }

    /**
     * Reads the next byte of data from this input stream. The value 
     * byte is returned as an <code>int</code> in the range 
     * <code>0</code> to <code>255</code>. If no byte is available 
     * because the end of the stream has been reached, the value 
     * <code>-1</code> is returned. 
     * <p>
     * This <code>read</code> method 
     * cannot block. 
     *
     * @return  the next byte of data, or <code>-1</code> if the end of the
     *          stream has been reached.
     */
	@Override
    public int read()
	{
		return (_position < _count) ? readUnsignedByte() : -1;
    }

    /**
     * Reads up to <code>len</code> bytes of data into an array of bytes 
     * from this input stream. 
     * If <code>pos</code> equals <code>count</code>,
     * then <code>-1</code> is returned to indicate
     * end of file. Otherwise, the  number <code>k</code>
     * of bytes read is equal to the smaller of
     * <code>len</code> and <code>count-pos</code>.
     * If <code>k</code> is positive, then bytes
     * <code>buffer[pos]</code> through <code>buffer[pos+k-1]</code>
     * are copied into <code>b[off]</code>  through
     * <code>b[off+k-1]</code> in the manner performed
     * by <code>System.arraycopy</code>. The
     * value <code>k</code> is added into <code>pos</code>
     * and <code>k</code> is returned.
     * <p>
     * This <code>read</code> method cannot block. 
     *
     * @param   b     the buffer into which the data is read.
     * @param   off   the start offset of the data.
     * @param   len   the maximum number of bytes read.
     * @return  the total number of bytes read into the buffer, or
     *          <code>-1</code> if there is no more data because the end of
     *          the stream has been reached.
     */
	@Override
    public int read(byte b[], int off, int len)
    {
		if (_position >= _count)
			return -1;
		if (_position + len > _count)
			len = _count - _position;
		if (len <= 0)
			return 0;
		
		System.arraycopy(_buffer, _position, b, off, len);
		_position += len;
		return len;
    }

    /**
     * Skips <code>n</code> bytes of input from this input stream. Fewer 
     * bytes might be skipped if the end of the input stream is reached. 
     * The actual number <code>k</code>
     * of bytes to be skipped is equal to the smaller
     * of <code>n</code> and  <code>count-pos</code>.
     * The value <code>k</code> is added into <code>pos</code>
     * and <code>k</code> is returned.
     *
     * @param   n   the number of bytes to be skipped.
     * @return  the actual number of bytes skipped.
     */
    public long skip(long n)
    {
		if (_position + n > _count) 
		    n = _count - _position;
		
		if (n < 0) 
		    return 0;
		
		_position += n;
		return n;
    }

    /**
     * Returns the number of bytes that can be read from this input 
     * stream without blocking. 
     * The value returned is
     * <code>count&nbsp;- pos</code>, 
     * which is the number of bytes remaining to be read from the input buffer.
     *
     * @return  the number of bytes that can be read from the input stream
     *          without blocking.
     */
    public int available()
    {
    	return _count - _position;
    }
    
    public byte readByte()
	{
		return _buffer[_position++];
    }
    public byte[] readByteArray()
	{
		int length = readInt();
		if (length == -1)
			return null;

		byte[] result = new byte[length];
		read(result, 0, result.length);
		return result;
	}
    
    public Byte readByteWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Byte(readByte());
    }
    public Byte[] readByteWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.VALUE_NULL)
			return null;
		
		Byte[] array = new Byte[length];
		for (int i = 0; i < length; i++)
			array[i] = readByteWrapper();
		return array;
    }
    
    public int readUnsignedByte()
	{
		return _buffer[_position++] & 0xff;
    }

	public short readShort()
	{
	    return (short)readInt();
	}
	public short[] readShortArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		short[] array = new short[length];
		for (int i = 0; i < length; i++)
			array[i] = readShort();
		return array;
	}
    public Short readShortWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Short(readShort());
    }
    public Short[] readShortWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.VALUE_NULL)
			return null;
		
		Short[] array = new Short[length];
		for (int i = 0; i < length; i++)
			array[i] = readShortWrapper();
		return array;
    }

	public int readInt()
	{
	    int b = readUnsignedByte();
	    int value = b & 0x3f;
	    int cBits = 6;
	    boolean fNeg = (b & 0x40) != 0;
	    while ((b & 0x80) != 0)
	    {
	    	b = readUnsignedByte();
	        value |= (b & 0x7f) << cBits;
	        cBits += 7;
	    }
	    if (fNeg)
	        value = ~value;
	    return value;
	}
	public int[] readIntArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		int[] array = new int[length];
		for (int i = 0; i < length; i++)
			array[i] = readInt();
		return array;
	}
    public Integer readIntWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Integer(readInt());
    }
    public Integer[] readIntWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.VALUE_NULL)
			return null;
		
		Integer[] array = new Integer[length];
		for (int i = 0; i < length; i++)
			array[i] = readIntWrapper();
		return array;
    }

	public int readIntFixed()
	{
		int b1 = readUnsignedByte();
	    int b2 = readUnsignedByte();
	    int b3 = readUnsignedByte();
	    int b4 = readUnsignedByte();
	    return ((b1 << 24) + (b2 << 16) + (b3 << 8) + (b4 << 0));	
	}

	public long readLong()
	{
	    int b = readUnsignedByte();
	    long l = b & 0x3f;
	    int cBits = 6;
	    boolean fNeg = (b & 0x40) != 0;
	    while ((b & 0x80) != 0)
	    {
	    	b = readUnsignedByte();
	        l |= (long) (b & 0x7f) << cBits;
	        cBits += 7;
	    }
	    if (fNeg)
	        l = ~l;
	    return l;
	}
	public long[] readLongArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		long[] array = new long[length];
		for (int i = 0; i < length; i++)
			array[i] = readLong();
		return array;
	}
    public Long readLongWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Long(readLong());
    }
    public Long[] readLongWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.VALUE_NULL)
			return null;
		
		Long[] array = new Long[length];
		for (int i = 0; i < length; i++)
			array[i] = readLongWrapper();
		return array;
    }

	public long readLongFixed()
	{
		long value = (long)readUnsignedByte() << 56;
		value += (long)readUnsignedByte() << 48 ;
		value += (long)readUnsignedByte() << 40 ;
		value += (long)readUnsignedByte() << 32 ;
		value += (long)readUnsignedByte() << 24 ;
		value += (long)readUnsignedByte() << 16 ;
		value += (long)readUnsignedByte() << 8 ;
		value += (long)readUnsignedByte() << 0 ;
		return value;
	}

	public float readFloat()
	{
	    int rawValue = readInt();
	    return Float.intBitsToFloat(rawValue);
	}
	public float[] readFloatArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		float[] array = new float[length];
		for (int i = 0; i < length; i++)
			array[i] = readFloat();
		return array;
	}
    public Float readFloatWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Float(readFloat());
    }
    public Float[] readFloatWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		Float[] array = new Float[length];
		for (int i = 0; i < length; i++)
			array[i] = readFloatWrapper();
		return array;
    }

	public double readDouble()
	{
	    long rawValue = readLong();
	    return Double.longBitsToDouble(rawValue);
	}
	public double[] readDoubleArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		double[] array = new double[length];
		for (int i = 0; i < length; i++)
			array[i] = readDouble();
		return array;
	}
    public Double readDoubleWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Double(readDouble());
    }
    public Double[] readDoubleWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		Double[] array = new Double[length];
		for (int i = 0; i < length; i++)
			array[i] = readDoubleWrapper();
		return array;
    }

	public boolean readBoolean()
	{
	    return _buffer[_position++] == BinaryStreamConstants.BOOLEAN_TRUE;
	}
	public boolean[] readBooleanArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		boolean[] array = new boolean[length];
		for (int i = 0; i < length; i++)
			array[i] = readBoolean();
		return array;
	}
    public Boolean readBooleanWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.BOOLEAN_NULL)
			return null;

		return new Boolean(readBoolean());
    }
    public Boolean[] readBooleanWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		Boolean[] array = new Boolean[length];
		for (int i = 0; i < length; i++)
			array[i] = readBooleanWrapper();
		return array;
    }

	public char readChar()
	{
	    return (char)readInt();
	}
	public char[] readCharArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		char[] array = new char[length];
		for (int i = 0; i < length; i++)
			array[i] = readChar();
		return array;
	}
    public Character readCharWrapper()
    {
		byte nullCode = readByte();
		if (nullCode == BinaryStreamConstants.VALUE_NULL)
			return null;

		return new Character(readChar());
    }
    public Character[] readCharWrapperArray()
    {
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		Character[] array = new Character[length];
		for (int i = 0; i < length; i++)
			array[i] = readCharWrapper();
		return array;
    }

	public String readString()
	{
		// Read string type
		byte stringType = readByte();
		switch (stringType) 
		{
			case BinaryStreamConstants.STRING_NULL:
				return null;
			case BinaryStreamConstants.STRING_EMPTY:
				return "";
			case BinaryStreamConstants.STRING_ASCII:
			{
				// Read length:
			    int length = readInt();
		    	// Create characters buffer:
		   		char[] chars = new char[length];
		   		// Read characters:
		   		for (int i = 0 ; i < length ; chars[i++] = (char)readUnsignedByte());		   			
		   		
		   		return new String(chars);
			}
			case BinaryStreamConstants.STRING_UNICODE:
			{
				// Read length:
			    int length = readInt();
		    	// Create characters buffer:
		   		char[] chars = new char[length];
		   		// Read characters:
		   		for (int i = 0; i < length; i++)
		   		{		   			
		   			int secondByte = _buffer[_position + length] & 0xff;		   			
		   			int firstByte = readUnsignedByte(); 
		   			chars[i] = (char)((secondByte << 8) | firstByte);		   				   			
		   		}
		   		_position += length;
		   		return new String(chars);				
			}
			default:
				throw new UnsupportedOperationException("Unsupported string type: " + stringType);
		}
		
	}
	public String[] readStringArray()
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		String[] array = new String[length];
		for (int i = 0; i < length; i++)
			array[i] = readString();
		return array;
	}

	public Date readDateTime(boolean isNullable)
	{
		if (isNullable)
		{
			byte nullCode = readByte();
			if (nullCode == BinaryStreamConstants.VALUE_NULL)
				return null;
		}

	    long rawValue = readLong();
	    return new Date(rawValue);
	}
	public Date[] readDateTimeArray(boolean isNullable)
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		Date[] array = new Date[length];
		for (int i = 0; i < length; i++)
			array[i] = readDateTime(isNullable);
		return array;
	}

	public BigDecimal readBigDecimal(boolean isNullable)
	{
		if (isNullable)
		{
			byte nullCode = readByte();
			if (nullCode == BinaryStreamConstants.VALUE_NULL)
				return null;
		}

		String rawValue = readString();
	    return new BigDecimal(rawValue);
	}
	public BigDecimal[] readBigDecimalArray(boolean isNullable)
	{
		int length = readInt();
		if (length == BinaryStreamConstants.ARRAY_NULL)
			return null;
		
		BigDecimal[] array = new BigDecimal[length];
		for (int i = 0; i < length; i++)
			array[i] = readBigDecimal(isNullable);
		return array;
	}
}

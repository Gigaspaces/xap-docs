package com.gigaspaces.springbatch;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.context.GigaSpaceContext;
import org.springframework.batch.item.ItemProcessor;

public class SpaceItemProcessor<I,O>  implements ItemProcessor<I,O>{

	@GigaSpaceContext
	GigaSpace space;

	@Override
	public O process(I request) throws Exception {
		System.out.println("SpaceItemProcessor called with Request ID:" + request);
		Thread.sleep(1000);
		ItemRequest itemRequest = (ItemRequest)request;
		ItemResult result = new ItemResult();
		result.setId(itemRequest.getId());		
		result.setJobID(itemRequest.getJobID());
		result.setRouting(itemRequest.getRouting());
		space.write(result); 
		return (O)result;
	}
}
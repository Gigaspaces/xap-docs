package com.gigaspaces.client;

import java.util.Random;
import java.util.logging.Logger;

import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.core.transaction.manager.LocalJiniTxManagerConfigurer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.gigaspaces.domain.Product;
import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.UpdateModifiers;

public class WriteProducts {

	Logger logger = Logger.getLogger(this.getClass().getName());
	GigaSpace gigaSpace = null;
	PlatformTransactionManager ptm = null;
	int batchSize = 10;

	static Random r = new Random();

	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("Usage: java TestClient <space URL>");
			System.exit(1);
		}

		new WriteProducts(args[0]);
	}

	/**
	 * Here we have the only constructor for this example TestClient
	 * 
	 * @param url
	 *            : the url to the space
	 */
	public WriteProducts(String url) {
		// connect to the space using its URL

		// connect to the space using its URL
		IJSpace space = new UrlSpaceConfigurer(url).space();
		// use gigaspace wrapper to for simpler API
		this.gigaSpace = new GigaSpaceConfigurer(space).gigaSpace();

		try {
			ptm = new LocalJiniTxManagerConfigurer(space).transactionManager();
		} catch (Exception e1) {
			e1.printStackTrace();
			System.exit(-1);
		}

		this.gigaSpace = new GigaSpaceConfigurer(space).transactionManager(ptm)
				.gigaSpace();

		try {
			feed(); // run the feeder (start feeding)
		} catch (NumberFormatException e) {
			logger.info("Invalid argument passed, count not a number");
		}

	}

	public void feed() {

		logger.info("Feeder Starting write of Products");

		Product[] batchProduct = new Product[batchSize];
		int counter = 0;
		Random r = new Random();

		while (counter < batchSize) {

			Product p = new Product();

			p.setId(counter + "");
			p.setName("name " + counter);
			p.setDescription("description " + counter);

			// Setting quantity as something random between 1 and 100
			p.setQuantity(r.nextInt(100));

			batchProduct[counter] = p;
			logger.info(System.currentTimeMillis() + " Writing Product "
					+ batchProduct[counter]);
			counter++;

			if (counter % batchSize == 0) {

				DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
				// configure the definition...
				TransactionStatus status = ptm.getTransaction(definition);

				try {
					gigaSpace.writeMultiple(batchProduct, Lease.FOREVER,
							UpdateModifiers.UPDATE_OR_WRITE);

				} catch (Exception e) {
					ptm.rollback(status);
					e.printStackTrace();
				}

				ptm.commit(status);

				break;
			}
		}
	}
}

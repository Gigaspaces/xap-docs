package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;

public class ConnectOptions extends ValidateableOptions {

    @Parameter(names = {"-u", "--username"}, description = "Username to authenticate against a secured grid.")
    private String username;

    @Parameter(names = {"-p", "--password"}, description = "Password to authenticate against a secured grid.")
    private String password;

    @Parameter(names = { "-l", "--lookup-locators" }, description = "Targeted grid's lookup locators")
    private String lookupLocators = null;

    @Parameter(names = { "-g", "--lookup-groups" }, description = "Targeted grid's Lookup group.")
    private String lookupGroup = null;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getLookupLocators() {
        return lookupLocators;
    }

    public String getLookupGroup() {
        return lookupGroup;
    }

    public boolean isSecured() {
        return (username != null || password != null);
    }

    @Override
    public String toString() {
        return "ConnectOptions{" +
                "username='" + username + '\'' +
                ", password='" + getSecuredPassword() + '\'' +
                ", lookupLocators='" + lookupLocators + '\'' +
                ", lookupGroup='" + lookupGroup + '\'' +
                '}';
    }

    private String getSecuredPassword() {
        return password == null ? password : "*****";
    }

    @Override
    public void validate() {
        if(isSecured() && (username == null || password == null)){
            throw new IllegalStateException("If connecting to a secured grid both [username] and [password] should be supplied.");
        }
    }
}


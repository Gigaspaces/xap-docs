﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("StockEntities")]
[assembly: AssemblyDescription("ExcelStock example. A Gigaspaces Platform .NET example for Gigaspaces implementation of High-Performance, Scalable Excel-Based Applications in Financial Services")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Gigaspaces Technologies, Ltd.")]
[assembly: AssemblyProduct("ExcelStock-StockEntities")]
[assembly: AssemblyCopyright("Copyright ©  2007")]
[assembly: AssemblyTrademark("Gigaspaces is a registered trademark of Gigaspaces Technologies, Ltd.")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("01161ae5-a0e5-4ed2-a52b-ef5eb29a4c5b")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

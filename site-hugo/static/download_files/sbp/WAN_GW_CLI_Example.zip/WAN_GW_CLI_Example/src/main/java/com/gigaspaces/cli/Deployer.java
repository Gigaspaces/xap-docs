package com.gigaspaces.cli;

import org.apache.commons.io.FileUtils;
import org.openspaces.admin.Admin;
import org.openspaces.admin.gateway.BootstrapResult;
import org.openspaces.admin.gateway.Gateway;
import org.openspaces.admin.gateway.GatewaySinkSource;
import org.openspaces.admin.pu.ProcessingUnitDeployment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

/**
 * @author Anna_Babich.
 */
public class Deployer {

    private static Logger logger = LoggerFactory.getLogger("Gateway-CLI: Deployer");

    private String xmlContent;

    private Admin admin;

    private boolean bootstrap;

    private String gatewayName;

    private String source;
    private int timeout;

    public Deployer(String xmlContent, Admin admin, String gatewayName) {
        this.xmlContent = xmlContent;
        this.admin = admin;
        this.gatewayName = gatewayName;
    }

    public Deployer(String xmlContent, Admin admin, boolean bootstrap, String gwName, String source, int timeout) {
        this.xmlContent = xmlContent;
        this.admin = admin;
        this.bootstrap = bootstrap;
        this.gatewayName = gwName;
        this.source = source;
        this.timeout = timeout;
    }

    public void deploy(String zone) {
        logger.debug("Deploying gateway");

        try {
            //create JAR
            Manifest manifest = new Manifest();
            manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
            JarOutputStream target = new JarOutputStream(new FileOutputStream(gatewayName + ".jar"), manifest);

            // print content to file
            File puXml = createDirectoryStructure();
            Files.write(Paths.get(puXml.getAbsolutePath()), xmlContent.getBytes());
            add(puXml, target);
            target.close();

            //deploy PU
            ProcessingUnitDeployment processingUnitDeployment = new ProcessingUnitDeployment(new File(gatewayName + ".jar"));

            if(zone != null && !Objects.equals(zone, ""))
                processingUnitDeployment.addZone(zone);

            admin.getGridServiceManagers().deploy(processingUnitDeployment);
            if (bootstrap){
                logger.debug("Bootstrap started");
                Gateway newyorkGateway = admin.getGateways().waitFor(gatewayName);
                GatewaySinkSource londonSinkSource = newyorkGateway.waitForSinkSource(source);
                BootstrapResult bootstrapResult = londonSinkSource.bootstrapFromGatewayAndWait(timeout, TimeUnit.SECONDS);

                if(bootstrapResult.isSucceeded())
                    logger.info("Bootstrap succeeded.");
                else
                    logger.debug("Bootstrap failed.", bootstrapResult.getFailureCause());
            }
        } catch (IOException e) {
            logger.error(e.getCause().toString());
        } finally {
            cleanUpTempFiles();
            logger.debug("Deploy executed");
        }
    }

    private File createDirectoryStructure() throws IOException {
        File result = new File("META-INF" + File.separator + "spring" + File.separator + "pu.xml");
        Path path = Paths.get(result.getAbsolutePath());
        Files.createDirectories(path.getParent());

        try {
            Files.createFile(path);
        } catch (FileAlreadyExistsException e) {
            logger.error("already exists: " + e.getMessage());
        }
        return result;
    }

    private void cleanUpTempFiles() {
        logger.debug("Cleaning resources.. ");
        File file = new File(gatewayName + ".jar");
        file.delete();
        try {
            FileUtils.deleteDirectory(new File("META-INF"));
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
        logger.debug("Cleaned");
    }

    private void add(File source, JarOutputStream target) throws IOException {
        BufferedInputStream in = null;
        try {
            if (source.isDirectory()){
                String name = source.getPath().replace("\\", "/");
                if (!name.isEmpty()) {
                    if (!name.endsWith("/")){
                        name += "/";
                    }
                    JarEntry entry = new JarEntry(name);
                    entry.setTime(source.lastModified());
                    target.putNextEntry(entry);
                    target.closeEntry();
                }
                for (File nestedFile: source.listFiles()){
                    add(nestedFile, target);
                }
                return;
            }

            JarEntry entry = new JarEntry(source.getPath().replace("\\", "/"));
            entry.setTime(source.lastModified());
            target.putNextEntry(entry);
            in = new BufferedInputStream(new FileInputStream(source));

            byte[] buffer = new byte[1024];
            while (true){
                int count = in.read(buffer);
                if (count == -1){
                    break;
                }
                target.write(buffer, 0, count);
            }
            target.closeEntry();
        }   finally {
            if (in != null)
                in.close();
        }
    }

}

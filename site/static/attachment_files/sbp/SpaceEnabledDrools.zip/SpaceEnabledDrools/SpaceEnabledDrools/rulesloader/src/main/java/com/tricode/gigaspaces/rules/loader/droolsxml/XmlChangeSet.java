package com.tricode.gigaspaces.rules.loader.droolsxml;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("change-set")
public class XmlChangeSet {

    private XmlAdd add;

    public XmlAdd getAdd() {
        return add;
    }

    public void setAdd(XmlAdd add) {
        this.add = add;
    }

}
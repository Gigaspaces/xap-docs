package com.gigaspaces.eviction;

import java.util.logging.Logger;

import org.openspaces.events.adapter.SpaceDataEvent;

import com.gigaspaces.domain.Order;


/**
 * The processor simulates work done no un-processed Data object. The processData
 * accepts a Data object, simulate work by sleeping, and then sets the processed
 * flag to true and returns the processed Data.
 */
public class Evictor {

	Logger logger = Logger.getLogger(this.getClass().getName());

	/**
     * Process the given Data object and returning the processed Data.
     *
     * Can be invoked using OpenSpaces Events when a matching event
     * occurs.
     */
    @SpaceDataEvent
    public void evictOrder(Order[] orders) {

    	if (orders.length > 0) {
    		logger.info(" ------ EVICTED " + orders.length + " objects. First order " + orders[0] + " Last order " + orders[orders.length - 1]);
    	} else {
    		logger.info(" ------ Nothing to EVICT");
    	}
    	

    }

}

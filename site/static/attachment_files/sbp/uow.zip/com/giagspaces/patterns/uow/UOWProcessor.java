package com.giagspaces.patterns.uow;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.EventDriven;
import org.openspaces.events.EventExceptionHandler;
import org.openspaces.events.ExceptionHandler;
import org.openspaces.events.ListenerExecutionFailedException;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.polling.Polling;
import org.springframework.transaction.TransactionStatus;

@EventDriven @Polling
public class UOWProcessor {
		
		public UOWProcessor ()
		{
		}
		
		@ExceptionHandler
		public EventExceptionHandler exceptionHandler ()
		{
			return new EventExceptionHandler() {

				@Override
				public void onException(
						ListenerExecutionFailedException exception,
						Object data, GigaSpace gigaSpace,
						TransactionStatus txStatus, Object source)
						throws RuntimeException 
						{
							System.out.println(exception);
							throw exception;
						}
				
				@Override
				public void onSuccess(Object data, GigaSpace gigaSpace,
						TransactionStatus txStatus, Object source)
						throws RuntimeException {
				}
			};
		}
			
	    @SpaceDataEvent
	    public void eventListener(UOWMessage message,GigaSpace space , TransactionStatus txStatus) {
				UOWMessage associatedMessagesTemplate = new UOWMessage();
				associatedMessagesTemplate.setGroup(message.getGroup());
				
				// consume associated Messages
				UOWMessage associatedMessages [] = space.takeMultiple (associatedMessagesTemplate, 1000);
				if (associatedMessages.length == 0) 
				{
					return;
				}
				
				// Consume the incoming message + associatedMessages
				StringBuffer buf = new StringBuffer("Consumed:Group ").append(message.getGroup()).append(" :").append(" ").append(message.getId()).append(" ");
				
				// check if really FIFO
				if (associatedMessages.length!=1)
				{
					for (int i=0;i<associatedMessages.length;i++)
					{
						buf.append(associatedMessages[i].getId()).append(" ");
						
						// not end of the array
						if (i != associatedMessages.length -1)
						{
					    	if (associatedMessages[i+1].getId() - associatedMessages[i].getId() != 20)
					    	{
					    		System.err.println("Error IN FIFO!!! Group " +associatedMessages[i].getGroup()+ " Current:" + associatedMessages[i+1].getId() + " Prev:"+associatedMessages[i].getId());
					    		// Something is wrong - rollback
					    		txStatus.setRollbackOnly();
					    		return;
								
					    	}
						}
					}
				}
				
				// Simulate processing time
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("TID:"+ Thread.currentThread().getId() + " " + buf.toString());
	    }
}

package com.gigaspaces.examples.binaryserialization.utils;

public class BinaryStreamConstants
{
	public static final byte ARRAY_NULL = -1;
	
	public static final byte VALUE_NULL = 0;
	public static final byte VALUE_NOT_NULL = 1;

	public static final byte BOOLEAN_NULL = -1;
	public static final byte BOOLEAN_FALSE = 0;
	public static final byte BOOLEAN_TRUE = 1;

	public static final byte STRING_NULL = -1;
	public static final byte STRING_EMPTY = 0;
	public static final byte STRING_ASCII = 1;
	public static final byte STRING_UNICODE = 2;
}

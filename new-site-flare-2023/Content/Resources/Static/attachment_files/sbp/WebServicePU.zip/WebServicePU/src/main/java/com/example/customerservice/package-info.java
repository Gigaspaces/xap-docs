@javax.xml.bind.annotation.XmlSchema(namespace = "http://customerservice.example.com/")
package com.example.customerservice;

package org.openspaces.calcengine;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.gsa.GridServiceContainerOptions;
import org.openspaces.admin.gsc.GridServiceContainer;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.pu.container.standalone.StandaloneProcessingUnitContainerProvider;

public class ScaleWorker2 {

	static String locators = System.getProperty("locators", "127.0.0.1");
//	static String groups = System.getProperty("groups", "gigaspaces-8.0.1-XAPPremium-ga");
	static ProcessingUnit workerPU = null;	
	public static void main(String[] args) throws Exception{
//		IntegratedProcessingUnitContainerProvider provider = new IntegratedProcessingUnitContainerProvider();
		
		StandaloneProcessingUnitContainerProvider provider =  new StandaloneProcessingUnitContainerProvider("location");
		provider.createContainer();
				
	}
}

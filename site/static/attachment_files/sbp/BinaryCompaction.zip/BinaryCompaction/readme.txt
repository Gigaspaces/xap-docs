-------
Purpose:
-------
The Binary Compressed Serialization example illustrates the default entry serialization and the Binary Compressed Serialization technique that provides better throughput and better memory footprint .

------------------------------
Building and running the demo:
------------------------------
Execute bin\compile.bat/sh in order to compile the demos. Execute bin\startSpace.bat/sh to start the space instance.  
Execute bin\runSimpleEntryTest.bat/sh to test the default Serialization. See the output.
Execute bin\runBinaryFormatEntryTest.bat/sh to test the Binary Compressed Serialization. See the output.

The runSimpleEntryTest and the runBinaryFormatEntryTest benchmark the writeMultiple , write , readMultiple , read , operations throughput.

The expected results for 32 Bit JVM:
Average SimpleEntry size = 303
SimpleEntry - Average writeMultiple (1000 entries batch) TP = 7418 oper/sec
SimpleEntry - Average write TP = 874 oper/sec
SimpleEntry - Average readMultiple  (1000 entries batch) TP = 17364 oper/sec
SimpleEntry - Average read TP = 1228 oper/sec

The results for :BinaryFormatEntry
Average BinaryFormatEntry size = 131
BinaryFormatEntry - Average writeMultiple (1000 entries batch) TP = 19324 oper/sec
BinaryFormatEntry - Average write TP = 1204 oper/sec
BinaryFormatEntry - Average readMultiple  (1000 entries batch) TP = 40439 oper/sec
BinaryFormatEntry - Average read TP = 1609 oper/sec

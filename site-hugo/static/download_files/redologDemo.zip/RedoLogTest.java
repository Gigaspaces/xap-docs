package com.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.space.Space;
import org.openspaces.admin.space.SpacePartition;
import org.openspaces.core.*;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.gateway.GatewayTarget;
import org.openspaces.core.gateway.GatewayTargetsFactoryBean;
import org.openspaces.core.space.EmbeddedSpaceConfigurer;
import org.openspaces.core.space.SpaceProxyConfigurer;

import com.gigaspaces.async.AsyncFuture;
import com.gigaspaces.cluster.activeelection.SpaceMode;
import com.j_spaces.core.filters.ReplicationStatistics.OutgoingChannel;

public class RedoLogTest {

	public static void main(String[] args) throws Exception {
		int partitonsCount = 1;
		int objectCountperPartition = 1;

		GatewayTarget gatewayTarget = new GatewayTarget();
		gatewayTarget.setName("target");
		GatewayTargetsFactoryBean gatewayTargetsFactoryBean = new GatewayTargetsFactoryBean();
		List<GatewayTarget> gatewayTargets = new ArrayList<GatewayTarget>();
		gatewayTargets.add(gatewayTarget);

		gatewayTargetsFactoryBean.setGatewayTargets(gatewayTargets);
		GigaSpace gigaSpace[] = new GigaSpace[partitonsCount];

		for (int i = 0; i < partitonsCount; i++) {
			ClusterInfo clusterInfo = new ClusterInfo();
			clusterInfo.setNumberOfInstances(partitonsCount);
			clusterInfo.setSchema("partitioned-sync2backup");
			clusterInfo.setInstanceId(i + 1);
			clusterInfo.setNumberOfBackups(1);
			gigaSpace[i] = new GigaSpaceConfigurer(new EmbeddedSpaceConfigurer("mySpace").clusterInfo(clusterInfo)
					.mirrored(true).replicationFilterProvider(new MyreplicationFilterFactory())
					.gatewayTargets(gatewayTargetsFactoryBean)).gigaSpace();
			System.out.println("created partition " + i);
		}

		for (int i = 0; i < partitonsCount; i++) {
			ClusterInfo clusterInfo = new ClusterInfo();
			clusterInfo.setNumberOfInstances(partitonsCount);
			clusterInfo.setSchema("partitioned-sync2backup");
			clusterInfo.setInstanceId(i + 1);
			clusterInfo.setBackupId(1);
			clusterInfo.setNumberOfBackups(1);
			gigaSpace[i] = new GigaSpaceConfigurer(new EmbeddedSpaceConfigurer("mySpace").clusterInfo(clusterInfo)
					.mirrored(true).replicationFilterProvider(new MyreplicationFilterFactory())
					.gatewayTargets(gatewayTargetsFactoryBean)).gigaSpace();
			System.out.println("created backup partition " + i);
		}

		Thread.sleep(2000);
		GigaSpace gigaSpaceRemote = new GigaSpaceConfigurer(new SpaceProxyConfigurer("mySpace")).gigaSpace();
		System.out.println("space got " + gigaSpaceRemote.count(new Object()) + " Data objects");
		long st = System.currentTimeMillis();
		AsyncFuture<Integer> result = gigaSpaceRemote.execute(new WriteTask(objectCountperPartition));
		int res = result.get();
		
		result = gigaSpaceRemote.execute(new WriteTaskNoRep(objectCountperPartition));
		res = result.get();
		
		/*
		 * AsyncFuture<Integer> result = gigaSpaceRemote.execute(new
		 * WriteMultipleTask(objectCountperPartition));
		 * 
		 * result.get();
		 * 
		 * AsyncFuture<Integer> result2 = gigaSpaceRemote.execute(new
		 * WriteMultipleTaskNoRep(objectCountperPartition));
		 * 
		 * result2.get();
		 */
		long end = System.currentTimeMillis();
		int count = gigaSpaceRemote.count(new Data());
		double duration = (double) (end - st) / (double) 1000;
		double tp = count / duration;
		System.out.println("space got " + gigaSpaceRemote.count(new Object()) + " Data objects");
		// System.out.println("TP [Write/Sec] =" + tp + " - test duration [Sec]
		// :" + duration );
		gigaSpaceRemote.clear(new Object());
		System.out.println("space got " + gigaSpaceRemote.count(new Object()) + " Data objects");
		//////////

		Admin admin = new AdminFactory().discoverUnmanagedSpaces().create();

		Space space = admin.getSpaces().waitFor("mySpace", 10, TimeUnit.SECONDS);
		space.waitFor(space.getNumberOfInstances(), SpaceMode.PRIMARY, 10, TimeUnit.SECONDS);
		SpacePartition partitions[] = space.getPartitions();

		for (int i = 0; i < partitions.length; i++) {
			SpacePartition partition = partitions[i];

			long redologSize = partition.getPrimary().getStatistics().getReplicationStatistics()
					.getOutgoingReplication().getRedoLogSize();
			System.out.println("redo log size for partition " + partition.getPartitionId() + " is:" + redologSize);

			List<OutgoingChannel> outgoing = partition.getPrimary().getStatistics().getReplicationStatistics()
					.getOutgoingReplication().getChannels();

			System.out.println("------------- Primary space instance replication targets -----------");

			for (Iterator iterator = outgoing.iterator(); iterator.hasNext();) {
				OutgoingChannel outgoingChannel = (OutgoingChannel) iterator.next();
				System.out.println(outgoingChannel);
			}
			Thread.sleep(1000);
		}

		admin.close();
	}
}

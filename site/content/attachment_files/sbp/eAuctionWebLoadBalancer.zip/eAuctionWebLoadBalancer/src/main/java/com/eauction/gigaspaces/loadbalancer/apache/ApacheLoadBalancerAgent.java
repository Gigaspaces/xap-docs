package com.eauction.gigaspaces.loadbalancer.apache;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.pu.container.jee.JeeServiceDetails;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;

import com.eauction.gigaspaces.loadbalancer.LoadBalancerAgent;


public class ApacheLoadBalancerAgent implements LoadBalancerAgent, Runnable {
    protected final Log log = LogFactory.getLog(ApacheLoadBalancerAgent.class);
    private String apachectlLocation;
    private String apacheLocation;
    private String configLocation;
    private String restartCommand;
    private int updateInterval = 10;
    private Map<String, LoadBalancerInfo> loadBalancersInfoMap = new ConcurrentHashMap<String, LoadBalancerInfo>();
    private Map<String, ClusterInfo> clusterInfoMap = new ConcurrentHashMap<String, ClusterInfo>();
    private Map<String, JeeServiceDetails> jeeServiceDetailsMap = new ConcurrentHashMap<String, JeeServiceDetails>();

    /**
     * Scheduler to make this monitor run in fixed intervals.
     */
    private ScheduledExecutorService executorService;

    public String getApacheLocation() {
        return apacheLocation;
    }

    public void setApacheLocation(String apacheLocation) {
        this.apacheLocation = apacheLocation;
    }

    public String getApachectlLocation() {
        return apachectlLocation;
    }

    public void setApachectlLocation(String apachectlLocation) {
        this.apachectlLocation = apachectlLocation;
    }

    public String getConfigLocation() {
        return configLocation;
    }

    public void setConfigLocation(String configLocation) {
        this.configLocation = configLocation;
    }

    public int getUpdateInterval() {
        return updateInterval;
    }

    public void setUpdateInterval(int updateInterval) {
        this.updateInterval = updateInterval;
    }

    public String getRestartCommand() {
        return restartCommand;
    }

    public void setRestartCommand(String restartCommand) {
        this.restartCommand = restartCommand;
    }

    @PostConstruct
    public void init() {
        if (apacheLocation == null) {
            if (isWindows()) {
                String programFiles = System.getenv("ProgramFiles");

                if (programFiles != null) {
                    String location = programFiles +
                        "/Apache Software Foundation/Apache2.2";

                    if (new File(location + "/bin/httpd.exe").exists()) {
                        apacheLocation = location;
                    }
                }
            } else {
                String location = "/opt/local/apache2";

                if (new File(location + "/apachectl").exists()) {
                    apacheLocation = location;
                } else {
                    location = "/opt/apache2";

                    if (new File(location + "/apachectl").exists()) {
                        apacheLocation = location;
                    }
                }
            }
        }

        if (apacheLocation != null) {
            if (isWindows()) {
                setApachectlLocation(apacheLocation + "/bin/httpd.exe");
            } else {
                setApachectlLocation(apacheLocation + "/apachectl");
            }

            if (configLocation == null) {
                setConfigLocation(apacheLocation + "/conf/gigaspaces");
            }
        }

        if (restartCommand == null) {
            if (isWindows()) {
                restartCommand = "\"" + apachectlLocation + "\" -k restart";
            } else {
                restartCommand = apachectlLocation + " graceful";
            }
        }

        log.info("Apachectl Location [" + apachectlLocation + "]");
        log.info("Config directory [" + configLocation + "]");

        // list all the files and init with empty load balancers
        log.info("Detecting existing config files...");
        new File(configLocation).listFiles(new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    String clusterName = name.substring(0,
                            name.length() - ".conf".length());
                    log.info("[" + clusterName + "] existing config detected");
                    loadBalancersInfoMap.put(clusterName,
                        new LoadBalancerInfo(clusterName));

                    return false;
                }
            });
        log.info("Started Apache Load Balancer Agent successfully");
        log.info("Make sure Apache is configured with [Include " +
            new File(configLocation).getAbsolutePath() + "/*.conf]");

        executorService = Executors.newScheduledThreadPool(1);
        executorService.scheduleWithFixedDelay(this, 1, updateInterval,
            TimeUnit.SECONDS);
    }

    @PreDestroy
    public void destroy() {
        log.info("Stopping Apached Load Balancer Agent...");
    }

    public void processingUnitAdded(ProcessingUnitInstance puInstance) {
        ClusterInfo clusterInfo = puInstance.getClusterInfo();
        JeeServiceDetails jeeDetails = puInstance.getJeeDetails();

        log.info("[" + clusterInfo.getName() + "] Adding [" +
            puInstance.getUid() + "] [" + jeeDetails.getHost() + ":" +
            jeeDetails.getPort() + jeeDetails.getContextPath() + "]");

        LoadBalancerInfo loadBalancersInfo = loadBalancersInfoMap.get(clusterInfo.getName());

        if (loadBalancersInfo == null) {
            loadBalancersInfo = new LoadBalancerInfo(clusterInfo.getName());
            loadBalancersInfoMap.put(clusterInfo.getName(), loadBalancersInfo);
        }

        clusterInfoMap.put(puInstance.getUid(), clusterInfo);
        jeeServiceDetailsMap.put(puInstance.getUid(), jeeDetails);
        loadBalancersInfo.putNode(new LoadBalancerNodeInfo(
                puInstance.getUid(), clusterInfo, jeeDetails));
        loadBalancersInfo.setDirty(true);
    }

    public void processingUnitRemoved(ProcessingUnitInstance puInstance) {
        ClusterInfo clusterInfo = puInstance.getClusterInfo();
        JeeServiceDetails jeeServiceDetails = puInstance.getJeeDetails();

        System.out.println("[" + clusterInfo.getName() + "] Removing [" +
            puInstance.getUid() + "] [" + jeeServiceDetails.getHost() + ":" +
            jeeServiceDetails.getPort() + jeeServiceDetails.getContextPath() +
            "]");

        LoadBalancerInfo loadBalancersInfo = loadBalancersInfoMap.get(clusterInfo.getName());

        if (loadBalancersInfo != null) {
            loadBalancersInfo.removeNode(new LoadBalancerNodeInfo(
                    puInstance.getUid(), clusterInfo, jeeServiceDetails));
            loadBalancersInfo.setDirty(true);
        }
    }

    public void run() {
        boolean dirty = false;

        for (Map.Entry<String, LoadBalancerInfo> entry : loadBalancersInfoMap.entrySet()) {
            LoadBalancerNodeInfo[] infos = null;

            synchronized (this) {
                if (entry.getValue().isDirty()) {
                    infos = entry.getValue().getNodes();
                    entry.getValue().setDirty(false);
                }
            }

            if ((infos == null) || (infos.length == 0)) {
                continue;
            }

            dirty = true;
            log.info("[" + entry.getKey() +
                "] Detected as dirty, updating config file...");

            File confFile = new File(configLocation + "/" + entry.getKey() +
                    ".conf");

            try {
                log.info("[" + entry.getKey() +
                    "] Locating balancer template [" + entry.getKey() + ".vm]");

                ClassPathResource resource = new ClassPathResource(entry.getKey() +
                        ".vm");

                if (!resource.exists()) {
                    log.info("[" + entry.getKey() +
                        "] Locating balancer template [balancer-template.vm]");
                    resource = new ClassPathResource("balancer-template.vm");
                }

                if (!resource.exists()) {
                    log.info("[" + entry.getKey() +
                        "] Cannot find velocity template, please generate one.");
                }

                if (resource.exists()) {
                    log.info("[" + entry.getKey() +
                        "] Using balancer template [" +
                        resource.getFile().getAbsolutePath() + "]");
                    Velocity.init();

                    PrintWriter writer = null;
                    Reader templateReader = null;

                    try {
                        writer = new PrintWriter(new FileOutputStream(confFile));
                        templateReader = new BufferedReader(new InputStreamReader(
                                    resource.getInputStream()));

                        VelocityContext context = new VelocityContext();
                        context.put("loadBalancerInfo", entry.getValue());
                        Velocity.evaluate(context, writer, "", templateReader);
                    } finally {
                        if (writer != null) {
                            writer.flush();
                            writer.close();
                        }

                        if (templateReader != null) {
                            templateReader.close();
                        }
                    }

                    log.info("[" + entry.getKey() + "] Updated config file");
                }
            } catch (Exception e) {
                log.info("Failed to write config file, will try again later");
                e.printStackTrace(System.out);
                entry.getValue().setDirty(true);
            }
        }

        if (dirty) {
            log.info("Executing [" + restartCommand + "]...");

            Process process = null;

            try {
                process = Runtime.getRuntime().exec(restartCommand);

                boolean exited = waitFor(process, 60000);
                int exitValue = -999;

                if (exited) {
                    exitValue = process.exitValue();
                }

                log.info("Executed [" + restartCommand + "], exit code [" +
                    exitValue + "]");

                if (exitValue != 0) {
                    String output = FileCopyUtils.copyToString(new InputStreamReader(
                                process.getErrorStream()));
                    System.out.println(output);
                }
            } catch (IOException e) {
                System.out.println("Failed to run [" + restartCommand + "]");
                e.printStackTrace(System.out);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                if (process != null) {
                    try {
                        process.getErrorStream().close();
                    } catch (Exception e) {
                        // do nothing
                    }

                    try {
                        process.getInputStream().close();
                    } catch (Exception e) {
                        // do nothing
                    }

                    try {
                        process.getOutputStream().close();
                    } catch (Exception e) {
                        // do nothing
                    }

                    try {
                        process.destroy();
                    } catch (Exception e) {
                        // do nothing
                    }
                }
            }
        }
    }

    private boolean waitFor(Process process, long timeout)
        throws InterruptedException {
        /* interval constant */
        final int interval = 200; // 200 milliseconds
        long timeWaiting = 0;

        while (timeWaiting < timeout) {
            if (!isProcessAlive(process)) {
                return true;
            }

            /* process still alive, wait next interval */
            Thread.sleep(interval);
            timeWaiting += interval;
        }

        /* process hasn't been destroyed */
        return false;
    }

    /**
     * @return <code>true</code> if supplied process is still alive, otherwise <code>false</code>
     */
    private boolean isProcessAlive(Process process) {
        try {
            process.exitValue();

            return false;
        } catch (IllegalThreadStateException e) {
            return true;
        }
    }

    private static boolean isWindows() {
        String osName = System.getProperty("os.name");

        if ((osName != null) && osName.startsWith("Windows")) {
            return true;
        } else {
            return false;
        }
    }
}

package com.tricode.gigaspaces.rules.space.drools.loader;

import com.j_spaces.core.client.ReadModifiers;
import com.j_spaces.core.client.SQLQuery;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRuleset;
import org.apache.log4j.Logger;
import org.drools.definition.KnowledgePackage;
import org.openspaces.core.GigaSpace;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Loads drools rules from the space.
 */
public class SpaceDroolsRuleLoader implements IDroolsRuleLoader {

    private final Logger log = Logger.getLogger(SpaceDroolsRuleLoader.class);

    private final GigaSpace gigaSpace;

    // Don't create new query objects every operation, this is very expensive
    private final SQLQuery<DroolsRuleset> rulesetByRulesetNameQuery =
            new SQLQuery<DroolsRuleset>(DroolsRuleset.class, "ruleSetName = ?");

    private final SQLQuery<DroolsRuleset> rulesetByRulesetAndProjectNameQuery =
            new SQLQuery<DroolsRuleset>(DroolsRuleset.class, "projectName = ? AND ruleSetName = ?");

    private final SQLQuery<DroolsRuleset> knowledgePackageQuery =
            new SQLQuery<DroolsRuleset>(DroolsRuleset.class, "projectName = ?");

    public SpaceDroolsRuleLoader(GigaSpace gigaSpace) {
        this.gigaSpace = gigaSpace;
    }

    /**
     * {@inheritDoc}
     */
    public Collection<KnowledgePackage> getKnowledgePackages(String projectName, String rulesetName) {
        if (log.isDebugEnabled()) {
            log.debug(String.format("Requested packages for {%s,%s}", projectName, rulesetName));
        }

        SQLQuery<DroolsRuleset> sqlQuery;
        if (projectName != null) {
            sqlQuery = rulesetByRulesetAndProjectNameQuery;
            sqlQuery.setParameter(1, projectName);
            sqlQuery.setParameter(2, rulesetName);
        } else {
            sqlQuery = rulesetByRulesetNameQuery;
            sqlQuery.setParameter(1, rulesetName);
        }

        log.info(String.format("Query: '%s'", sqlQuery));
        DroolsRuleset[] ruleSets = gigaSpace.readMultiple(sqlQuery, Integer.MAX_VALUE, ReadModifiers.DIRTY_READ);
        log.info(String.format("Query: '%s' rule packages.", ruleSets.length));

        Collection<KnowledgePackage> packagesList = new ArrayList<KnowledgePackage>();
        for (DroolsRuleset rulesSet : ruleSets) {
            log.info(String.format("Ruleset: {%s, %s}", rulesSet.getKnowledgePackages(), rulesSet.getStatus()));
            packagesList.addAll(rulesSet.getKnowledgePackages());
        }

        return packagesList;
    }

    /**
     * {@inheritDoc}
     */
    public Collection<KnowledgePackage> getKnowledgePackages(String projectName) {
        if (log.isDebugEnabled()) {
            log.debug("Requested packages for " + projectName);
        }

        knowledgePackageQuery.setParameter(1, projectName);

        log.info(String.format("Query: '%s'", knowledgePackageQuery));
        DroolsRuleset[] ruleSets = gigaSpace.readMultiple(knowledgePackageQuery, Integer.MAX_VALUE, ReadModifiers.DIRTY_READ);
        log.info(String.format("Query: '%s' rule packages.", ruleSets.length));

        Collection<KnowledgePackage> packagesList = new ArrayList<KnowledgePackage>();
        for (DroolsRuleset rulesSet : ruleSets) {
            log.info(String.format("Ruleset: {%s, %s}", rulesSet.getKnowledgePackages(), rulesSet.getStatus()));
            packagesList.addAll(rulesSet.getKnowledgePackages());
        }

        return packagesList;
    }

}
using GigaSpaces.Examples.ExcelStocks.StockEntities;
using GigaSpaces.Examples.ExcelStocks.Quote.Framework;

namespace GigaSpaces.Examples.ExcelStocks.Quote
{
    /// <summary>
    /// The specific implementation of RtdEntityServer for StockData.
    /// </summary>
    internal class RtdStockServer : RtdEntityServer<StockData>
    {
        protected override object GetFieldValue(StockData instance, string fieldName)
        {
            switch (fieldName)
            {
                case "symbol": return instance.Symbol;
                case "time": return instance.Time;
                case "prev": return instance.Prev;
                case "last": return instance.Last;
                case "bid": return instance.Bid;
                case "ask": return instance.Ask;
                case "low": return instance.Low;
                case "high": return instance.High;
                case "open": return instance.Open;
                case "bidsize": return instance.BidSize;
                case "asksize": return instance.AskSize;
                case "analystcomment": return instance.AnalystComment;
                default: return "Unrecognized field requested. value=" + fieldName;
            }
        }

        protected override void SetKey(StockData instance, object key)
        {
            instance.Symbol = (string)key;
        }

        protected override object GetKey(StockData instance)
        {
            return instance.Symbol;
        }
    }
}

package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;
import com.j_spaces.core.cluster.RedoLogCapacityExceededPolicy;

public class LinkSpaceOptions extends ValidateableOptions {

    @Parameter(names = {"-a", "--add"}, description = "Add target gateway.")
    private boolean isAdd;

    @Parameter(names = {"-r", "--remove"}, description = "Remove target gateway.")
    private boolean isRemove;

    @Parameter(names = {"-l", "--list"}, description = "Prints all the targets already associated with the space.")
    private boolean isList;

    @Parameter(names = { "-n", "--name"}, description = "Gateway site name.")
    private String name;

    @Parameter(names = {"-b", "--bulk-size"}, description = "Replication bulk size." )
    private int bulkSize = 100;

    @Parameter(names = {"-i", "--idle-time-threshold"}, description = "Maximum pause between replication events.")
    private long idleTimeThreshold = 3000;

    @Parameter(names = { "-m", "--max-redo-capacity"}, description = "Maximum replication log capacity.")
    private long maxRedoLogCapacity = 10000;

    @Parameter(names = {"-o", "--on-capacity-exceeded"}, description = "What operation to perform when replication log capacity has been exceeded.")
    private RedoLogCapacityExceededPolicy onRedoCapcityExceeded = RedoLogCapacityExceededPolicy.BLOCK_OPERATIONS;

    @Parameter(names = {"-c", "--replicate-change-as-update"}, description = "Replicate space object changes as update events.")
    private boolean replicateChangeAsUpdate = true;

    @Parameter(names = {"-s", "--space-name"}, description = "Space name to modify connection on.")
    private String spaceName;

    @Override
    public void validate() {
        if((isAdd() && isRemove()) || (isAdd() && isList()) || (isList() && isRemove()))
            throw new IllegalArgumentException("you can specify only one of [add] [remove] [list] in the same request.");

        if(!isList && getName() == null) throw new IllegalArgumentException("Gateway site name must be specified.");

        if(getSpaceName() == null) throw new IllegalArgumentException("Target space name must be provided.");
    }

    public boolean isAdd() {
        return isAdd;
    }

    public boolean isRemove() {
        return isRemove;
    }

    public boolean isList() {
        return isList;
    }

    public String getName() {
        return name;
    }

    public int getBulkSize() {
        return bulkSize;
    }

    public long getIdleTimeThreshold() {
        return idleTimeThreshold;
    }

    public long getMaxRedoLogCapacity() {
        return maxRedoLogCapacity;
    }

    public RedoLogCapacityExceededPolicy getOnRedoCapcityExceeded() {
        return onRedoCapcityExceeded;
    }

    public boolean getReplicateChangeAsUpdate() {
        return replicateChangeAsUpdate;
    }

    public String getSpaceName() {
        return spaceName;
    }

    @Override
    public String toString() {
        return "LinkSpaceOptions{" +
                "isAdd=" + isAdd +
                ", isRemove=" + isRemove +
                ", isList=" + isList +
                ", name='" + name + '\'' +
                ", bulkSize=" + bulkSize +
                ", idleTimeThreshold=" + idleTimeThreshold +
                ", maxRedoLogCapacity=" + maxRedoLogCapacity +
                ", onRedoCapcityExceeded=" + onRedoCapcityExceeded +
                ", replicateChangeAsUpdate=" + replicateChangeAsUpdate +
                ", spaceName='" + spaceName + '\'' +
                '}';
    }
}


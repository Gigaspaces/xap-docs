package com.gigaspaces.cli.operations;

import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.Deployer;
import com.gigaspaces.cli.generator.XmlGenerator;
import com.gigaspaces.cli.jcommander.parameters.DeployOptions;
import com.gigaspaces.cli.model.WANGatewayModel;
import org.openspaces.schema.core.gateway.Sink;

import java.util.Map;

/**
 * Created by skyler on 5/27/2015.
 */
public class DeployOperation implements Operation<DeployOptions> {
    private XmlGenerator xmlGenerator = new XmlGenerator();

    @Override
    public void run(DeployOptions options, CliGatewayContext context) {
        Map<String, WANGatewayModel> models = context.getModels();

        WANGatewayModel wanGatewayModel = models.get(options.getName());

        if (wanGatewayModel == null){
            throw new IllegalArgumentException("Gateway["+ options.getName() + "] has not been initialized.");
        }

        String content;

        try {

            boolean isBootstrap = options.getBootStrapSource() != null;

            if(isBootstrap){
                for(Sink s : wanGatewayModel.getSinks().values()){
                    for(Sink.Sources.Source source : s.getSources().getSource()){
                        if(source.getName().equals(options.getBootStrapSource()))
                            s.setRequiresBootstrap(isBootstrap);
                    }
                }
            }

            content = xmlGenerator.generate(wanGatewayModel, options.isXap9());
            Deployer deployer = new Deployer(content, context.getAdmin(), options.getName());

            if(isBootstrap)
                deployer = new Deployer(content, context.getAdmin(),isBootstrap, options.getName(), options.getBootStrapSource(), options.getTimeout());


            deployer.deploy(options.getZone());
        } catch (Exception e) {
            throw new RuntimeException("Caught exception while deploying gateway.", e);
        }
    }
}

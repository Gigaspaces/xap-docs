package com.gigaspaces.cli.jcommander.parameters;

import com.beust.jcommander.Parameter;

public class InitializeOptions extends ValidateableOptions {

    @Parameter(names = { "-n", "--name" }, description = "New gateway name.")
    private String name;

    public String getName(){
        return name;
    }

    @Override
    public String toString() {
        return "InitializeGatewayParameters{" +
                "name=" + name +
                '}';
    }

    @Override
    public void validate() {
        if(name == null) throw new IllegalArgumentException("Argument [name] cannot be null.");
    }
}

1) Ensure you have GigaSpacesXAP6.0 or higher  
2) Ensure you have JDK1.5 or higher
3) Extract the provided zip somewhere with no spaces in the path
4) Edit the demo_setup.bat provided in the demo folder (the top three variables)
5) Run build.bat 
6) run startDemo.cmd  
(Look for the running shell and follow the prompts written in the title bar)

These * items are all in the prompts...:

  *)deploy syncremotingsystem NOTE default is 3 partitions with backup
  *)deploy the syncremotingclient
  [Note that the client requires that the space is running first.  So ensure   
    the syncremotingsystem is running before you try to deploy the client.]

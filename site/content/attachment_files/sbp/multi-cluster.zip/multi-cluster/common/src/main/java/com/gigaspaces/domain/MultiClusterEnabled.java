package com.gigaspaces.domain;

public abstract class MultiClusterEnabled {

	public boolean multiClusterReplicate = true;

	public boolean isMultiClusterReplicate() {
		return multiClusterReplicate;
	}

	public void setMultiClusterReplicate(boolean multiClusterReplicate) {
		this.multiClusterReplicate = multiClusterReplicate;
	}
}

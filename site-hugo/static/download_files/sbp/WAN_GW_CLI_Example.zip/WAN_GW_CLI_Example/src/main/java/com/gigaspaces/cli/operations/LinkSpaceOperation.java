package com.gigaspaces.cli.operations;

import com.gigaspaces.async.AsyncFuture;
import com.gigaspaces.cli.CliGatewayContext;
import com.gigaspaces.cli.jcommander.parameters.LinkSpaceOptions;
import com.gigaspaces.cli.task.CollectTargetsTask;
import org.openspaces.admin.Admin;
import org.openspaces.admin.space.Space;
import org.openspaces.admin.space.SpaceReplicationManager;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.gateway.GatewayTarget;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;
import java.util.concurrent.ExecutionException;

/**
 * Created by skyler on 5/27/2015.
 */
public class LinkSpaceOperation implements Operation<LinkSpaceOptions> {

    private static Logger logger = LoggerFactory.getLogger("Link");

    @Override
    public void run(LinkSpaceOptions options, CliGatewayContext context) {
        Admin admin = context.getAdmin();
        Space targetSpace = admin.getSpaces().waitFor(options.getSpaceName());
        if (options.isList()){
            listTargets(targetSpace);
        }   else {
            SpaceReplicationManager manager = targetSpace.getReplicationManager();
            disconnect(options, manager);
            if (options.isAdd()){
                connect(options, manager);
            }
        }
    }

    private void listTargets(Space targetSpace) {
        GigaSpace gigaSpace = targetSpace.getGigaSpace();
        AsyncFuture<Set<String>> asyncTargets = gigaSpace.execute(new CollectTargetsTask());
        try {
            Set<String> strings = asyncTargets.get();
            logger.info("Targets:");
            for (String target : strings){
                logger.info(target);
            }
        } catch (InterruptedException | ExecutionException e) {
            logger.warn("Unable to list targets because of", e);
        }
    }

    private void connect(LinkSpaceOptions options, SpaceReplicationManager manager) {
        GatewayTarget gatewayTarget = new GatewayTarget(options.getName());
        gatewayTarget.setBulkSize(options.getBulkSize());
        gatewayTarget.setIdleTimeThreshold(options.getIdleTimeThreshold());
        gatewayTarget.setMaxRedoLogCapacity(options.getMaxRedoLogCapacity());
        gatewayTarget.setOnRedoLogCapacityExceeded(options.getOnRedoCapcityExceeded());
        gatewayTarget.setReplicateChangeAsUpdate(options.getReplicateChangeAsUpdate());

        manager.addGatewayTarget(gatewayTarget);
    }

    private void disconnect(LinkSpaceOptions options, SpaceReplicationManager manager) {
        manager.removeGatewayTarget(options.getName());
    }

}



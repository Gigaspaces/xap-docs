package com.tricode.gigaspaces.rules.space.drools.compiler;

import com.j_spaces.core.client.SQLQuery;
import com.tricode.gigaspaces.rules.shared.RulesetStatus;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsDslDefinition;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRule;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRuleset;
import org.apache.log4j.Logger;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.openspaces.core.GigaSpace;
import org.openspaces.events.EventDriven;
import org.openspaces.events.EventTemplate;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.polling.Polling;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

@EventDriven
@Polling(gigaSpace = "gigaSpace")
public class RulesCompiler {

    private final Logger log = Logger.getLogger(RulesCompiler.class);

    @Autowired
    private GigaSpace gigaSpace;

    /**
     * Listens for creation of new rule sets with status 'unprocessed'.
     *
     * @return Template to use for search.
     */
    @EventTemplate
    public static SQLQuery<DroolsRuleset> findUnprocessedRuleSets() {
        return new SQLQuery<DroolsRuleset>(DroolsRuleset.class, "status = ?", RulesetStatus.UNPROCESSED);
    }

    @SpaceDataEvent
    public DroolsRuleset processRule(DroolsRuleset set) {
        set.setKnowledgePackages(null);

        try {
            // find related objects
            final DroolsDslDefinition definitionTemplate = new DroolsDslDefinition();
            definitionTemplate.setRuleSetId(set.getId());
            DroolsDslDefinition[] definitions = gigaSpace.readMultiple(definitionTemplate, Integer.MAX_VALUE);

            final DroolsRule ruleTemplate = new DroolsRule();
            ruleTemplate.setRuleSetId(set.getId());
            DroolsRule[] rules = gigaSpace.readMultiple(ruleTemplate, Integer.MAX_VALUE);

            KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();

            // add DSL
            for (DroolsDslDefinition definition : definitions) {
                kbuilder.add(ResourceFactory.newByteArrayResource(definition.getDslBytes()), ResourceType.DSL);
            }

            // add rules to use
            for (DroolsRule rule : rules) {
                kbuilder.add(ResourceFactory.newByteArrayResource(rule.getRuleBytes()),
                        ResourceType.getResourceType(rule.getResourceTypeString()));
            }

            // log any errors
            if (kbuilder.hasErrors()) {
                for (KnowledgeBuilderError error : kbuilder.getErrors()) {
                    log.error(error.getMessage() + " on lines " + Arrays.toString(error.getErrorLines()));
                }
                throw new IllegalArgumentException("Could not parse knowledge.");
            }

            KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
            kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

            set.setKnowledgePackages(kbase.getKnowledgePackages());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            set.setStatus(RulesetStatus.EXCEPTION);
            return set;
        }

        set.setStatus(RulesetStatus.COMPILED);

        log.info(String.format("Rules compiled successfully for ruleset '%s'", set.getRuleSetName()));

        return set;
    }

}
#!/bin/bash


source ./undeploy.sh
source ./deploy.sh
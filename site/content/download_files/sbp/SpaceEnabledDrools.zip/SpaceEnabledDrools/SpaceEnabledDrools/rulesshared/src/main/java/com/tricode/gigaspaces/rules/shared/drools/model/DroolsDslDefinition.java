package com.tricode.gigaspaces.rules.shared.drools.model;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;

import java.io.Serializable;

/**
 * The contents of a single DSL file.
 */
@SpaceClass(persist = false, replicate = false)
public class DroolsDslDefinition implements Serializable {

    private static final long serialVersionUID = -7187529469674707974L;

    /**
     * Unique ID.
     */
    private String id;

    /**
     * The ID of rhe ruleset to which this DSL belongs
     */
    private String ruleSetId;

    private String projectName;

    /**
     * The DSL content as bytes.
     */
    private byte[] dslBytes;

    /**
     * Public no-arg constructor is required by GigaSpaces.
     */
    public DroolsDslDefinition() {
    }

    @SpaceId(autoGenerate = true)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRuleSetId() {
        return ruleSetId;
    }

    public void setRuleSetId(String ruleSetId) {
        this.ruleSetId = ruleSetId;
    }

    @SpaceRouting
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public byte[] getDslBytes() {
        return dslBytes;
    }

    public void setDslBytes(byte[] dslBytes) {
        this.dslBytes = dslBytes.clone();
    }

}
package com.gigaspaces.cli.generator;

import com.gigaspaces.cli.model.WANGatewayModel;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.openspaces.schema.core.gateway.Delegator;
import org.openspaces.schema.core.gateway.Lookups;
import org.openspaces.schema.core.gateway.Sink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.IOException;
import java.io.StringWriter;

/**
 * @author Anna_Babich.
 */
public class XmlGenerator {

    private static Logger logger = LoggerFactory.getLogger("Gateway-CLI : XmlGenerator");

    private static final String TEMPLATE_FILE_XAP9 = "templates/pu_template9.vm";
    private static final String TEMPLATE_FILE = "templates/pu_template.vm";

    private static final String DELEGATORS = "delegators";

    private static final String LOOKUPS = "lookups";

    private static final String SINKS = "sinks";

    public static final String LOOKUPS_ID = "lookups";

    public String generate(WANGatewayModel model, boolean isXap9) throws Exception {
        VelocityEngine ve = createVelocityEngine();
        Template t;

        if(isXap9)
            t = ve.getTemplate(TEMPLATE_FILE_XAP9);
        else
            t = ve.getTemplate(TEMPLATE_FILE);

        VelocityContext context = new VelocityContext();
        context.put(LOOKUPS, generateLookups(model));
        context.put(DELEGATORS, generateDelegators(model));
        context.put(SINKS, generateSinks(model));
        StringWriter writer = new StringWriter();
        t.merge( context, writer );
        logger.debug(writer.toString());
        return writer.toString();
    }

    private VelocityEngine createVelocityEngine() throws Exception {
        VelocityEngine ve = new VelocityEngine();
        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.init();
        return ve;
    }

    private String generateDelegators(WANGatewayModel model) throws JAXBException, IOException {
        StringWriter stringWriter = new StringWriter();
        for (Delegator delegator : model.getDelegators().values()){
            Marshaller jaxbMarshaller = createMarshaller(Delegator.class);
            jaxbMarshaller.marshal(delegator, stringWriter);
        }
        return stringWriter.toString();
    }

    private String generateSinks(WANGatewayModel model) throws JAXBException, IOException {
        StringWriter stringWriter = new StringWriter();
        for (Sink sink : model.getSinks().values()){
            Marshaller jaxbMarshaller = createMarshaller(Sink.class);
            jaxbMarshaller.marshal(sink, stringWriter);
        }
        return stringWriter.toString();
    }

    private String generateLookups(WANGatewayModel model) throws JAXBException, IOException {
        StringWriter stringWriter = new StringWriter();
        Lookups lookups = model.getLookups();
        lookups.setId(LOOKUPS_ID);
        Marshaller jaxbMarshaller = createMarshaller(Lookups.class);
        jaxbMarshaller.marshal(lookups, stringWriter);
        return stringWriter.toString();
    }

    private Marshaller createMarshaller(Class clazz) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        return jaxbMarshaller;
    }

}
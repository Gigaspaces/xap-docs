﻿using System;
using System.Runtime.InteropServices;
using System.Configuration;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;   

using GigaSpaces.Core;

namespace GigaSpaces.Examples.ExcelStocks.Quote
{
    /// <summary>
    /// Real time Stock Market Data. Notify on all updates to a Symbols. 
    /// </summary>
    [ComVisible(true)]
    [ProgId("Stock.Quote")]
    public class StockQuote : IRtdServer
    {
        // The specific implementation of RtdEntityServer for StockData
        private RtdStockServer _rtdEntityServer = new RtdStockServer();

        #region IRtdServer interface implementation

        /// <summary>
        /// This method is called when Excel requests the first topic 
        /// from the real-time data server. 
        /// This method call is immediately followed by a call to the ConnectData 
        /// method. 
        /// </summary>
        /// <param name="CallbackObject">The CallbackObject parameter is a required IRTDUpdateEvent callback 
        /// object that the RTD server uses to notify Excel when it should gather 
        /// updates from the RTD server through the IRTDUpdateEvent callback 
        /// object's UpdateNotify method.</param>
        /// <returns>This method returns a Long value; a value of 1 indicates 
        /// a successful request, and a value of zero (0) or a negative value 
        /// indicates a failed request.</returns>
        public int ServerStart(IRTDUpdateEvent CallbackObject)
        {
			try
			{
				// Config the JVM Initial and Maximum Heap Size
				SpaceProxyProviderFactory.Configuration.JvmSettings.JvmMemory.InitialHeapSizeInMB = 16;
				SpaceProxyProviderFactory.Configuration.JvmSettings.JvmMemory.MaximumHeapSizeInMB = 64;

				// Get space connection string:
				string spaceUrl = ConfigurationManager.AppSettings["SpaceUrlMarket"];
				if (spaceUrl == null)
				{
					MessageBox.Show("Could not find the configuration of the space url ('SpaceUrlMarket' "
					+ "in the application config file 'excel.exe.config')");
					return 0;
				}
                // Connect:
                this._rtdEntityServer.Connect(CallbackObject, spaceUrl);

                // All is well, return 1 
                return 1;
            }
            catch (Exception ex)
            {
				_rtdEntityServer.LogError("Error in StockQuote.ServerStart. Message:", ex);
                return 0;
            }
        }

        /// <summary>
        /// This method is called when Excel no longer requires topics 
        /// from the RTD server (for example, the user quits Excel).
        /// </summary>
        public void ServerTerminate()
        {
            try
            {
                _rtdEntityServer.Dispose();
            }
            catch (Exception ex)
            {
				_rtdEntityServer.LogError(" Error in StockQuote.ServerTerminate. Message:", ex);
            }
        }

        /// <summary>
        /// If the RTD server is no longer able to process RefreshData method calls, 
        /// the Heartbeat method enables Excel to pop up a dialog box that says 
        /// "The real-time data server 'XYZ' is not responding. Would you like 
        /// Microsoft Excel to attempt to restart the server?" 
        /// This method returns a Long value; a value of 1 indicates that the 
        /// real-time data server connection still exists, and a value of zero (0) 
        /// or a negative value indicates that the real-time data server connection 
        /// no longer exists.
        /// </summary>
        /// <returns>1 - the RTD server is up and running, 0 - indicates error</returns>
        public int Heartbeat()
        {
            return 1;
        }

        /// <summary>
        /// This method is called whenever Excel requests new topics from the RTD server. 
        /// </summary>
        /// <param name="topicID">A value that 
        /// represents a unique, arbitrary value automatically 
        /// assigned by Excel (for example, "34") that identifies the topic.</param>
        /// <param name="arguments">An array of one or more 
        /// values that the user enters into the RTD function to uniquely 
        /// identify the topic. This array should always be 
        /// an array of string values. </param>
        /// <param name="getNewValues">True if new values are to be retrieved. 
        /// Leave the getNewValues parameter alone if you want Excel 
        /// to use the previous value that it had saved with the Excel spreadsheet.</param>
        /// <returns></returns>
        public object ConnectData(int topicID, ref Array arguments, ref bool getNewValues)
        {
            getNewValues = true;

            try
            {
                return _rtdEntityServer.GetTopicValue(topicID, arguments);
            }
            catch (Exception ex)
            {
                //Any unexpected error.  
                _rtdEntityServer.LogError(" Error in StockQuote. Message:", ex);
                return "Error in StockQuote. Error:" + ex.Message;
            }
        }

        /// <summary>
        /// This method is called whenever Excel no longer requires a specific topic.
        /// </summary>
        /// <param name="TopicID">The TopicID parameter is a required Long value that 
        /// represents the arbitrary, unique value automatically assigned by Excel in the ConnectData 
        /// method that identifies the topic.</param>
        public void DisconnectData(int TopicID)
        {
        }

        /// <summary>
        /// This method returns a two-dimensional array of values. 
        /// The first dimension represents a list of topic IDs; these topic IDs 
        /// map to the TopicID parameter in the ConnectData method above. 
        /// This is how Excel associates topics with data.
        /// The second dimension represents the values associated with the topic IDs.
        /// </summary>
        /// <param name="TopicCount">A required Long value that the RTD server provides.
        /// This method returns in the TopicCount the number of elements returned in 
        /// the array of values</param>
        /// <returns>A two-dimensional (m X n) array of values. 
        /// The 1st dimention (m) is always 2 entries - topic [0, ] and value [1, ].
        /// The 2nd dimention (n) is the number of cells we want to update in the Excel 
        /// as a result of this specific event
        /// </returns>
        public Array RefreshData(ref int TopicCount)
        {
            return _rtdEntityServer.GetChanges(ref TopicCount);
        }

        #endregion
    }
}
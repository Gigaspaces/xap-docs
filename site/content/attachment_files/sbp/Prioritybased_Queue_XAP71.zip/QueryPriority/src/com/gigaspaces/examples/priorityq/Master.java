package com.gigaspaces.examples.priorityq;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import org.openspaces.core.GigaSpace;
import net.jini.core.lease.Lease;

class Master extends Thread {
	GigaSpace space;
	Random rand = new Random (); 
	boolean mode = true;
	static AtomicInteger id = new AtomicInteger(0);

	Master(GigaSpace space) {
		this.space = space;

	}
	public void setMode(boolean mode) {
		this.mode = mode;
	}

	public void run() {
		System.out.println("Master " + Thread.currentThread().getId() + " Started");
		try {
			Order task = new Order();
			while (mode) {
				id.getAndIncrement();
				task.priority = new Integer(rand.nextInt(9) + 1);
				task.id = new Integer(id.get());
				task.timestamp = System.currentTimeMillis();
				space.write(task, Lease.FOREVER);
				//System.out.println("wrote:" + task);
				Thread.sleep(20);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
package org.openspaces.calcengine;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.calcengine.common.CalculateNPVUtil;
import org.openspaces.calcengine.executor.AnalysisTask;
import org.openspaces.calcengine.executor.NPVResultsReducer;
import org.openspaces.core.ExecutorBuilder;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.SpaceProxyConfigurer;
import com.gigaspaces.async.AsyncFuture;

public class ClientExecutor {

	static String locators = System.getProperty("locators", "127.0.0.1");
	static Logger logger = Logger.getLogger("Client");
	static DecimalFormat formater = new DecimalFormat("0.0");
	static int MAX_TRADES = 10000;
	static int MAX_ITERATIONS = 1000000;
	
	static double rates[] = {2,3,4,5,6,7,8};
	
	public static void main(String[] args) throws Exception{
		
		GigaSpace gigaspace = new GigaSpaceConfigurer(new SpaceProxyConfigurer("CalcDataGrid").lookupLocators(locators)).gigaSpace();
		
		if (gigaspace==null)
		{
			System.out.println("Can't get space proxy");
			System.exit(0);
		}
		
		// Try unmanaged Spaces. Maybe running the space within the IDE or using gsInstance
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().addLocator(locators).createAdmin();

		if (admin == null)
		{
			System.out.println("Can locate lookup service and generate admin object. Exit");
			System.exit(0);
		}
		
		int partitionCount = admin.getSpaces().waitFor("CalcDataGrid", 5, TimeUnit.SECONDS).getPartitions().length;

		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);
		Logger.getLogger("net.jini.discovery.LookupLocatorDiscovery").setLevel(Level.OFF);
		
		System.out.println("We have " + partitionCount + " partitions");
		
		Integer[] ids  = new Integer[MAX_TRADES];
		for (int i=0;i<MAX_TRADES;i++)
		{
			ids [i] = i ;
		}
		
		// Mapping IDs to partition
		HashMap<Integer , HashSet<Integer>> partitionIDSDistro = CalculateNPVUtil.splitIDs(ids , partitionCount );
		AnalysisTask analysisTasks[] = new AnalysisTask[partitionCount];
		
		for (int c=0;c<MAX_ITERATIONS;c++)
		{
			Map<String, Double> positions = null;
			logger.info("Calculating Net present value for "  + MAX_TRADES + " Trades ...");
			ExecutorBuilder executorBuilder = gigaspace.executorBuilder(new NPVResultsReducer());
	
			// Creating the Tasks. Each partition getting a Task with the exact Trade IDs to calculate
			for (int r=0;r<rates.length; r++)
			{
				long startTime = System.currentTimeMillis();
				for (int i=0;i<partitionCount ; i++)
				{
					Integer partIDs[] = new Integer[partitionIDSDistro.get(i).size()];
					partitionIDSDistro.get(i).toArray(partIDs);
					analysisTasks[i] = new AnalysisTask(partIDs,i,rates[r]);
					executorBuilder.add(analysisTasks[i]);
				}
				
				AsyncFuture<HashMap<String, Double>> future = executorBuilder.execute();
				
				if (future !=null)
				{
					try
					{
						positions = future.get();
						long endTime = System.currentTimeMillis();
						logger.info("\nTime to calculate Net present value for " +MAX_TRADES  + " Trades using " +rates[r] + " % rate:" + (endTime - startTime) + " ms");
						for(String key: positions.keySet()){
							logger.info("Book = " + key + ", NPV = " + formater.format(positions.get(key)));
						}
						Thread.sleep(1000);
					}
					catch (Exception e)
					{}
				}
			}
		}		
		admin.close();
	}
}

package org.openspaces.calcengine.executor;

import java.util.HashMap;

import org.openspaces.calcengine.common.CalculateNPVUtil;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.executor.Task;
import org.openspaces.core.executor.TaskGigaSpace;

import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.j_spaces.core.client.SpaceURL;

public class AnalysisTask implements Task<HashMap<String, Double>>{

	@TaskGigaSpace
	transient GigaSpace gigaspace;
	Integer[] tradeIds ;
	Integer routing;
	Double rate ;
	
	public AnalysisTask (Integer[] tradeIds,Integer routing, Double rate)
	{
		this.tradeIds = tradeIds;
		this.routing = routing;
		this.rate=rate;
	}
	
	
	public HashMap<String, Double> execute() throws Exception {
		int partitionID= Integer.valueOf(gigaspace.getSpace().getURL().getProperty(SpaceURL.CLUSTER_MEMBER_ID)).intValue() - 1;
		System.out.println("Time: " + System.currentTimeMillis()+  " Execute on Partition ID: " +partitionID+" Routing ID:"+ routing);
		return CalculateNPVUtil.execute(gigaspace ,gigaspace, tradeIds , partitionID , rate);
/*		
		HashMap<String, Double> rtnVal = new HashMap<String, Double>();

		List<Trade> tradesList = new ArrayList<Trade>();
		try {
			ReadByIdsResult<Trade> res = gigaspace.readByIds(Trade.class, tradeIds);
			
			// checking for null results and getting missing Trades objects from external Data source
			Trade resArr[] = res.getResultsArray();
			ArrayList<Integer> missingIDs = new ArrayList<Integer>();
			for (int i = 0; i < resArr.length; i++) {
				if (resArr [i] == null)
				{
					missingIDs.add(tradeIds[i]);
				}
			}
			Trade missingTrades[] = null;
			if (missingIDs.size() > 0)
			{
				System.out.println(">>>> Partition:"+ partitionID + " - Loading missing Trades from the database for IDs:"+missingIDs);
				missingTrades = CalculateNPVUtil.getTradesFromDB(missingIDs,gigaspace);
			}
			
			Iterator<Trade> iter = res.iterator();
			// ReadByIdsResult - Holds iterable results of the readByIds operation. 
			// When iterating through the results, null values are skipped. 
			// If you want to access null values, use the getResultsArray() method. 
			// Results are ordered based on the list of Ids provided to the readByIds method.
			while (iter.hasNext())
			{
				tradesList.add(iter.next());
			}
			
			if (missingTrades!=null)
			{
				for (int i = 0; i < missingTrades.length; i++) {
					tradesList.add(missingTrades[i]);
				}
			}
		} catch (Exception e){
			String a = e.getMessage();
			System.out.println(a);
			e.printStackTrace();
		}
		CalculateNPVUtil.runAnalysis(tradesList,rate);
		
		for(Trade t : tradesList){
			String key = t.getBook();
			if ( rtnVal.containsKey(key)){
				rtnVal.put(key, rtnVal.get(key)+t.getNPV());
			} else {
				rtnVal.put(key,t.getNPV());
			}
		}
		return rtnVal;
*/
	}
	

	@SpaceRouting
	public Integer getRouting() {
		return routing;
	}

	public void setRouting(Integer routing) {
		this.routing = routing;
	}

}
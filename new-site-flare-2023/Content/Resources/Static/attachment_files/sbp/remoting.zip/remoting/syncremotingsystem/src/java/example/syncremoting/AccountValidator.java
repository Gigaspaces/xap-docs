package example.syncremoting;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.adapter.SpaceDataEvent;
import example.syncremoting.common.*;

/**
 * <p>A simple bean that is run within a Spring context that acts
 * as the processing unit context as well (when executed within a
 * processing unit container).
 *
 * <p>Is handed SpaceDataEvents from a polling container.<br /> 
 * This removes the need to use space.take and space.write in the code.
 *
 * <p>The template for the polling container is defined in the pu.xml.
 */
public class AccountValidator {

    /**
     * This method is called any time the matching event is produced by the space.
     * 
     * <p>The OpenSpaces EventContainer will automagically call this method.
     *
     * @param obj The object that matches the prescribed template defined for this bean.    
     */
    @SpaceDataEvent
    public Object[] objProcessed(Account obj) {    	
        System.out.println(this.getClass().getSimpleName()+" Approving Account: "+obj);
        ApprovedAccountRecord aar = new ApprovedAccountRecord();
        aar.setAccountID(obj.getId());
        aar.setApprovalCode("201-"+System.currentTimeMillis()%10);
        aar.setId(obj.getId()+obj.getZipCode());
        aar.setIsApproved(new Boolean(true));
        obj.setIsProcessed(new Boolean(true));
        Object[] results = new Object[]{aar, obj};
      return results;
    }
    
    // constructor designed to prove we exist
    public AccountValidator(){
      System.out.println(this.getClass().getSimpleName()+" constructed...");
    }  
}
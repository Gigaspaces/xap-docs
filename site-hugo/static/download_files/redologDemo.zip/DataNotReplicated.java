package com.test;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;

@SpaceClass (replicate=false)
public class DataNotReplicated {
	
	public DataNotReplicated(){}
	
	String id;
	Boolean replicated;
	
	@SpaceId (autoGenerate=true)
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
}

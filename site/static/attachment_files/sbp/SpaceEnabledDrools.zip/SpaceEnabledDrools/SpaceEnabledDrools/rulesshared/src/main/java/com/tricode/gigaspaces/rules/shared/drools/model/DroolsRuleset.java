package com.tricode.gigaspaces.rules.shared.drools.model;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceExclude;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;
import com.tricode.gigaspaces.rules.shared.RulesetStatus;
import org.drools.definition.KnowledgePackage;

import java.io.Serializable;
import java.util.Collection;

/**
 * Drools ruleset object. Has sets of {@link DroolsDslDefinition} and {@link DroolsRule} objects.
 * <p/>
 * When rule is precompiled, knowledgePackages is filled.
 */
@SpaceClass(persist = false, replicate = false)
public class DroolsRuleset implements Serializable {

    private static final long serialVersionUID = -8808765296633680796L;

    private String id;

    /**
     * Name of the project.
     */
    private String projectName;

    /**
     * Name of the ruleset.
     */
    private String ruleSetName;

    /**
     * Precompiled version of ruleset.
     */
    private Collection<KnowledgePackage> knowledgePackages;

    /**
     * Status of this ruleset.
     */
    private RulesetStatus status;

    /**
     * Rule definitions (DSL's) included in this rule set.
     */
    private Collection<DroolsDslDefinition> definitions;

    /**
     * Rules included in this rule set.
     */
    private Collection<DroolsRule> rules;

    /**
     * Public no-arg constructor is required by GigaSpaces.
     */
    public DroolsRuleset() {
    }

    @SpaceId(autoGenerate = true)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @SpaceRouting
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getRuleSetName() {
        return ruleSetName;
    }

    public void setRuleSetName(String ruleSetName) {
        this.ruleSetName = ruleSetName;
    }

    public Collection<KnowledgePackage> getKnowledgePackages() {
        return knowledgePackages;
    }

    public void setKnowledgePackages(Collection<KnowledgePackage> knowledgePackages) {
        this.knowledgePackages = knowledgePackages;
    }

    public RulesetStatus getStatus() {
        return status;
    }

    public void setStatus(RulesetStatus status) {
        this.status = status;
    }

    @SpaceExclude
    public Collection<DroolsRule> getRules() {
        return rules;
    }

    public void setRules(Collection<DroolsRule> rules) {
        this.rules = rules;
    }

    @SpaceExclude
    public Collection<DroolsDslDefinition> getDefinitions() {
        return definitions;
    }

    public void setDefinitions(Collection<DroolsDslDefinition> definitions) {
        this.definitions = definitions;
    }

}
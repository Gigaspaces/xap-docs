package com.gigaspaces.cli;

import com.gigaspaces.cli.jcommander.OptionsParser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OptionsParserTest {
    private OptionsParser underTest = new OptionsParser();

    @Test
    public void testSingeHyphenOption() {
        String[] arguments = underTest.createArguments("-option");

        assertEquals(1, arguments.length);
        assertEquals("-option", arguments[0]);
    }

    @Test
    public void testDoubleHyphenOption() {
        String[] arguments = underTest.createArguments("--option");

        assertEquals(1, arguments.length);
        assertEquals("--option", arguments[0]);
    }

    @Test
    public void multipleWordArguments() {
        String[] arguments = underTest.createArguments("-option -option1");

        assertEquals(2, arguments.length);
        assertEquals("-option", arguments[0]);
        assertEquals("-option1", arguments[1]);
    }

    @Test
    public void multiplePhraseArguments(){
        String[] arguments = underTest.createArguments("\"a phrase\" \"a second phrase\"");

        assertEquals(2, arguments.length);
        assertEquals("a phrase", arguments[0]);
        assertEquals("a second phrase", arguments[1]);
    }

    @Test
    public void singlePhraseArgument() {
        String[] arguments = underTest.createArguments("\"a phrase\"");

        assertEquals(1, arguments.length);
        assertEquals("a phrase", arguments[0]);
    }

    @Test
    public void phraseWithSingleQuotes(){
        String[] arguments = underTest.createArguments("'a phrase'");

        assertEquals(1, arguments.length);
        assertEquals("a phrase", arguments[0]);
    }

    @Test
    public void phraseWithDoubleQuotes() {
        String[] arguments = underTest.createArguments("\"a phrase\"");

        assertEquals(1, arguments.length);
        assertEquals("a phrase", arguments[0]);
    }

    @Test
    public void phraseWithEscapedSingleQuote() {
        String[] arguments = underTest.createArguments("'a phr\\'ase'");

        assertEquals(1, arguments.length);
        assertEquals("a phr'ase", arguments[0]);
    }

    @Test
    public void phraseWithEscapedDoubleQuote(){
        String[] arguments = underTest.createArguments("\"a phr\\\"ase\"");

        assertEquals(1, arguments.length);
        assertEquals("a phr\"ase", arguments[0]);
    }

    @Test
    public void phraseWithDoubleQuotesSingleQuoteInside() {
        String[] arguments = underTest.createArguments("\"a phr'ase\"");

        assertEquals(1, arguments.length);
        assertEquals("a phr'ase", arguments[0]);
    }

    @Test
    public void phraseWithSingleQuotesDoubleQuoteInside() {
        String[] arguments = underTest.createArguments("'a phr\"ase'");

        assertEquals(1, arguments.length);
        assertEquals("a phr\"ase", arguments[0]);
    }

    @Test(expected = IllegalArgumentException.class)
    public void throwsWhenOptionsAreNull(){
        underTest.parse(new String[0], null);
    }
}

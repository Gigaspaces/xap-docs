﻿Ensure you have referenced Gigaspaces.Core.Dll correctly. The default installation path for XAP.NET will look something like the following:

C:\GigaSpaces\XAP.NET 9.7.0 x64\NET v4.0.30319\Bin
package com.test;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.cluster.IReplicationFilter;
import com.j_spaces.core.cluster.IReplicationFilterEntry;
import com.j_spaces.core.cluster.ReplicationPolicy;

public class MyReplicationFilter implements IReplicationFilter{

	@Override
	public void close() {
		System.out.println(this + " - MyReplicationFilter close");
		
	}

	@Override
	public void init(IJSpace space, String arg1, ReplicationPolicy replicationPolicy) {
		System.out.println(this + " - MyReplicationFilter init " + space + " - replicationPolicy :" + replicationPolicy);
		
	}

	@Override	
	public void process(int direction, IReplicationFilterEntry filterEntry, String remoteSpaceMemberName) {
		String filterDirectionStr = null;
        switch( direction ) 
    {
                      case IReplicationFilter.FILTER_DIRECTION_INPUT:  filterDirectionStr = "INPUT"; break;
                      case IReplicationFilter.FILTER_DIRECTION_OUTPUT: filterDirectionStr = "OUTPUT"; break;
              }
//        filterEntry.discard();
		System.out.println(this + " - process " + filterDirectionStr +  " " + filterEntry.getClassName() + " " + filterEntry.getOperationType().toString() + " " + remoteSpaceMemberName);
	}

}

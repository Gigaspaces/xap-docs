using System;

using GigaSpaces.Core;

namespace GigaSpaces.Examples.ExcelStocks.Feeder
{
	/// <summary>
	/// The GigaSpaces ExcelStocks Market Simulation (Feeder)
	/// </summary>
	static class Program
	{

		public static void Main(String[] args)
		{
			// Validate runtime arguments:
			if (args.Length < 1)
			{
				Utils.LogMessage("Usage: <URL>");
				Utils.LogMessage("<protocol>://host:port/containername/spacename");
				Environment.Exit(1);
			}

			// Get runtime arguments: URL
			string spaceUrl = args[0];

			// Connect to space:
			ISpaceProxy proxy = ConnectToSpace(spaceUrl);

			Utils.LogMessage("\nWelcome to GigaSpaces ExcelStocks Feeder Example.");

			DataFeeder dataFeeder = new DataFeeder(proxy);
			dataFeeder.Load();

			proxy.Dispose();
		}

		public static ISpaceProxy ConnectToSpace(string url)
		{
			try
			{
				Utils.LogMessage("\nConnect to " + url);
				ISpaceProxy space = SpaceProxyProviderFactory.Instance.FindSpace(url);
				Utils.LogMessage("Connected successfully ! ");
				return space;
			}
			catch (Exception ex)
			{
				Utils.LogMessage("Could not find space: " + url + Environment.NewLine + "Reason - " + ex.Message);
				Environment.Exit(1);
			}
			//Avoid compiler error
			return null;
		}
	}
}

package com.gigaspaces.domain;

import java.util.HashMap;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;

@SpaceClass
public class Watermark {

	private int id = 0;

	private HashMap<Long, String> evictionStatistics = null;

	private Boolean evictionActive = null;

	public Watermark() {
		id = 0;
	}

	@SpaceId(autoGenerate = false)
	public int getId() {
		return id;
	}

	public void setId(int id) {

	}

	public Boolean isEvictionActive() {
		return evictionActive;
	}

	public void setEvictionActive(Boolean evictionActive) {
		this.evictionActive = evictionActive;
	}

	public HashMap<Long, String> getEvictionStatistics() {
		return evictionStatistics;
	}

	public void setEvictionStatistics(HashMap<Long, String> evictionStatistics) {
		this.evictionStatistics = evictionStatistics;
	}

}

package com.tricode.gigaspaces.rules.shared;

/**
 * Constants class, used with Drools configuration.
 */
public final class RulesConstants {

    public static final String PROJECT_NAME = "spaceEnabledDrools";

    /**
     * Private constructor to prevent instantiating this class.
     */
    private RulesConstants() {
    }

}
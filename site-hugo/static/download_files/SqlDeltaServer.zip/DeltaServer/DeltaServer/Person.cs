﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GigaSpaces.Core.Metadata;

namespace DeltaServer
{
    [SpaceClass(Persist = true)]
    class Person
    {
        private int _id;
        private string _firstname;
        private string _lastname;
        private int _age;

        public Person(int id, string firstName, string lastName, int age)
        {
            _id = id;
            _firstname = firstName;
            _lastname = lastName;
            _age = age;
        }

        public Person()
        {

        }

        [SpaceID(AutoGenerate = false), SpaceRouting]
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        [SpaceIndex(Type = SpaceIndexType.Basic)]
        public string FirstName
        {
            get { return _firstname; }
            set { _firstname = value; }
        }

        [SpaceIndex(Type = SpaceIndexType.Basic)]
        public string LastName
        {
            get { return _lastname; }
            set { _lastname = value; }
        }

        [SpaceProperty(NullValue = 0), SpaceIndex(Type = SpaceIndexType.Extended)]
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}

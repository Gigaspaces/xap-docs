package com.gigaspaces.cli.model;

import com.gigaspaces.cli.exception.DelegatorException;
import com.gigaspaces.cli.exception.LookupException;
import com.gigaspaces.cli.exception.SinkException;
import org.openspaces.schema.core.gateway.Delegator;
import org.openspaces.schema.core.gateway.Lookups;
import org.openspaces.schema.core.gateway.Sink;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class WANGatewayModel {

    private final Lookups lookups = new Lookups();

    private Map<String, Delegator> delegators = new HashMap<>();

    private Map<String, Sink> sinks = new HashMap<>();

    public void addLookup(Lookups.Lookup lookup){
        String gatewayName = lookup.getGatewayName();
        for (Lookups.Lookup existingLookup : lookups.getLookup()){
            if (existingLookup.getGatewayName().equals(gatewayName)){
                throw new LookupException("Gateway lookup with the same name already exists");
            }
            if (lookupsAreEqual(existingLookup, lookup)){
                throw new LookupException("Gateway lookup with the same configuration already exists");
            }
        }
        lookups.getLookup().add(lookup);
    }

    public void modifyLookup(Lookups.Lookup lookup){
        String gatewayName = lookup.getGatewayName();
        removeLookup(gatewayName);
        lookups.getLookup().add(lookup);
    }

    public void removeLookup(String gatewayName){
        Iterator<Lookups.Lookup> iterator = lookups.getLookup().iterator();
        while (iterator.hasNext()){
            Lookups.Lookup existingLookup = iterator.next();
            if (existingLookup.getGatewayName().equals(gatewayName)){
                iterator.remove();
                return;
            }
        }
        throw new LookupException("Gateway lookup with this name doesn't exist");
    }

    public void addDelegator(Delegator inputDelegator) {
        delegators.put(inputDelegator.getId(), inputDelegator);
    }

    public void addDelegation(String delegatorId, Delegator.Delegations.Delegation delegation) {
        checkDelegatorInitialized(delegatorId);
        Delegator delegator = delegators.get(delegatorId);
        delegator.getDelegations().getDelegation().add(delegation);
    }


    public void removeDelegator(String delegatorId) {
        delegators.remove(delegatorId);
    }

    public void removeDelegation(String delegatorId, Delegator.Delegations.Delegation delegation) {
        checkDelegatorInitialized(delegatorId);
        Delegator delegator = delegators.get(delegatorId);
        Iterator<Delegator.Delegations.Delegation> iterator = delegator.getDelegations().getDelegation().iterator();
        while (iterator.hasNext()){
            Delegator.Delegations.Delegation existingDelegation = iterator.next();
            if (delegationsAreEqual(existingDelegation, delegation)){
                iterator.remove();
                return;
            }
        }
        throw new DelegatorException("Delegation doesn't exist");
    }

    public void addSink(Sink sink) {
        sinks.put(sink.getId(), sink);
    }

    public void addSource(String sinkId, Sink.Sources.Source source) {
        checkSinkInitialized(sinkId);
        Sink sink = sinks.get(sinkId);
        sink.getSources().getSource().add(source);
    }

    public void removeSink(String sinkId) {
        sinks.remove(sinkId);
    }

    public void removeSource(String sinkId, Sink.Sources.Source source) {
        checkSinkInitialized(sinkId);
        Sink sink = sinks.get(sinkId);
        Iterator<Sink.Sources.Source> iterator = sink.getSources().getSource().iterator();
        while (iterator.hasNext()){
            Sink.Sources.Source exisitingSource = iterator.next();
            if (sourcesAreEqual(exisitingSource, source)){
                iterator.remove();
                return;
            }
        }
        throw new SinkException("Source doesn't exist");
    }

    private void checkDelegatorInitialized(String delegatorId) {
        Delegator delegator = delegators.get(delegatorId);
        if (delegator == null){
            throw new DelegatorException("Delegator is not initialized");
        }
    }

    private void checkSinkInitialized(String sinkId) {
        Sink sink = sinks.get(sinkId);
        if (sink == null){
            throw new DelegatorException("Sink is not initialized");
        }
    }

    private boolean delegationsAreEqual(Delegator.Delegations.Delegation existingDelegation, Delegator.Delegations.Delegation delegation) {
        return existingDelegation.getTarget().equals(delegation.getTarget());
    }

    private boolean sourcesAreEqual(Sink.Sources.Source exisitingSource, Sink.Sources.Source source) {
        return exisitingSource.getName().equals(source.getName());
    }

    private boolean lookupsAreEqual(Lookups.Lookup existingLookup, Lookups.Lookup lookup) {
        return false;
//        return  existingLookup.getDiscoveryPort().equals(lookup.getDiscoveryPort()) &&
//                existingLookup.getHost().equals(lookup.getHost()) &&
//                existingLookup.getCommunicationPort().equals(lookup.getCommunicationPort());
    }

    public Lookups getLookups() {
        return lookups;
    }

    public Map<String, Delegator> getDelegators() {
        return delegators;
    }

    public Map<String, Sink> getSinks() {
        return sinks;
    }
}

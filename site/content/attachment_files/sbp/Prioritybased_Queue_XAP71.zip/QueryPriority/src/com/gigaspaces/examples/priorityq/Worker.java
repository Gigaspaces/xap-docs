package com.gigaspaces.examples.priorityq;

import java.util.concurrent.atomic.AtomicInteger;

import org.openspaces.core.GigaSpace;
import com.j_spaces.core.client.SQLQuery;

class Worker extends Thread {
	GigaSpace space;
	static AtomicInteger lastWorker   = new AtomicInteger(0);
	int priorityMin;

	int priorityMax;
	int sleepTime = 2000;
	int qMaxSize = 10;

	Worker(GigaSpace space, int priorityMin, int priorityMax) {
		super();
		setName("Worker " + lastWorker.getAndIncrement());
		this.space = space;
		this.priorityMin = priorityMin;
		this.priorityMax = priorityMax + 1;
	}

	public void run() {
//		String queryStr = "priority>" + (priorityMin) + " and priority<"+ priorityMax;
		String queryStr = "priority>0" ;

		SQLQuery query = new SQLQuery(Order.class.getName(), queryStr);
		System.out.println(Thread.currentThread().getName() + " Started Query:" + queryStr);
		try {
			Object template = space.snapshot(query);
			while (true) {
				// Query specific entries - we use the snapshot to support SQLQuery with blocking take
				Object result = space.take (template ,100000);
				if (result != null) {
					System.out.println(Thread.currentThread().getName() + " "  + queryStr+ " :Processing Order:" + result);
				}
				else
				{
					System.out.println(Thread.currentThread().getName() + " "  + queryStr
							+ " :No Order found!" );
				}

				// check if we need to change the sleep time
				int q_size = space.count(new Order());

				if (q_size > qMaxSize) {
					sleepTime = sleepTime - 500;
					if (sleepTime < 0) {
						sleepTime = 100;
					}
				} else {
					sleepTime = 2000;
				}
				//System.out.println("Changed worker worktime to:" + sleepTime+ "ms");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

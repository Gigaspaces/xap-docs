package com.test.eds;

import java.io.Serializable;

public class QuerySubResult implements Serializable{
	
	public QuerySubResult (MyData[] resultSet ,int 	partitionID )
	{
		this.resultSet=resultSet ;
		this.partitionID=partitionID;
	}
	
	public QuerySubResult (int resultSetSize ,int 	partitionID )
	{
		this.resultSetSize=resultSetSize ;
		this.partitionID =partitionID ;
	}

	MyData[] resultSet;
	int partitionID;
	int resultSetSize;
	
	public MyData[] getResultSet() {
		return resultSet;
	}

	public int getPartitionID() {
		return partitionID;
	}

	public int getResultSetSize() {
		if (resultSet!=null) 
			return resultSet.length;
		else
			return resultSetSize;
	}
}

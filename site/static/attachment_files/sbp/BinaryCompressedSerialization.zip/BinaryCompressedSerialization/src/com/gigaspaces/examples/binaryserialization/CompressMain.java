package com.gigaspaces.examples.binaryserialization;

import com.gigaspaces.async.AsyncFuture;
import com.j_spaces.core.client.FinderException;
import net.jini.core.entry.UnusableEntryException;
import net.jini.core.lease.Lease;
import net.jini.core.transaction.TransactionException;
import org.apache.commons.math.random.RandomDataImpl;
import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import java.util.List;
import java.util.ArrayList;

public class CompressMain {

    private GigaSpace _gigaspace;
    private RandomDataImpl _randomData; 
    Progress progress = new Progress();
    
    public static void main(String[] args) {
        try{
            CompressMain cm = new CompressMain(args[0]);

            Integer dec = new Integer(args[1]);
            if(dec == null){
                System.exit(1);
            }
            switch (dec){
                case 0:
                    cm.testFunctionality();
                    break;
                case 1:
                    cm.testSimpleEntry();
                    break;
                case 2:
                    cm.testBinaryFormatEntry();
                    break;
                default:
                    System.exit(1);
            }
            System.exit(0);
        }catch(FinderException e){
            e.printStackTrace();
            System.exit(1);
        }catch(Exception ee){
            ee.printStackTrace();
            System.exit(1);
        }
    }


    public CompressMain(String url) throws Exception {
        _gigaspace = new GigaSpaceConfigurer(new UrlSpaceConfigurer(url)).gigaSpace();
        _randomData = new RandomDataImpl();
    }

    private void testFunctionality() throws Exception{
        SimpleEntry testSE = generateSimpleEntry(500);
        _gigaspace.write(testSE, Lease.FOREVER);
        SimpleEntry templateSE = new SimpleEntry();
        templateSE._queryField = new Long(500);
        SimpleEntry resSE = (SimpleEntry)_gigaspace.read(templateSE, 0);
       // System.out.println("\nSimpleEntry\n-----------\nFieldA:"+resSE._stringFieldA + 
       // 		"\nFieldB:"+resSE._stringFieldB +
       //				"\nFieldC:"+resSE._stringFieldC);

        BinaryFormatEntry testBFE = generateBinaryFormatEntry(500);
        _gigaspace.write(testBFE, Lease.FOREVER);
        BinaryFormatEntry templateBFE = new BinaryFormatEntry();
        templateBFE._queryField = new Long(500);
        BinaryFormatEntry resBFE = (BinaryFormatEntry)_gigaspace.read(templateBFE, 0);
        resBFE.unpack();
       // System.out.println("\nBinaryFormatEntry\n-----------\nFieldA:"+resBFE.getStringFieldA() + 
        //		"\nFieldB:"+resBFE.getStringFieldB() +
	//			"\nFieldC:"+resBFE.getStringFieldC());
    }

    private void testSimpleEntry() throws TransactionException, java.rmi.RemoteException,
            UnusableEntryException, InterruptedException , Exception{
        long  timeBefore = 0, timeAfter = 0;
        double avgWriteMultiple = 0, avgWrite = 0, avgRead = 0, avgReadMultiple = 0, avgTake = 0, avgTakeMultiple = 0,
                counter = 0;

        System.out.println("About to start testing Memory footprint and throughput for SimpleEntry " +
        "\nThis may take few minutes");
        _gigaspace.clear(null);
        long memoryBefore = memCheck();

        avgWriteMultiple = 250/(writeMultipleTest(1 , progress)/1000);
        long memoryAfter = memCheck();
        System.out.println("\nwrite test...");
        for(int i = 1 ; i < 10001 ; i++){
            SimpleEntry wse = generateSimpleEntry(i + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.write(wse, Lease.FOREVER);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            
            if (i % 100 ==0)
            	progress.next();
        }
        avgWrite = 10000/(counter/1000);
        counter = 0;
        System.out.println("\nreadMultiple test...");

        for(int j = 1 ; j < 251 ; j++){
            SimpleEntry readMultipleTemplate = new SimpleEntry();
            readMultipleTemplate._queryField = new Long(j);

            timeBefore = System.currentTimeMillis();
            Object res[] = _gigaspace.readMultiple(readMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length ==0) throw new RuntimeException("readMultiple rturn empty result");
            if (j % 100 ==0)
            	progress.next();
            
        }
        avgReadMultiple = 250/(counter/1000);
        counter = 0;
        System.out.println("\nread test...");

        for(int k = 1 ; k < 10001 ; k++){
            SimpleEntry readTemplate = new SimpleEntry();
            readTemplate._queryField = new Long(k + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.read(readTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);

            if (k % 100 ==0)
            	progress.next();
            
        }
        avgRead = 10000/(counter/1000);
        counter = 0;
        
/*        
        System.out.println("\ntake test...");

        for(int h = 1 ; h < 10001 ; h++){
            SimpleEntry takeTemplate = new SimpleEntry();
            takeTemplate._queryField = new Long(h + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.take(takeTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (h % 100 ==0)
            	progress.next();
            
        }
        avgTake = 10000/(counter/1000);
        counter = 0;
        System.out.println("\ntakeMultiple test...");

        for(int g = 1 ; g < 251 ; g++){
            SimpleEntry takeMultipleTemplate = new SimpleEntry();
            takeMultipleTemplate._queryField = new Long(g);
            timeBefore = System.currentTimeMillis();
            Object res[]= _gigaspace.takeMultiple(takeMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length ==0) throw new RuntimeException("takeMultiple rturn empty result");
        }
        avgTakeMultiple = 250/(counter/1000);
*/

        printResult("SimpleEntry", memoryAfter , memoryBefore , avgWrite , avgRead , avgTake, avgWriteMultiple , avgReadMultiple , avgTakeMultiple);

    }

    static public void printResult(String entryType, long  memoryAfter , long memoryBefore , double avgWrite , double avgRead , double avgTake, double avgWriteMultiple , double avgReadMultiple , double avgTakeMultiple)
    {
        System.out.println("\nThe results for :" + entryType);
        System.out.println("Average " + entryType + " size = " + (memoryAfter - memoryBefore)/250000);
        System.out.println(entryType + " - Average writeMultiple (1000 entries batch) TP = "+ (int)(avgWriteMultiple*1000) +" oper/sec");
        System.out.println(entryType + " - Average write TP = " + (int)avgWrite+" oper/sec");
        System.out.println(entryType + " - Average readMultiple  (1000 entries batch) TP = "+ (int)(avgReadMultiple * 1000)+" oper/sec");
        System.out.println(entryType+ " - Average read TP = " + (int)avgRead +" oper/sec");
//        System.out.println(entryType+ " - Average takeMultiple (1000 entries batch) TP = "  + (int)(avgTakeMultiple*1000)+" oper/sec");
//        System.out.println(entryType + " - Average take TP = " + (int)avgTake+" oper/sec");
    }


    private void testBinaryFormatEntry() throws TransactionException, java.rmi.RemoteException,
        UnusableEntryException, InterruptedException , Exception{
        long timeBefore = 0, timeAfter = 0;
        double avgWriteMultiple = 0, avgWrite = 0,
                avgRead = 0, avgReadMultiple = 0, avgTake = 0, avgTakeMultiple = 0,
                counter = 0;

        System.out.println("About to start testing Memory footprint and throughput for BinaryFormatEntry " +
        "\nThis may take few minutes");
        _gigaspace.clear(null);

        long memoryBefore = memCheck();
        avgWriteMultiple = 250/(writeMultipleTest(3,progress)/1000);
        long memoryAfter = memCheck();
        System.out.println("\nwrite test...");

        for(int i = 1 ; i < 10001 ; i++){
            BinaryFormatEntry writeTemplate = generateBinaryFormatEntry(i + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.write(writeTemplate, Lease.FOREVER);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (i % 100 ==0)
                progress.next();
            
        }
        avgWrite = 10000/(counter/1000);
        counter = 0;
        System.out.println("\nreadMultiple test...");

        for(int j = 1 ; j < 251 ; j++){
            BinaryFormatEntry readMultipleTemplate = new BinaryFormatEntry();
            readMultipleTemplate._queryField = new Long(j);
            timeBefore = System.currentTimeMillis();
            Object res[] = _gigaspace.readMultiple(readMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length ==0) throw new RuntimeException("readMultiple rturn emptry result");
        }
        avgReadMultiple = 250/(counter/1000);
        counter = 0;
        System.out.println("\nread test...");

        for(int k = 1 ; k < 10001 ; k++){
            BinaryFormatEntry readTemplate = new BinaryFormatEntry();
            readTemplate._queryField = new Long(k + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.read(readTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (k % 100 ==0)
            	progress.next();
        }
        avgRead = 10000/(counter/1000);
        
/*        
        counter = 0;

        System.out.println("\ntake test...");
        for(int h = 1 ; h < 10001 ; h++){
            BinaryFormatEntry takeTemplate = new BinaryFormatEntry();
            takeTemplate._queryField = new Long(h + 1000);
            timeBefore = System.currentTimeMillis();
            _gigaspace.take(takeTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (h % 100 ==0)
            	progress.next();
        }
        avgTake = 10000/(counter/1000);
        counter = 0;
        System.out.println("\ntakeMultiple test...");

        for(int g = 1 ; g < 251 ; g++){
            BinaryFormatEntry takeMultipleTemplate = new BinaryFormatEntry();
            takeMultipleTemplate._queryField = new Long(g);
            timeBefore = System.currentTimeMillis();
            Object res[] = _gigaspace.takeMultiple(takeMultipleTemplate, 1000);
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
            if (res.length ==0) throw new RuntimeException("takeMultiple rturn emptry result");
        }
        avgTakeMultiple = 250/(counter/1000);
*/
        printResult("BinaryFormatEntry", memoryAfter , memoryBefore , avgWrite , avgRead , avgTake, avgWriteMultiple , avgReadMultiple , avgTakeMultiple);

    }
    private long memCheck() throws Exception{
    	System.out.println("\nChecking space memory...");
        progress.startAutoProgress();
        MemCheckTask mct = new MemCheckTask();
        AsyncFuture result = _gigaspace.execute(mct);
        Long res = (Long)result.get();
        progress.stopAutoProgress();
    	System.out.println("\nEnd Checking space memory");
        return res.longValue();
    }
    

    private double writeMultipleTest(int type , Progress prog) throws TransactionException, java.rmi.RemoteException{
    	long timeBefore = 0, timeAfter = 0;
        double counter = 0;
        System.out.println("writeMultiple test...");
        for(int i = 1 ; i < 251 ; i++){
            Object[] writeMArr = getWriteList(type, i);
            timeBefore = System.currentTimeMillis();
            _gigaspace.writeMultiple(writeMArr, Lease.FOREVER);
            prog.next();
            timeAfter = System.currentTimeMillis();
            counter += (timeAfter - timeBefore);
        }

        return counter;
    }


    private int getRandomNumber(int base, int max) {
        return _randomData.nextSecureInt(base, max);
    }

    private Object[] getWriteList(int type, int id){

        Object[] retArr = null;
        switch(type){
            case 1:
                retArr = generateSimpleEntryList(id);
                break;
            case 3:
                retArr = generateBinaryFormatEntryList(id);
                break;
            default:
                break;
        }
        return retArr;
    }

    private SimpleEntry[] generateSimpleEntryList(int id){
        List<SimpleEntry> simpleEntryList = new ArrayList<SimpleEntry>();
        for(int j = 0 ; j < 1000 ; j++){
            SimpleEntry se = generateSimpleEntry(id);
            simpleEntryList.add(se);
        }

        return simpleEntryList.toArray(new SimpleEntry[simpleEntryList.size()]);
    }

    private SimpleEntry generateSimpleEntry(int id){
        return new SimpleEntry(id, 
        	getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    getRandomNumber(1, 1000),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)),
		    String.valueOf(getRandomNumber(1, 1000)));
    }


    private BinaryFormatEntry[] generateBinaryFormatEntryList(int id){
        List<BinaryFormatEntry> binaryFormatEntryList = new ArrayList<BinaryFormatEntry>();
        for(int j = 0 ; j < 1000 ; j++){
            BinaryFormatEntry bfe = generateBinaryFormatEntry(id);
            binaryFormatEntryList.add(bfe);
        }

        return binaryFormatEntryList.toArray(new BinaryFormatEntry[binaryFormatEntryList.size()]);
    }

    private BinaryFormatEntry generateBinaryFormatEntry(int id){
        BinaryFormatEntry bfe = new BinaryFormatEntry(id, 
        			getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    getRandomNumber(1, 1000),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    String.valueOf(getRandomNumber(1, 1000)),
                    getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					getRandomNumber(1, 1000),
					String.valueOf(getRandomNumber(1, 1000)),
					String.valueOf(getRandomNumber(1, 1000)),
					String.valueOf(getRandomNumber(1, 1000)),
					String.valueOf(getRandomNumber(1, 1000)));

        bfe.pack();
        return bfe;
    }
}

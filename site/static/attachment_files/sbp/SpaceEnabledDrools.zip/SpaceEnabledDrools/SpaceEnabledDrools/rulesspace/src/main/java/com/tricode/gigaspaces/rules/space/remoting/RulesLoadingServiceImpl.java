package com.tricode.gigaspaces.rules.space.remoting;

import java.util.Collection;

import com.tricode.gigaspaces.rules.shared.drools.model.DroolsContext;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsDslDefinition;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRule;
import com.tricode.gigaspaces.rules.shared.drools.model.DroolsRuleset;
import com.tricode.gigaspaces.rules.shared.remoting.IRulesLoadingService;
import org.apache.log4j.Logger;
import org.openspaces.core.GigaSpace;
import org.openspaces.remoting.RemotingService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * GigaSpaces remoting service for loading/unloading Drools 5 business rules.
 */
@RemotingService
public class RulesLoadingServiceImpl implements IRulesLoadingService {

    private final Logger log = Logger.getLogger(RulesLoadingServiceImpl.class);

    @Autowired
    private GigaSpace gigaSpace;

    /**
     * {@inheritDoc}
     */
    public void loadRuleset(DroolsRuleset ruleset) {
        try {
            Collection<DroolsDslDefinition> definitions = ruleset.getDefinitions();
            Collection<DroolsRule> rules = ruleset.getRules();

            gigaSpace.write(ruleset);

            // now that we have the ruleSetId we can write the linked objects

            if (!definitions.isEmpty()) {
                for (DroolsDslDefinition definition : definitions) {
                    definition.setRuleSetId(ruleset.getId());
                }

                gigaSpace.writeMultiple(definitions.toArray(new DroolsDslDefinition[definitions.size()]));
            }

            if (!rules.isEmpty()) {
                for (DroolsRule rule : rules) {
                    rule.setRuleSetId(ruleset.getId());
                }

                gigaSpace.writeMultiple(rules.toArray(new DroolsRule[rules.size()]));
            }
        } catch (Exception e) {
            log.error("Exception loading ruleset", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void unloadRuleset(DroolsRuleset ruleset) {
        try {
            DroolsRuleset rulesetToUnload = new DroolsRuleset();
            rulesetToUnload.setProjectName(ruleset.getProjectName());
            rulesetToUnload.setRuleSetName(ruleset.getRuleSetName());
            DroolsRuleset[] ruleSets = gigaSpace.takeMultiple(rulesetToUnload, Integer.MAX_VALUE);

            // remove associated objects
            for (DroolsRuleset ruleSet : ruleSets) {
                final DroolsDslDefinition definitionTemplate = new DroolsDslDefinition();
                definitionTemplate.setRuleSetId(ruleSet.getId());
                gigaSpace.takeMultiple(definitionTemplate, Integer.MAX_VALUE);

                final DroolsRule ruleTemplate = new DroolsRule();
                ruleTemplate.setRuleSetId(ruleSet.getId());
                gigaSpace.takeMultiple(ruleTemplate, Integer.MAX_VALUE);
            }

            // also remove contexts
            DroolsContext context = new DroolsContext();
            context.setProjectName(ruleset.getProjectName());
            context.setRulesetNames(ruleset.getRuleSetName() + ",");    // concatenation adds ',' after each name so add it here too
            gigaSpace.takeMultiple(context, Integer.MAX_VALUE);
        } catch (Exception e) {
            log.error("Exception unloading ruleset", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void unloadAllRulesets() {
        gigaSpace.takeMultiple(new DroolsRuleset(), Integer.MAX_VALUE);
        gigaSpace.takeMultiple(new DroolsDslDefinition(), Integer.MAX_VALUE);
        gigaSpace.takeMultiple(new DroolsRule(), Integer.MAX_VALUE);
        gigaSpace.takeMultiple(new DroolsContext(), Integer.MAX_VALUE);
    }

}
package com.eauction.gigaspaces.loadbalancer.apache;

import org.openspaces.core.cluster.ClusterInfo;

import org.openspaces.pu.container.jee.JeeServiceDetails;


/**
 * Node level information for the load balancer.
 *
 * @author kimchy
 */
public class LoadBalancerNodeInfo {
    private String uid;
    private ClusterInfo clusterInfo;
    private JeeServiceDetails serviceDetails;

    public LoadBalancerNodeInfo(String uid, ClusterInfo clusterInfo,
        JeeServiceDetails serviceDetails) {
        this.uid = uid;
        this.clusterInfo = clusterInfo;
        this.serviceDetails = serviceDetails;
    }

    public String getUid() {
        return uid;
    }

    /**
     * Returns the cluster specific information fo the load balancer node (the web application processing
     * unit instance).
     */
    public ClusterInfo getClusterInfo() {
        return clusterInfo;
    }

    /**
     * Returns jee related information for the given load balancer node (for example, host, port, and context path).
     */
    public JeeServiceDetails getServiceDetails() {
        return serviceDetails;
    }
}

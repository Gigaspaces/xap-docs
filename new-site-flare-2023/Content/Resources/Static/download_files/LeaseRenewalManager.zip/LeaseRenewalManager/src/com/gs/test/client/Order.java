package com.gs.test.client;

import java.io.Serializable;

import com.gigaspaces.annotation.pojo.SpaceId;

public class Order implements Serializable {

	private String id;
	private Boolean processed;
	private String data;

	@SpaceId(autoGenerate=true)
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String d) {
		this.data = d;
	}

	public Boolean getProcessed() {
		return processed;
	}

	public void setProcessed(Boolean processed) {
		this.processed = processed;
	}


}

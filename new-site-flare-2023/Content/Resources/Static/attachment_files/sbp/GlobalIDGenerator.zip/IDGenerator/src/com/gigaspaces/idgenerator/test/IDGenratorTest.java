package com.gigaspaces.idgenerator.test;

import com.gigaspaces.idgenerator.SpaceBasedIdGenerator;

public class IDGenratorTest
{

    SpaceBasedIdGenerator idGenerator;

	public void go() throws Exception {
		for (int i=0;i<100000;i++)
		{
			Integer ID = idGenerator.generateId();
			System.out.println("ID:" + ID);
		}
	}

	public SpaceBasedIdGenerator getIdGenerator() {
		return idGenerator;
	}

	public void setIdGenerator(SpaceBasedIdGenerator idGenerator) {
		this.idGenerator = idGenerator;
	}
}

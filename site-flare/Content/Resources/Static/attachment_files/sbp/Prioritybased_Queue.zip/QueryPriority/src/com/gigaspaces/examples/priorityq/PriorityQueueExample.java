package com.gigaspaces.examples.priorityq;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.SpaceFinder;

public class PriorityQueueExample {
	public static void main(String[] args) {
		System.out.println("Welcome to GigaSpaces Priority Based Queue Example" );
		GigaSpace space = null;
		
		try {
			space = new GigaSpaceConfigurer (new UrlSpaceConfigurer(args[0])).gigaSpace();
			if (space == null) {
				System.out.println("can't connect to space" + args[0]);
				System.out.println("exit!");
			}
			
			System.out.println("Connect to space:" + args[0] + " OK!");
			space.clean();
			space.snapshot(new Order());
			
			int masterCount = 1;
			int workersCount = 1;
			Worker workers[] = new Worker [workersCount ];
			Master masters[] = new Master[masterCount  ];
			
			Monitor monitor= new Monitor (space);
			monitor.start();

			for (int i=0;i<masterCount ;i++)
			{
				masters[i]= new Master(space);
				masters[i].start();
			}

			Thread.sleep(1000);

			for (int i=0;i<masterCount ;i++)
			{
				masters[i].stop();
			}

			for (int i=0;i<workersCount ;i++)
			{
				workers[i]= new Worker(space , i *workersCount  , (i*workersCount ) + workersCount );
				workers[i].start();
			}

			while(true)
			{
				Thread.sleep(100000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

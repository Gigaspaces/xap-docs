export XAP_NIC_ADDRESS=127.0.0.1
export GS_HOME=/home/gigaspaces-xap-enterprise-12.0.1-ga-b16600



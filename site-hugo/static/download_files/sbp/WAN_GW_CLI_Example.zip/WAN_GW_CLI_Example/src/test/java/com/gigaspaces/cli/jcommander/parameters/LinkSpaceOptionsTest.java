package com.gigaspaces.cli.jcommander.parameters;

import com.gigaspaces.cli.jcommander.OptionsParser;
import com.j_spaces.core.cluster.RedoLogCapacityExceededPolicy;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by skyler on 5/27/2015.
 */
public class LinkSpaceOptionsTest {
    @Test(expected = IllegalArgumentException.class)
    public void exceptionThrownWhenRemoveAndAddProvided() {
        internalTestWrapper("-a -r -n site-1", new LinkSpaceOptions());
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionThrownWhenNameMissingOnRemove() {
        internalTestWrapper("-r", new LinkSpaceOptions());
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionThrownWhenNameMissingOnAdd() {
       internalTestWrapper("-a -b 100 -i 200 -m 300", new LinkSpaceOptions());
    }

    @Test(expected = IllegalArgumentException.class)
    public void exceptionThrownWhenSpaceNameIsMissing() {
        internalTestWrapper("-a -n site-1 -b 100 -i 200 -m 300", new LinkSpaceOptions());
    }

    @Test
    public void happyPathRemove() {
        LinkSpaceOptions underTest = new LinkSpaceOptions();
        internalTestWrapper("-r -s mySpace -n site-1", underTest);

        assertTrue(underTest.isRemove());
        assertEquals("site-1", underTest.getName());
    }

    @Test
    public void happyPathAdd() {
        LinkSpaceOptions underTest = new LinkSpaceOptions();
        internalTestWrapper("-a -s mySpace -n site-1 -b 100 -i 200 -m 300", underTest);

        assertEquals("site-1", underTest.getName());
        assertEquals(100, underTest.getBulkSize());
        assertEquals(200, underTest.getIdleTimeThreshold());
        assertEquals(300, underTest.getMaxRedoLogCapacity());
    }

    @Test
    public void canParseEnumValues() {
        LinkSpaceOptions underTest = new LinkSpaceOptions();
        internalTestWrapper("-a -s mySpace -n SITE-1 -b 100 -i 200 -m 300 -o DROP_OLDEST", underTest);

        assertEquals(RedoLogCapacityExceededPolicy.DROP_OLDEST, underTest.getOnRedoCapcityExceeded());
    }

    private void internalTestWrapper(String command, LinkSpaceOptions options){
        OptionsParser optionsParser = new OptionsParser();
        optionsParser.parse(command.split(" "), options);
    }
}

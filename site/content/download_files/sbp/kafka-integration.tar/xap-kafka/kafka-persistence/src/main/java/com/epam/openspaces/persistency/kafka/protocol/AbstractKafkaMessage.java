package com.epam.openspaces.persistency.kafka.protocol;

/**
 * Message of XAP-Kafka protocol.
 *
 * @author Oleksiy_Dyagilev
 */
public interface AbstractKafkaMessage {
}

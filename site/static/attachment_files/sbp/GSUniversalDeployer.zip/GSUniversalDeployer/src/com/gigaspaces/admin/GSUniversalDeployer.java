package com.gigaspaces.admin;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.esm.ElasticServiceManager;
import org.openspaces.admin.esm.events.ElasticServiceManagerLifecycleEventListener;
import org.openspaces.admin.gsc.GridServiceContainer;
import org.openspaces.admin.gsc.events.GridServiceContainerLifecycleEventListener;
import org.openspaces.admin.gsm.GridServiceManager;
import org.openspaces.admin.internal.pu.elastic.AbstractElasticProcessingUnitDeployment;
import org.openspaces.admin.pu.DeploymentStatus;
import org.openspaces.admin.pu.ProcessingUnit;
import org.openspaces.admin.pu.ProcessingUnitDeployment;
import org.openspaces.admin.pu.ProcessingUnitInstance;
import org.openspaces.admin.pu.ProcessingUnits;
import org.openspaces.admin.pu.elastic.ElasticStatefulProcessingUnitDeployment;
import org.openspaces.admin.pu.elastic.config.EagerScaleConfigurer;
import org.openspaces.admin.pu.elastic.config.ManualCapacityScaleConfigurer;
import org.openspaces.admin.pu.elastic.topology.ElasticStatefulDeploymentTopology;
import org.openspaces.admin.pu.events.ProcessingUnitInstanceLifecycleEventListener;
import org.openspaces.admin.space.ElasticSpaceDeployment;
import org.openspaces.admin.space.SpaceDeployment;
import org.openspaces.pu.container.support.CommandLineParser;

import com.gigaspaces.events.AdminEvent;
import com.gigaspaces.events.AdminEventListener;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;

public class GSUniversalDeployer implements
		ElasticServiceManagerLifecycleEventListener,
		ProcessingUnitInstanceLifecycleEventListener,
		GridServiceContainerLifecycleEventListener {

	public GSUniversalDeployer() {
	}

	private static Logger logger = Logger.getLogger(GSUniversalDeployer.class
			.getSimpleName());

	static List<String> puListToDeploy = new ArrayList<String>();
	static Map<String, List<String>> puDependencyMap = new HashMap<String, List<String>>();
	static Map<String, Properties> pusDeployProperties = new HashMap<String, Properties>();
	static List<ProcessingUnit> deployedPUs = new ArrayList<ProcessingUnit>();

	static String locators = null;
	static String groups = null;

	final static String PU_SEPERATOR = ",";
	final static String PU_START_LIST = "[";
	final static String PU_END_LIST = "]";
	final static String DEPLOY_OPTION_SEPERATOR = " -";

	static Admin admin = null;
	static GridServiceManager gsm = null;
	static ElasticServiceManager elasticServiceManager = null;

	static boolean abortDeployOnFailure = false;
	static boolean deploy = true;

	public static void main(String[] args) throws Exception {
		if (args.length == 0) {
			printUsage();
			System.exit(0);
		}
		String deployDependencyFile = null;
		CommandLineParser.Parameter[] params = CommandLineParser.parse(args);

		for (CommandLineParser.Parameter param : params) {
			if (param.getName().equalsIgnoreCase("config")) {
				if (param.getArguments().length == 0) {
					printUsage();
					System.exit(0);
				}
				deployDependencyFile = param.getArguments()[0];
			}

			if (param.getName().equalsIgnoreCase("locators")) {
				if (param.getArguments().length == 0) {
					printUsage();
					System.exit(0);
				}
				locators = param.getArguments()[0];
			}

			if (param.getName().equalsIgnoreCase("groups")) {
				if (param.getArguments().length == 0) {
					printUsage();
					System.exit(0);
				}
				groups = param.getArguments()[0];
			}

			if (param.getName().equalsIgnoreCase("command")) {
				if (param.getArguments().length == 0) {
					printUsage();
					System.exit(0);
				}
				String cmd = param.getArguments()[0];
				if (cmd.equals("deploy"))
					deploy = true;
				if (cmd.equals("undeploy"))
					deploy = false;
			}

			if (param.getName().equalsIgnoreCase("abortDeployOnFailure")) {
				abortDeployOnFailure = Boolean.valueOf(param.getArguments()[0])
						.booleanValue();
			}
		}

		if ((deployDependencyFile == null)
				|| (deployDependencyFile.length() == 0)) {
			logger.info("No Deploy file configuration is specified. Please add -config file_location argument!");
			printUsage();
			System.exit(0);
		}

		if ((locators == null) && (groups == null)) {
			if ((locators == null) || (locators.length() == 0))
				logger.info("No lookup service locators is specified. Please add -locators LOOKKUPLOCATORS argument!");

			if ((groups == null) || (groups.length() == 0))
				logger.info("No lookup service groups is specified. Please add -groups LOOKKUPGROUPS argument!");

			printUsage();
			System.exit(0);
		}

		if ((locators != null)) {
			if ((locators.length() == 0)) {
				logger.info("No lookup service locators is specified. Please add -locators LOOKKUPLOCATORS argument!");
				printUsage();
				System.exit(0);
			}
		}

		if ((groups != null)) {
			if ((groups.length() == 0)) {
				logger.info("No lookup service groups is specified. Please add -groups LOOKKUPGROUPS argument!");
				printUsage();
				System.exit(0);
			}
		}

		String puDependency = readFile(deployDependencyFile);

		List<String> allpuList = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(puDependency, "\n");
		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			if (token.startsWith("//") || token.startsWith("#"))
				continue;

			if ((token.indexOf(PU_START_LIST) < 0)
					&& (token.indexOf(PU_END_LIST) < 0)) {
				token = token + "[]";
			}
			String line = token;

			String curPU = token.substring(0, token.indexOf(PU_START_LIST));
			token = token.substring(token.indexOf(PU_START_LIST) + 1,
					token.indexOf(PU_END_LIST));

			StringTokenizer stPUList = new StringTokenizer(token, PU_SEPERATOR);
			List<String> cupuList = new ArrayList<String>();
			while (stPUList.hasMoreTokens()) {
				String aPU = stPUList.nextToken();
				cupuList.add(aPU.trim());
				allpuList.add(aPU.trim());
			}
			puDependencyMap.put(curPU.trim(), cupuList);
			String deployOptions = line.substring(
					line.indexOf(PU_END_LIST) + 1, line.length());

			String deplOptions[] = deployOptions.split(DEPLOY_OPTION_SEPERATOR);
			Properties deployProps = new Properties();
			for (int i = 0; i < deplOptions.length; i++) {
				String prop[] = deplOptions[i].split(" ");
				String option = prop[0];
				if ((option != null) && (option.length() > 0)) {
					String value = prop[1];
					if (prop.length > 2) {
						for (int j = 2; j < prop.length; j++) {
							value = value + " " + prop[j];
						}
					}
					deployProps.put(option.toLowerCase(), value);
				}
			}
			/*
			 * StringTokenizer deployParams = new StringTokenizer(deployOptions,
			 * DEPLOY_OPTION_SEPERATOR); Properties deployProps = new
			 * Properties(); while (deployParams.hasMoreTokens()) { String
			 * option = deployParams.nextToken(); String value =
			 * deployParams.nextToken(); deployProps.put(option.toLowerCase(),
			 * value); }
			 */
			pusDeployProperties.put(curPU.trim(), deployProps);
			// get deploy parameters

		}

		// loop thru all the PUs and order the PU based on the their dependency
		// start by looking for PUs with no dependency
		// remove PUs that
		Iterator<String> allpuListIter = allpuList.iterator();
		while (allpuListIter.hasNext()) {
			String pu = allpuListIter.next();

			if (puDependencyMap.get(pu) == null) {
				addPuToDeployList(pu);
				removeFromGraph(pu);
			}
		}

		addNoDependentPUtoList();
		if (deploy) {
			deployPU();
			logger.info("Deploy process is done!");
		} else {
			undeploy();
		}
		System.exit(0);
	}

	static void removeFromGraph(String pu) {
		// iterate the entire graph and remove pu in case it is there
		Iterator<String> keysIter = puDependencyMap.keySet().iterator();
		while (keysIter.hasNext()) {
			String puName = keysIter.next();
			List<String> pus = puDependencyMap.get(puName);
			pus.remove(pu);
			if (pus.size() == 0)
				addPuToDeployList(puName);
		}
	}

	static void addNoDependentPUtoList() {
		// iterate again and get all empty keys
		Iterator<String> keysIter = puDependencyMap.keySet().iterator();
		while (keysIter.hasNext()) {
			String key = keysIter.next();
			List<String> pus = puDependencyMap.get(key);
			if (pus.size() == 0) {
				addPuToDeployList(key);
			} else {
				if (puListToDeploy.containsAll(pus)) {
					addPuToDeployList(key);
				} else {
					Iterator<String> iter = pus.iterator();
					while (iter.hasNext()) {
						String n = iter.next();
						addPuToDeployList(n);

						removeFromGraph(n);
						addNoDependentPUtoList();
					}
				}
			}
		}
	}

	static boolean initDone = false;

	static void init() {
		if (initDone)
			return;
		initDone = true;
		// get admin , gsm , register listners
		AdminFactory af = new AdminFactory();
		if (locators != null)
			af.addLocator(locators);

		if (groups != null)
			af.addLocator(groups);

		admin = af.createAdmin();

		if (admin == null) {
			logger.info("Can't find Admin - Abort deploy");
			System.exit(1);
		}
		gsm = admin.getGridServiceManagers().waitForAtLeastOne(10,
				TimeUnit.SECONDS);
		if (gsm == null) {
			logger.info("Can't find GSM - Abort deploy");
			System.exit(1);
		}

		admin.getProcessingUnits().addLifecycleListener(
				new GSUniversalDeployer());
		admin.getGridServiceContainers().addLifecycleListener(
				new GSUniversalDeployer());

	}

	static void addPuToDeployList(String pu) {
		if (!puListToDeploy.contains(pu)) {
			puListToDeploy.add(pu);
		}
	}

	static void deployPU() throws Exception {
		init();
		logger.info("PU List To Deploy:" + puListToDeploy);

		// iterate over the deploy PU list
		// check if deployed. If not deployed , deploy
		Iterator<String> iter = puListToDeploy.iterator();
		while (iter.hasNext()) {
			String puName = iter.next();
			ProcessingUnit pu = admin.getProcessingUnits().waitFor(puName, 3,
					TimeUnit.SECONDS);
			if (pu != null) {
				logger.info("PU " + puName + " already deployed!");
				continue;
			}

			if (pusDeployProperties.containsKey(puName)) {
				ProcessingUnitDeployment puDeployConfig = null;
				SpaceDeployment puSpaceDeployConfig = null;
				ElasticStatefulProcessingUnitDeployment elaticpuDeployConfig = null;
				ElasticSpaceDeployment elaticSpacepuDeployConfig = null;

				boolean isElastic = false;

				// puDeployConfig.setContextProperty("dataGridName",
				// puName);
				Properties deployProps = new Properties();
				deployProps = pusDeployProperties.get(puName);
				boolean isSpacePU = false;
				if (deployProps.containsKey("type")) {
					String puType = getDeployProperty(deployProps, "type");
					PU_TYPE pu_type = PU_TYPE.valueOf(PU_TYPE.class, puType.toUpperCase());
					switch (pu_type) {
						case SPACE: {
							isSpacePU = true;
							break;
						}
						case STATEFULL: {
							break;
						}
						case STATELESS: {
							break;
						}
						default: {
							break;
						}
					}
				}

				if (deployProps.containsKey("file")) {
					String fileName = deployProps.getProperty("file");
					if (fileName.toLowerCase().endsWith(".zip")
							|| fileName.toLowerCase().endsWith(".jar")
							|| fileName.toLowerCase().endsWith(".war")) {
						puDeployConfig = new ProcessingUnitDeployment(new File(fileName));
						puDeployConfig.name(puName);
					} else {
						logger.info("file does not ends with zip/jar/war. Deploy Exit!");
						System.exit(0);
					}
				} else {
					if (isSpacePU)
					{
						puSpaceDeployConfig = new SpaceDeployment (puName);
					}
					else
					{
						puDeployConfig = new ProcessingUnitDeployment(puName);
					}
				}

				isElastic = deployProps.containsKey("elastic");
				if (isElastic) {
					boolean highlyAvailable = Boolean.valueOf(
							getDeployProperty(deployProps, "highlyAvailable",
									"true")).booleanValue();

					if (deployProps.containsKey("file")) {
						String fileName = deployProps.getProperty("file");
						if (fileName.toLowerCase().endsWith(".zip")
								|| fileName.toLowerCase().endsWith(".jar")
								|| fileName.toLowerCase().endsWith(".war")) {
							elaticpuDeployConfig = new ElasticStatefulProcessingUnitDeployment(
									new File(fileName));
						} else {
							logger.info("file does not ends with zip/jar/war. Deploy Exit!");
							System.exit(0);
						}
					} else {
						elaticpuDeployConfig = new ElasticStatefulProcessingUnitDeployment(puName);
					}

					elaticpuDeployConfig.name(puName);
					if (isSpacePU) {
						elaticSpacepuDeployConfig = new ElasticSpaceDeployment(puName);
					}

					String memoryCapacityPerContainer = getDeployProperty(deployProps,"memoryCapacityPerContainer", "32m");
					String maxMemoryCapacity = getDeployProperty(deployProps,"maxMemoryCapacity", "256m");
					String memoryCapacity = getDeployProperty(deployProps,"memoryCapacity", "128m");
					
					elaticpuDeployConfig
							.highlyAvailable(highlyAvailable)
							.memoryCapacityPerContainer(memoryCapacityPerContainer)
							.maxMemoryCapacity(maxMemoryCapacity)
							.scale(new ManualCapacityScaleConfigurer()
									.memoryCapacity(memoryCapacity)
									// .numberOfCpuCores(8)
									.create());

					if (isSpacePU) {
						elaticSpacepuDeployConfig
								.highlyAvailable(highlyAvailable)
								.memoryCapacityPerContainer(memoryCapacityPerContainer)
								.maxMemoryCapacity(maxMemoryCapacity)
								.scale(new ManualCapacityScaleConfigurer()
										.memoryCapacity(memoryCapacity)
										// .numberOfCpuCores(8)
										.create());

					}
					
					boolean singleMachineDeployment =Boolean.valueOf(
							getDeployProperty(deployProps,
									"singleMachineDeployment", "false"))
							.booleanValue();
					
					if (singleMachineDeployment)
						elaticpuDeployConfig.singleMachineDeployment();

					if (isSpacePU) {
						if (singleMachineDeployment)
							elaticSpacepuDeployConfig.singleMachineDeployment();
					}

					// elaticpuDeployConfig.maxNumberOfCpuCores(Integer.valueOf(deployProps.getProperty("maxNumberOfCpuCores","1000").toString()).intValue());
					// set the initial memory and CPU capacity

					if (getDeployProperty(deployProps, "elastic",
							"manualCapacity").equals("manualCapacity")) {
						elaticpuDeployConfig
								.scale(new ManualCapacityScaleConfigurer()
										.memoryCapacity(memoryCapacity)
										// .numberOfCpuCores(8)
										.create());
					} else {
						elaticpuDeployConfig.scale(new EagerScaleConfigurer()
						// .maxConcurrentRelocationsPerMachine(maxNumberOfConcurrentRelocationsPerMachine)
						// .numberOfCpuCores(8)
								.create());
					}

					if (isSpacePU) {
						if (getDeployProperty(deployProps, "elastic",
								"manualCapacity").equals("manualCapacity")) {
							elaticSpacepuDeployConfig
									.scale(new ManualCapacityScaleConfigurer()
											.memoryCapacity(memoryCapacity)
											// .numberOfCpuCores(8)
											.create());
						} else {
							elaticSpacepuDeployConfig
									.scale(new EagerScaleConfigurer()
									// .maxConcurrentRelocationsPerMachine(maxNumberOfConcurrentRelocationsPerMachine)
									// .memoryCapacity(deployProps.getProperty("memoryCapacity","512M").toString())
									// .numberOfCpuCores(8)
											.create());
						}
					}

				}

				if (deployProps.containsKey("sla")) {
					if (isSpacePU)
						puSpaceDeployConfig.slaLocation(getDeployProperty(deployProps,"sla"));
					else
						puDeployConfig.slaLocation(getDeployProperty(deployProps,"sla"));
				}

				if (deployProps.containsKey("cluster")) {
					String clusterConfig = getDeployProperty(deployProps,
							"cluster");
					StringTokenizer stclusterConfig = new StringTokenizer(
							clusterConfig, " ");
					while (stclusterConfig.hasMoreTokens()) {
						String token = stclusterConfig.nextToken();
						String clusterOptions[] = token.split("=");
						if (clusterOptions[0].equals("schema")) {
							if (isSpacePU)
								puSpaceDeployConfig.clusterSchema(clusterOptions[1]);
							else
								puDeployConfig.clusterSchema(clusterOptions[1]);
						}
						if (clusterOptions[0].equals("total_members")) {
							String clusterMembers[] = clusterOptions[1].split(",");
							if (isSpacePU)
							{
								puSpaceDeployConfig.numberOfInstances(Integer.valueOf(
										clusterMembers[0]).intValue());
								if (clusterMembers.length == 2)
									puSpaceDeployConfig.numberOfBackups(Integer.valueOf(
											clusterMembers[1]).intValue());
							}
							else
							{
								puDeployConfig.numberOfInstances(Integer.valueOf(
										clusterMembers[0]).intValue());
								if (clusterMembers.length == 2)
									puDeployConfig.numberOfBackups(Integer.valueOf(
											clusterMembers[1]).intValue());
							}
						}
					}
				}

				if (deployProps.containsKey("user")) {
					String user = getDeployProperty(deployProps, "user");
					String pass = getDeployProperty(deployProps, "password");
					
					if (isElastic) {
						if (isSpacePU) {
							elaticSpacepuDeployConfig.userDetails(user, pass);
						}
						else
							elaticpuDeployConfig.userDetails(user, pass);
					}
					else
					{
						if (isSpacePU) {
							puSpaceDeployConfig.userDetails(user, pass);
						}
						else
						{
							puDeployConfig.userDetails(user, pass);
						}
					}
				}
				
				if (deployProps.containsKey("secured")) {
					boolean secured = Boolean.valueOf(
							getDeployProperty(deployProps, "secured"))
							.booleanValue();

					if (isElastic) {
						elaticpuDeployConfig.secured(secured);
						
						if (isSpacePU) {
							elaticSpacepuDeployConfig.secured(secured);
						}
					}
					else
					{
						if (isSpacePU) {
							puSpaceDeployConfig.secured(secured);
						}
						else
						{
							puDeployConfig.secured(secured);
						}
					}
				}

				if (deployProps.containsKey("properties")) {
					String deployContextprops = getDeployProperty(deployProps,
							"properties");
					if (deployContextprops.startsWith("embed".toLowerCase())) {
						deployContextprops = deployContextprops.substring(8,
								deployContextprops.length());
						String deployContextpropsArr[] = deployContextprops
								.split(";");
						for (int i = 0; i < deployContextpropsArr.length; i++) {
							String deployContextpropsKeyVal[] = deployContextpropsArr[i]
									.split("=");
							if (isElastic) {
								elaticpuDeployConfig.addContextProperty(
										deployContextpropsKeyVal[0],
										deployContextpropsKeyVal[1]);
								
								if (isSpacePU) {
									elaticSpacepuDeployConfig.addContextProperty(
											deployContextpropsKeyVal[0],
											deployContextpropsKeyVal[1]);
								}
							} else {
								if (isSpacePU) {
									puSpaceDeployConfig.setContextProperty(
											deployContextpropsKeyVal[0],
											deployContextpropsKeyVal[1]);
								}
								else
									puDeployConfig.setContextProperty(
											deployContextpropsKeyVal[0],
											deployContextpropsKeyVal[1]);
							}
						}
					}

					if (deployContextprops.startsWith("file".toLowerCase())) {
						deployContextprops = deployContextprops.substring(7,
								deployContextprops.length());
						String deployContextpropsArrFiles[] = deployContextprops
								.split(";");
						Properties contextpropsProp = new Properties();
						File propsFile = new File(deployContextpropsArrFiles[0]);
						FileInputStream fis = new FileInputStream(propsFile);
						contextpropsProp.load(fis);
						fis.close();

						for (Enumeration e = contextpropsProp.keys(); e
								.hasMoreElements(); ) {
							String key = (String) e.nextElement();
							String value = contextpropsProp.getProperty(key);
							if (isElastic) {
								if (isSpacePU) {
									elaticSpacepuDeployConfig.addContextProperty(key,value);
								}
								else
									elaticpuDeployConfig.addContextProperty(key,value);
									
							} else {
								if (isSpacePU) {
									puSpaceDeployConfig.setContextProperty(key, value);
								}
								else
									puDeployConfig.setContextProperty(key, value);
							}
						}

					}
					// end properties
				}

				if (deployProps.containsKey("max-instances-per-vm")) {
					if (isSpacePU)
						puSpaceDeployConfig.maxInstancesPerMachine(Integer.valueOf(
								getDeployProperty(deployProps,
								"max-instances-per-vm")).intValue());
					else
						puDeployConfig.maxInstancesPerVM(Integer.valueOf(
								getDeployProperty(deployProps,
										"max-instances-per-vm")).intValue());
				}

				if (deployProps.containsKey("max-instances-per-machine")) {
					if (isSpacePU)
						puSpaceDeployConfig.maxInstancesPerMachine(Integer.valueOf(
								getDeployProperty(deployProps,
										"max-instances-per-machine"))
								.intValue());
					else
						puDeployConfig.maxInstancesPerMachine(Integer.valueOf(
								getDeployProperty(deployProps,"max-instances-per-machine"))
								.intValue());
				}

				if (deployProps.containsKey("max-instances-per-zone")) {
					String zones = getDeployProperty(deployProps,
							"max-instances-per-zone");
					String zonesArry[] = zones.split(" ");
					for (int i = 0; i < zonesArry.length; i++) {
						String zonesArryInfo[] = zonesArry[i].split("/");
						
						if (isSpacePU)
							puSpaceDeployConfig.maxInstancesPerZone(zonesArryInfo[0],
									Integer.valueOf(zonesArryInfo[1]).intValue());
						else
							puDeployConfig.maxInstancesPerZone(zonesArryInfo[0],
									Integer.valueOf(zonesArryInfo[1]).intValue());
					}
				}

				if (deployProps.containsKey("zones")) {
					String zones = getDeployProperty(deployProps, "zones");
					String zonesArry[] = zones.split(" ");
					for (int i = 0; i < zonesArry.length; i++) {
						if (isSpacePU)
							puSpaceDeployConfig.addZone(zonesArry[i]);
						else
							puDeployConfig.addZone(zonesArry[i]);
					}
				}

				boolean undeployOnFailure = false;
				if (deployProps.containsKey("undeployOnFailure")) {
					undeployOnFailure = Boolean.valueOf(
							getDeployProperty(deployProps, "undeployOnFailure",
									"false")).booleanValue();
				}

				if (isElastic) {
					if (elasticServiceManager == null) {
						elasticServiceManager = admin
								.getElasticServiceManagers().waitForAtLeastOne(
										5, TimeUnit.SECONDS);
					}
					if (elasticServiceManager == null) {
						logger.info("Can't find ElasticServiceManager. Abort Deploy.");
						break;
					}
					admin.getElasticServiceManagers().addLifecycleListener(
							new GSUniversalDeployer());
				}

				startdeploy(puName, deployProps, isElastic, puSpaceDeployConfig , puDeployConfig,elaticpuDeployConfig, elaticSpacepuDeployConfig, undeployOnFailure , isSpacePU);

			}
		}
		admin.close();
	}

	static void startdeploy(String puName, Properties deployProps,
			boolean isElastic, 
			SpaceDeployment puSpaceDeployConfig,
			ProcessingUnitDeployment puDeployConfig,
			ElasticStatefulProcessingUnitDeployment elaticpuDeployConfig,
			ElasticSpaceDeployment elaticSpacepuDeployConfig,			
			boolean undeployOnFailure,
			boolean isSpacePU) 
	{
		ProcessingUnit pu;
		long stTime = System.currentTimeMillis(), enTime = 0;
		logger.info("Deploying " + puName + " - Deploy options:" + deployProps);
		try {
			if (isElastic) 
			{
				if (isSpacePU)
					pu = gsm.deploy(elaticSpacepuDeployConfig, 100, TimeUnit.SECONDS);
				else
					pu = gsm.deploy(elaticpuDeployConfig, 100, TimeUnit.SECONDS);
			}
			else {
				if (isSpacePU)
					pu = gsm.deploy(puSpaceDeployConfig, 100, TimeUnit.SECONDS);
				else
					pu = gsm.deploy(puDeployConfig, 100, TimeUnit.SECONDS);
						
			}

			pu = admin.getProcessingUnits().waitFor(puName, 10, TimeUnit.SECONDS);
			int timeout = 1000 * Integer.valueOf(getDeployProperty(deployProps, "timeout", "120")).intValue();
			boolean deployOK = false;

			// start Deploy
			while (true) {
				if (pu == null)
					pu = admin.getProcessingUnits().waitFor(puName, 10, TimeUnit.SECONDS);
				if (pu == null)
				{
					logger.info("Can't acces PU. Abort Deploy process");
					System.exit(0);
				}
				DeploymentStatus deployStatus = pu.getStatus();
				if (deployStatus == null) {
					break;
				}
				if (deployStatus.equals(DeploymentStatus.INTACT)) {
					deployOK = true;
					enTime = System.currentTimeMillis();
					break;
				}
				if (System.currentTimeMillis() > (stTime + timeout)) {
					break;
				}
				try {
					logger.info("Waiting for PU " + puName + " to deploy...");
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (deployOK) {
				logger.info("PU " + pu.getName()
						+ " deployed sucessfuly. Time to deploy: "
						+ (enTime - stTime) / 1000 + " seconds");
				deployedPUs.add(pu);
			} else {
				logger.info("PU " + pu.getName()
						+ " cannot be deployed sucessfuly.");
				handleFailure(undeployOnFailure, puName);
			}
		} catch (org.openspaces.admin.AdminException adminEx) {
			adminEx.printStackTrace();
			logger.info(adminEx.getMessage());
			handleFailure(undeployOnFailure, puName);
		}
	}

	static void undeploy() {
		init();
		logger.info("PU List To UnDeploy:" + puListToDeploy);
		unDeployAllpus();
		/*
		 * Iterator<String> iter = puListToDeploy.iterator(); while
		 * (iter.hasNext()) { String puToUndeploy = iter.next();
		 * logger.info("Undeploy " + puToUndeploy); gsm.undeploy(puToUndeploy);
		 * }
		 */
	}

	static void handleFailure(boolean undeployOnFailure, String puName) {
		if (undeployOnFailure) {
			logger.info("Intiating undeploy process for " + puName);
			gsm.undeploy(puName);
		}

		if (abortDeployOnFailure) {
			logger.info("Aborting Deploy process");
			unDeployAllpus();
			logger.info("Abort process completed. Exit!");
			admin.close();
			System.exit(0);
		}

	}

	public static String readFile(String File) throws Exception {
		String fileStr = "";
		File file = new File(File);
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;

		fis = new FileInputStream(file);

		// Here BufferedInputStream is added for fast reading.
		bis = new BufferedInputStream(fis);
		dis = new DataInputStream(bis);

		// dis.available() returns 0 if the file does not have more lines.
		while (dis.available() != 0) {

			fileStr = fileStr + dis.readLine() + "\n";
		}

		// dispose all the resources after using them.
		fis.close();
		bis.close();
		dis.close();
		return fileStr;

	}

	static String getDeployProperty(Properties deployProps, String name) {
		return deployProps.getProperty(name.toLowerCase()).toString();
	}

	static String getDeployProperty(Properties deployProps, String name,
			String defaultValue) {
		return deployProps.getProperty(name.toLowerCase(), defaultValue)
				.toString();
	}

	static void unDeployAllpus() {
		Iterator<String> puListIter = puListToDeploy.iterator();
		while (puListIter.hasNext()) {
			String putoUndeplpoy = puListIter.next();
			logger.info("Undeploying " + putoUndeplpoy);
			long stTime = System.currentTimeMillis(), enTime = 0;
			boolean undeployOK = false;
			try {
				gsm = admin.getGridServiceManagers().waitForAtLeastOne(10,
						TimeUnit.SECONDS);
				if (gsm == null) {
					logger.info("Can't find a GSM. Exit!");
					System.exit(0);
				}
				gsm.undeploy(putoUndeplpoy);
				// wait for undeploy to complete
				while (true) {
					ProcessingUnits pus = admin.getProcessingUnits();
					if (!pus.getNames().containsKey(putoUndeplpoy)) {
						undeployOK = true;
						break;
					}

					if (System.currentTimeMillis() > (stTime + 60000)) {
						break;
					}

					try {
						logger.info("Waiting for undeploy to complete...");
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
				logger.info(e.getMessage());
			}

			if (undeployOK)
				logger.info("PU " + putoUndeplpoy + " undeployed successfully!");
		}
	}

	/*
	 * static public void sendemail(String emailMessage ) throws Exception {
	 * String EMAIL_TO = "email.to"; String EMAIL_SUBJECT = "email.subject";
	 * String EMAIL_FROM ="email.from"; String EMAIL_HOSTNAME =
	 * "email.hostname"; String EMAIL_USERNAME = "email.username"; String
	 * EMAIL_PASSWORD = "email.password"; String emailList =
	 * System.getProperty(EMAIL_TO);//"shay@gigaspaces.com"; String
	 * emailSubjectTxt=
	 * System.getProperty(EMAIL_SUBJECT);//;"problem with spaces"; String
	 * emailFromAddress= System.getProperty(EMAIL_FROM);//
	 * "shay@gigaspaces.com"; String SMTP_HOST_NAME =
	 * System.getProperty(EMAIL_HOSTNAME); //;"tigger.gspaces.com"; String
	 * SMTP_AUTH_USER= System.getProperty(EMAIL_USERNAME); String SMTP_AUTH_PWD
	 * = System.getProperty(EMAIL_PASSWORD);
	 * SendMailUsingAuthentication.main(new String []{emailList ,
	 * emailSubjectTxt , emailMessage ,emailFromAddress , SMTP_HOST_NAME
	 * ,SMTP_AUTH_USER,SMTP_AUTH_PWD }); }
	 */

	@Override
	public void elasticServiceManagerAdded(
			ElasticServiceManager elasticServiceManager) {
		logger.info("elasticServiceManagerAdded "
				+ elasticServiceManager.toString());
	}

	@Override
	public void elasticServiceManagerRemoved(
			ElasticServiceManager elasticServiceManager) {
		logger.info("elasticServiceManagerRemoved "
				+ elasticServiceManager.toString());

	}

	@Override
	public void processingUnitInstanceAdded(
			ProcessingUnitInstance processingUnitInstance) {
		logger.info("processingUnitInstanceAdded "
				+ getProcessingUnitInstanceDesc(processingUnitInstance));

	}

	@Override
	public void processingUnitInstanceRemoved(
			ProcessingUnitInstance processingUnitInstance) {
		logger.info("processingUnitInstanceRemoved "
				+ getProcessingUnitInstanceDesc(processingUnitInstance));
	}

	@Override
	public void gridServiceContainerAdded(
			GridServiceContainer gridServiceContainer) {
		logger.info("gridServiceContainerAdded "
				+ getGridServiceContainerDesc(gridServiceContainer));
	}

	@Override
	public void gridServiceContainerRemoved(
			GridServiceContainer gridServiceContainer) {
		logger.info("gridServiceContainerRemoved "
				+ getGridServiceContainerDesc(gridServiceContainer));
	}

	static String getProcessingUnitInstanceDesc(
			ProcessingUnitInstance processingUnitInstance) {
		String desc = "PU Uid:"
				+ processingUnitInstance.getUid()
				+ " "
				+ " AgentId:"
				+ processingUnitInstance.getGridServiceContainer()
						.getGridServiceAgent().getUid()
				+ " "
				+ " HostName:"
				+ processingUnitInstance.getMachine().getHostName()
				+ " "
				+ " HostAddress:"
				+ processingUnitInstance.getMachine().getHostAddress()
				+ " "
				+ " Pid:"
				+ processingUnitInstance.getVirtualMachine().getDetails()
						.getPid()
				+ " "
				+ " MemoryHeapMaxInMB:"
				+ processingUnitInstance.getVirtualMachine().getDetails()
						.getMemoryHeapMaxInMB() + " " + " Zones:"
				+ processingUnitInstance.getZones().keySet();
		return desc;
	}

	static String getGridServiceContainerDesc(
			GridServiceContainer gridServiceContainer) {
		String desc = "GSC Uid:"
				+ gridServiceContainer.getUid()
				+ " "
				+ " AgentId:"
				+ gridServiceContainer.getGridServiceAgent().getUid()
				+ " "
				+ " HostName:"
				+ gridServiceContainer.getMachine().getHostName()
				+ " "
				+ " HostAddress:"
				+ gridServiceContainer.getMachine().getHostAddress()
				+ " "
				+ " Pid:"
				+ gridServiceContainer.getVirtualMachine().getDetails()
						.getPid()
				+ " "
				+ " MemoryHeapMaxInMB:"
				+ gridServiceContainer.getVirtualMachine().getDetails()
						.getMemoryHeapMaxInMB() + " " + " Zones:"
				+ gridServiceContainer.getZones().keySet();
		return desc;
	}

	static void printUsage() {
		System.out
				.println("\n\n ----- GigaSpaces Universal Deployer ----- \nUsage:\n"
						+ "java com.gigaspaces.admin.GSUniversalDeployer -config CONFIG_LOCATION -groups LOOKUPGROUPS -locators LOOKUPLOCATORS -abortDeployOnFailure true|false -command deploy|undeploy\n"
						+ "\n\nSee details at:http://www.gigaspaces.com/wiki/display/SBP/Universal+Deployer");
	}

	public enum PU_TYPE {
		REGULAR ,SPACE, STATELESS, STATEFULL

	}
}

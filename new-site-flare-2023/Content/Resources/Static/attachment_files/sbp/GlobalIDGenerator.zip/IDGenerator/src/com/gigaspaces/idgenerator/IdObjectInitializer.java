package com.gigaspaces.idgenerator;

import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoContext;
import org.openspaces.core.context.GigaSpaceContext;
import org.springframework.beans.factory.InitializingBean;

import com.j_spaces.core.client.UpdateModifiers;

public class IdObjectInitializer implements InitializingBean{

    @GigaSpaceContext
    private GigaSpace gigaSpace;
    
    @ClusterInfoContext
    private ClusterInfo clusterInfo;
    private int idRangeSize = 1000;
    
    /**
     * Sets the range size,
     * @param idRangeSize
     */
    public void setIdRangeSize(int idRangeSize) {
        this.idRangeSize = idRangeSize;
    }

    public void init() {
    	System.out.println("IdObjectInitializer init called");
        if (shouldWriteIdObjectToSpace())   {
            IdCounterEntry existingEntry = gigaSpace.readById(IdCounterEntry.class, 0);
            if (existingEntry == null) {
                gigaSpace.write(new IdCounterEntry(100, idRangeSize) ,Lease.FOREVER,0,UpdateModifiers.WRITE_ONLY ) ;
            	System.out.println("IdObjectInitializer wrote IdCounterEntry");
            }
        }
    }

    //return true if we don't have a clusterInfo/instance id, or if this the first
    //primary instance in the cluster
    private boolean shouldWriteIdObjectToSpace() {
        if  (clusterInfo == null)
            return true;
        if (clusterInfo.getInstanceId() == null)
            return true;
        if (clusterInfo.getInstanceId() == 1)
            return true;
        return false;
    }

	@Override
	public void afterPropertiesSet() throws Exception {
		init() ;
	}
}

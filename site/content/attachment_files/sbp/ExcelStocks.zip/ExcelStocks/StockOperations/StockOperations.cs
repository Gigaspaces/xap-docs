using System;
using System.Text;
using System.Configuration;
using System.Runtime.InteropServices;
using Microsoft.Win32;

using GigaSpaces.Core;
using GigaSpaces.Examples.ExcelStocks.StockEntities;
using System.Windows.Forms;

namespace GigaSpaces.Examples.ExcelStocks.Operations
{
    /// <summary>
    /// Stock Market Data - user defined functions: Read the "Open" value of a Symbol.
    /// </summary>
    [ClassInterface(ClassInterfaceType.AutoDual), ComVisible(true)]
	[ProgId("Stock.Operations")]
	public class StockOperations
    {
        #region Members

        // List of all the errors
        private StringBuilder _errorLog = new StringBuilder();
        // Space proxy
        private ISpaceProxy _proxy;
		private bool _messageBoxShown = false;
       
        #endregion

        /// <summary>
        /// Constructor - connecting to the Space
        /// </summary>
        public StockOperations()
        {
			// Config the JVM Initial and Maximum Heap Size
			SpaceProxyProviderFactory.Configuration.JvmSettings.JvmMemory.InitialHeapSizeInMB = 32;
			SpaceProxyProviderFactory.Configuration.JvmSettings.JvmMemory.MaximumHeapSizeInMB = 64;
			
			try
            {
                string spaceUrl = ConfigurationManager.AppSettings["SpaceUrlMarket"];
                _proxy = SpaceProxyProviderFactory.Instance.FindSpace(spaceUrl);
            }
            catch (Exception ex)
            {
				LogError("Error in Stock.Operations. Message:", ex);
            }
        }

        /// <summary>
        /// Read a Open Stock Value for a given Symbol from the Space
        /// </summary>
        /// <param name="symbol">Stock Symbol</param>
        /// <returns>Open Stock Value</returns>
        public double ReadOpen(String symbol)
        {
            try
            {
                StockData template = new StockData();
                template.Symbol = symbol;
                StockData stockData = _proxy.Read<StockData>(template);

				if (stockData == null)
				{
					MessageBox.Show("Symbol not found: " + symbol); 
					return 0;
				}

            	return stockData.Open.Value;
            }
            catch (Exception ex)
            {
                LogError("Error reading Open value.", ex);
                throw;
            }
        }

        /// <summary>
        /// Return the list of errors that occured
        /// </summary>
        /// <returns></returns>
        public string GetErrorLog()
        {
            return _errorLog.ToString();
        }

        #region COM registeration and unregister functions

        [ComRegisterFunctionAttribute]
        public static void RegisterFunction(Type type)
        {
            Registry.ClassesRoot.CreateSubKey(GetSubKeyName(type));
        }

        [ComUnregisterFunctionAttribute]
        public static void UnregisterFunction(Type type)
        {
            Registry.ClassesRoot.DeleteSubKey(GetSubKeyName(type), false);
        }

        private static string GetSubKeyName(Type type)
        {
            return @"CLSID\{" + type.GUID.ToString().ToUpper() + @"}\Programmable";
        }

        #endregion

        #region Private methods
        
        private void LogError(string logMessage, Exception ex)
        {
			if (!_messageBoxShown)
			{
				_messageBoxShown = true;
				MessageBox.Show(logMessage + ex.Message + ex.StackTrace);
			} 
			
			_errorLog.Append(DateTime.Now.ToString());
			_errorLog.Append("Error in Stock.Operations. Message:");
            _errorLog.AppendLine(ex.Message);
            _errorLog.AppendLine();
            _errorLog.AppendLine(ex.StackTrace);
            _errorLog.AppendLine();            
        }

        #endregion
    }
}
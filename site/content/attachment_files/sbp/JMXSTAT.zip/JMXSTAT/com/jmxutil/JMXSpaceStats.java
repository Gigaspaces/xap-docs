package com.jmxutil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.PrintWriter;
import java.lang.management.*;

import java.util.*;

import javax.management.*;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.gigaspaces.lrmi.TransportProtocolHelper;
import com.j_spaces.core.*;
import com.j_spaces.core.IJSpaceContainer;
import com.j_spaces.core.admin.IJSpaceContainerAdmin;
import com.j_spaces.core.admin.IRemoteJSpaceAdmin;
import com.j_spaces.core.client.IDirectSpaceProxy;
import com.j_spaces.core.client.SpaceFinder;
import com.j_spaces.core.client.SpaceURL;
import com.j_spaces.core.cluster.ClusterPolicy;
import com.j_spaces.core.cluster.ReplicationPolicy;
import com.j_spaces.core.filters.FilterOperationCodes;
import com.j_spaces.core.filters.StatisticsContext;

/**
 * @author Yogesh.Parchure
 *         <p>
 *         February 2008
 * @version 1.0
 *          <p>
 *          Parameters to this class are the JMX URL for the space, result file
 *          name, statistics interval time in milliseconds.
 */
public class JMXSpaceStats {

	static String gropus = null;

	static String locators = null;

	static String spaceName;

	static PrintWriter pw = null;

	static int sleeptime = 5000;

	static boolean using15JVM = true;

	static IJSpace spaceProxyClustered = null;

	static Set jmxClusterInfo = new HashSet();

	static List spaces = new ArrayList();

	static File resultFile;

	static String spaceURL = null;

	public static void main(String[] args) {
		if (args.length == 0) {
			showUsage();
			System.exit(1);
		}

		spaceURL = args[0];

		if (args[1] == null || args[1].length() == 0) {
			echo("Result file not specified");
			System.exit(1);
		}
		resultFile = new File(args[1]);

		if (args[2] != null && args[2].length() != 0) {
			try {
				sleeptime = Integer.parseInt(args[2]);
			} catch (NumberFormatException nfe) {
				sleeptime = 5000;
			}
		}

		try {

			init();

			while (true) {
				try {
					echo(new Date() + " - Sampling Cluster");
					Iterator iterJMXClusterInfo = jmxClusterInfo.iterator();
					while (iterJMXClusterInfo.hasNext()) {
						getJMXStats((JMXInfo) iterJMXClusterInfo.next());
					}
					sleep(sleeptime);
				} catch (Exception e) {
					e.printStackTrace();
					while (true) {
						try {
							sleep(sleeptime);
							echo("retry...");
							init();
							break;
						} catch (Exception e1) {
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static public void init() throws Exception {
		spaceProxyClustered = (IJSpace) SpaceFinder.find(spaceURL);

		SpaceURL spaceUrl = spaceProxyClustered.getURL();
		gropus = spaceUrl.getProperty(SpaceURL.GROUPS);
		locators = spaceUrl.getProperty(SpaceURL.LOCATORS);
		spaceName = spaceProxyClustered.getName();

		// get all cluster members
		spaces.clear();
		getClusterSpaces(spaceProxyClustered, spaces);
		echo("Tracking " + spaces);
		try {
			if (pw == null) {
				pw = new PrintWriter(new FileOutputStream(resultFile), true);
				pw.println("\n\nTracking the following spaces:" + spaces);
				pw
						.println("\n\nTime,Space Container,Space Host Name,JVM thread Count,JVM heap Committed,JVM heap max,"
								+ "JVM heap used,Space read Count,Space write Count,Space update Count,Space take Count,Space Notify Registration Count,Space Trigger Count,Total Connections");
			}

		} catch (FileNotFoundException e) {
			echo("Caught Exception while opening file " + resultFile.getName());
			e.printStackTrace();
			System.exit(1);
		}

		Iterator iter = spaces.iterator();
		jmxClusterInfo.clear();
		while (iter.hasNext()) {
			IJSpace spaceProxy = (IJSpace) iter.next();
			IJSpaceContainerAdmin containerProxy = (IJSpaceContainerAdmin) spaceProxy
					.getContainer();
			JMXInfo jmxInfo = getJMXInfo("service:jmx:rmi:///jndi/rmi://"
					+ containerProxy.getConfig().getJndiURL() + "/jmxrmi");
			jmxInfo.host= containerProxy.getConfig().containerHostName;
			jmxInfo.spaceProxy= spaceProxy;

			IRemoteJSpaceAdmin remoteAdminSpace = (IRemoteJSpaceAdmin) ((IDirectSpaceProxy) spaceProxy)
					.getRemoteJSpace();
			// get remote space id
			Long objID = new Long(TransportProtocolHelper
					.getRemoteObjID(remoteAdminSpace));

			ObjectName mBeanConnectionName = new ObjectName(
					"com.gigaspaces.management:type=TransportConnections,name=transport-"
							+ spaceProxy.getContainer().getName());
			jmxInfo.mBeanConnectionName =mBeanConnectionName;

			jmxInfo.objID= objID;
			jmxClusterInfo.add(jmxInfo);
		}

	}

	public static void getJMXStats(JMXInfo jmxInfo) throws Exception {
		
		MBeanInfo gsmbeaninfo = jmxInfo.mbsc.getMBeanInfo(jmxInfo.gsmbeanName);
		MBeanOperationInfo[] gsmbeanops = gsmbeaninfo.getOperations();
		MBeanParameterInfo[] gsmbeanGetStatisticsparms;

		String[] gs_getstats_return = null;
		for (int i = 0; i < gsmbeanops.length; i++) {

			// get the method signature for getStatistics
			if (gsmbeanops[i].getName().equals("getStatistics")) {
				gsmbeanGetStatisticsparms = gsmbeanops[i].getSignature();
				gs_getstats_return = new String[gsmbeanGetStatisticsparms.length];
				for (int j = 0; j < gsmbeanGetStatisticsparms.length; j++) {
					gs_getstats_return[j] = gsmbeanGetStatisticsparms[j]
							.getType();
				}
			}
		}

		Object[] beforeReadFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_READ) };
		Object[] afterReadMultipleFilters = new Object[] { new Integer(
				FilterOperationCodes.AFTER_READ_MULTIPLE) };
		Object[] beforeWriteFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_WRITE) };
		Object[] beforeTakeFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_TAKE) };
		Object[] beforeTakeMultFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_TAKE_MULTIPLE) };
		Object[] updateFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_UPDATE) };

		Object[] notifyRegFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_NOTIFY) };

		Object[] notifyRegTrigFilters = new Object[] { new Integer(
				FilterOperationCodes.BEFORE_NOTIFY_TRIGGER) };

		Object[] params = { jmxInfo.objID };
		String[] signature = { long.class.getName() };

		StatisticsContext readStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", beforeReadFilters,
				gs_getstats_return);
		StatisticsContext readMStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", afterReadMultipleFilters,
				gs_getstats_return);

		StatisticsContext writeStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", beforeWriteFilters,
				gs_getstats_return);

		StatisticsContext takeStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", beforeTakeFilters,
				gs_getstats_return);

		StatisticsContext takeMStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", beforeTakeMultFilters,
				gs_getstats_return);

		StatisticsContext updateStat = (StatisticsContext) jmxInfo.mbsc
				.invoke(jmxInfo.gsmbeanName, "getStatistics", updateFilters,
						gs_getstats_return);

		StatisticsContext notifyRegStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", notifyRegFilters,
				gs_getstats_return);

		StatisticsContext notifyTrigStat = (StatisticsContext) jmxInfo.mbsc.invoke(
				jmxInfo.gsmbeanName, "getStatistics", notifyRegTrigFilters,
				gs_getstats_return);

		// sleep(sleeptime);
		String output = null;
		List connectionsList = null;
		if (using15JVM) {
			jmxInfo.memused = jmxInfo.memoryproxy.getHeapMemoryUsage();
			output = "," + jmxInfo.threadproxy.getThreadCount() + ","
					+ jmxInfo.memused.getCommitted() + "," + jmxInfo.memused.getMax() + ","
					+ jmxInfo.memused.getUsed();
		} else {
			output = ",0,0,0,0";
		}

		connectionsList = (List) jmxInfo.mbsc.invoke(jmxInfo.mBeanConnectionName,
				"getTransportConnections", params, signature);
		pw
				.println(new Date(System.currentTimeMillis())
						+ ","
						+ jmxInfo.spaceProxy.getContainer().getName()
						+ ","
						+ jmxInfo.host
						+ output
						+ ","
						+ ((readStat == null ? 0 : readStat.getCurrentCount()) + (readMStat == null ? 0
								: readMStat.getCurrentCount()))
						+ ","
						+ (writeStat == null ? 0 : writeStat.getCurrentCount())
						+ ","
						+ (updateStat == null ? 0 : updateStat
								.getCurrentCount())
						+ ","
						+ ((takeStat == null ? 0 : takeStat.getCurrentCount()) + (takeMStat == null ? 0
								: takeMStat.getCurrentCount()))
						+ ","
						+ (notifyRegStat == null ? 0 : notifyRegStat
								.getCurrentCount())
						+ ","
						+ (notifyTrigStat == null ? 0 : notifyTrigStat
								.getCurrentCount()) + ","
						+ connectionsList.size());

	}

	private static void showUsage() {
		echo("This Program Monitors a Running Space Cluster");
		echo("Usage: JMXSpaceStats spaceURL LogFile Sampling_Duration");
	}

	private static void echo(String msg) {
		System.out.println(msg);
	}

	private static void sleep(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	static private void getClusterSpaces(IJSpace space, List spaces)
			throws Exception {
		IRemoteJSpaceAdmin admin = (IRemoteJSpaceAdmin) space.getAdmin();

		ClusterPolicy clusterPolicy = admin.getClusterPolicy();

		if (clusterPolicy == null) {
			spaces.add(space);
			return;
		}

		List replicationGroups = clusterPolicy.m_ReplicationGroups;

		int partitions = replicationGroups.size();
		Set totalMembers = new HashSet();
		for (int i = 0; i < partitions; i++) {
			ReplicationPolicy replicationPolicy = (ReplicationPolicy) replicationGroups
					.get(i);
			List members = replicationPolicy.m_ReplicationGroupMembersNames;

			if (members.size() == 1)
				throw new RuntimeException("exit - No replica spaces");

			for (int u = 0; u < members.size(); u++) {
				totalMembers.add(members.get(u));
			}
		}
		Iterator iter = totalMembers.iterator();
		while (iter.hasNext()) {
			IJSpace directProxy = getSpaceDirectProxy((String) iter.next());
			spaces.add(directProxy);
		}

	}

	static IJSpace getSpaceDirectProxy(String spaceMemeberName)
			throws Exception {

		String containerName = spaceMemeberName.substring(0, spaceMemeberName
				.indexOf(":"));
		String containerURL = "jini://*/" + containerName;

		if (gropus != null)
			containerURL = containerURL + "?groups=" + gropus;

		if (locators != null)
			containerURL = containerURL + "&locators=" + locators;

		IJSpaceContainer spaceContainer = (IJSpaceContainer) SpaceFinder
				.find(containerURL);
		return spaceContainer.getSpace(spaceName);
	}

	static public JMXInfo getJMXInfo(String jmxUrl) {
		JMXInfo jmxInfo = new JMXInfo();
		try {
			// Create an RMI connector client and
			// connect it to the RMI connector server
			//
			echo("\nConnect to " + jmxUrl);
			JMXServiceURL url = new JMXServiceURL(jmxUrl);
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);

			MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
			jmxInfo.mbsc= mbsc;
			ObjectName gsmbeanName = null;
			Set names = mbsc.queryNames(null, null);
			for (Iterator i = names.iterator(); i.hasNext();) {
				ObjectName testObj = (ObjectName) i.next();
				if (testObj.toString().startsWith(
						"com.gigaspaces:type=JavaSpace,name=")) {
					gsmbeanName = testObj;
					break;
				}
			}

			jmxInfo.gsmbeanName= gsmbeanName;

			if (null == gsmbeanName) {
				echo("GigaSpaces Space MBean not found. Exiting.");
				System.exit(1);
			}
			MemoryUsage memused = null;
			ThreadMXBean threadproxy = null;
			MemoryMXBean memoryproxy = null;
			// Get a MBean proxy for RuntimeMXBean interface
			try {
				RuntimeMXBean proxy = (RuntimeMXBean) ManagementFactory
						.newPlatformMXBeanProxy(mbsc,
								ManagementFactory.RUNTIME_MXBEAN_NAME,
								RuntimeMXBean.class);

				echo("Runtime JVM Name: " + proxy.getVmName() + " JVM Vendor: "
						+ proxy.getVmVendor());
				threadproxy = (ThreadMXBean) ManagementFactory
						.newPlatformMXBeanProxy(mbsc,
								ManagementFactory.THREAD_MXBEAN_NAME,
								ThreadMXBean.class);

				jmxInfo.threadproxy= threadproxy;

				memoryproxy = (MemoryMXBean) ManagementFactory
						.newPlatformMXBeanProxy(mbsc,
								ManagementFactory.MEMORY_MXBEAN_NAME,
								MemoryMXBean.class);

				jmxInfo.memoryproxy= memoryproxy;

				memused = memoryproxy.getHeapMemoryUsage();

				jmxInfo. memused= memused;

				return jmxInfo;
			} catch (Exception e) {
				using15JVM = false;
				return jmxInfo;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return jmxInfo;
	}

	public static class JMXInfo
	{
		MBeanServerConnection mbsc ;
		MemoryMXBean memoryproxy ;
		MemoryUsage memused ;
		ThreadMXBean threadproxy ;
		ObjectName gsmbeanName ;
		IJSpace spaceProxy ;
		Long objID ;
		ObjectName mBeanConnectionName ;
		String host;
	}
}

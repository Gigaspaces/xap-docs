package org.openspaces.calcengine;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openspaces.admin.Admin;
import org.openspaces.admin.AdminFactory;
import org.openspaces.admin.pu.ProcessingUnit;

public class ScaleWorker {

	static String locators = System.getProperty("locators", "127.0.0.1");
	static ProcessingUnit workerPU = null;	
	public static void main(String[] args) throws Exception{
		
		Admin admin = new AdminFactory().discoverUnmanagedSpaces().addLocator(locators).createAdmin();

		if (admin == null)
		{
			System.out.println("Can locate lookup service and generate admin object. Exit");
			System.exit(0);
		}
				
		workerPU = admin.getProcessingUnits().waitFor("worker",5,TimeUnit.SECONDS);
		
		Logger.getLogger("org.openspaces.admin.internal.discovery.DiscoveryService").setLevel(Level.OFF);
		Logger.getLogger("com.sun.jini.reggie").setLevel(Level.OFF);
		Logger.getLogger("com.gigaspaces.client").setLevel(Level.OFF);
		Logger.getLogger("net.jini.discovery.LookupLocatorDiscovery").setLevel(Level.OFF);
		
		if (workerPU == null)
		{
			System.out.println("Can't find Worker PU");
			System.exit(0);
		}
		
		Scanner scanner = new Scanner(System.in);
		while(true)
		{
			int workersCount = workerPU.getNumberOfInstances();
			System.out.println("We have " +workersCount  + " workers." +" Type u to Scale Up, d to Scale Down , e to exit");
			
			String action = scanner.nextLine();
			
			if (action.toLowerCase().equals("u"))
			{
				workerPU.incrementInstance();
				workerPU.waitFor(workersCount + 1,10, TimeUnit.SECONDS);
			}
			
			else if (action.toLowerCase().equals("d"))
			{
				if (workersCount==1)
				{
					System.out.println("Can't scale down. There is only one Worker!");
				}
				else
				{
					workerPU.decrementInstance();
					workerPU.waitFor(workersCount - 1,10, TimeUnit.SECONDS);
					Thread.sleep(2000);
				}
			}
			
			else if (action.toLowerCase().equals("e"))
			{
				break;
			}
			else
			{
				System.out.println("Wrong input!");
			}

		}
		admin.close();
	}
}
